# Validierung v0.4.12

## Lokal erfolgreich geprüft

- Vollständiger Firmwarebuild: PlatformIO 6.1.19, espressif8266 4.2.1, Arduino-ESP8266 3.1.2, ArduinoJson 7.4.3, GFX Library for Arduino 1.6.8.
- Statischer RAM: 53.236 / 81.920 Bytes (65,0 %). Flash: 699.527 / 1.044.464 Bytes (67,0 %). Das sind keine Laufzeit-Heap-Messungen.
- Geo: Originalfehler mit Standard-Schreibkapazität 0 reproduziert. Die echte Framework-Übertragungsroutine wird mit dem Produktionspuffer geprüft: erfolgreicher Empfang, 256-Byte-Schritte, 48-KiB-Grenze, Kurzschreiben, Transportfehler, Öffnungs-/Truncate-Fehler, Heap-Ablehnung vor und während des Empfangs und Dateilöschung. JSON wird erst nach TLS-Freigabe gelesen.
- Die beiden Produktions-Geo-Filter bestehen repräsentative Such-/Reverse-Antworten mit ArduinoJson 7.4.3. Der JSON-Allocator hält weiterhin 3072 Bytes zurück.
- Bestehende Tests für Radar-Speicherschutz, Alterung/Erholung, Routenparser, Retry-After, progressive Anbieterpausen, Enrichment, Diagnose/RTC und Unicode bestehen.
- Displaytest: stabile bekannte Typnamen vor und nach Metadaten, einschließlich E75L/E75S und E2-Modelle; Breite höchstens 224 Pixel. Bestehende Displayzustände bestehen.
- WebKit: alle neun Breiten 320, 375, 390, 430, 560, 561, 768, 820 und 1024 Pixel bestehen.

Das offizielle Framework- und SCons-Archiv aus dem vorherigen Build wurde lokal wiederverwendet, weil Paketmirror teilweise falsche Downloads lieferten. Die offiziellen Versionsstände bleiben unverändert. Ausgelieferte platformio.ini und Workflow verwenden reguläre festgelegte Pakete.

## Grenzen

Kein physischer Würfel verfügbar. Reales LittleFS, TLS-Empfang und langandauernde Ortsabfragen sind auf Hardware zu prüfen. Unter 3 KiB Rest-Heap wird bewusst abgebrochen; erfolgreiche Ortsauflösung in jedem Betriebszustand ist nicht zugesagt. Temporäre Geo-Dateien verursachen Flash-Schreibvorgänge ausschließlich bei Ortsabfragen und werden nach dem Versuch gelöscht.

Der v0.4.11-Log mit HTTP 200 und anschließendem 6-Sekunden-IncompleteInput passt zum lokal reproduzierten Übertragungsfehler. Der zusätzliche Reboot bei 2400 Bytes Rest-Heap ist damit nicht abschließend erklärt. Die ELF-Zuordnung der Exception-Adressen ist kein vollständiger Stacktrace und kein Ursachenbeweis.

Radar-Datenbankzuordnungen können weiterhin falsch oder unvollständig sein. Bekannte Typcodes erhalten konsistente Displaynamen; unbekannte Typen behalten den bisherigen Fallback. Anbieterlimits und die unveränderte Datenalterung können weiterhin rote Radar-Anzeigen verursachen. Keine Änderungen an Radar-/Wetter-Abrufen und keine vollständige Rückkehr zu v0.4.9.
