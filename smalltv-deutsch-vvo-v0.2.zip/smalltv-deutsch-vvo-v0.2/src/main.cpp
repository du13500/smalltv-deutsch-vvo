
#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>
#include <WiFiClientSecureBearSSL.h>
#include <ESP8266WebServer.h>
#include <ESP8266HTTPUpdateServer.h>
#include <ESP8266mDNS.h>
#include <DNSServer.h>
#include <LittleFS.h>
#include <ArduinoJson.h>
#include <Arduino_GFX_Library.h>
#include <SPI.h>
#include <time.h>
#include "Vvo.h"

// -----------------------------------------------------------------------------
// SmallTV-Ultra hardware
// ESP8266 HW SPI: SCLK GPIO14, MOSI GPIO13
// Pin map based on the open-source smalltv-mod hardware definition.
// -----------------------------------------------------------------------------
#define TFT_DC   0
#define TFT_RST  2
#define TFT_CS   15
#define TFT_BL   5
#define TFT_W    240
#define TFT_H    240

#define FW_NAME    "SmallTV Deutsch/VVO"
#define FW_VERSION "0.2.0-vvo"

#define C_BLACK   0x0000
#define C_WHITE   0xFFFF
#define C_YELLOW  0xFFE0
#define C_RED     0xF800
#define C_GREEN   0x07E0
#define C_GRAY    0x8410
#define C_DGRAY   0x4208
#define C_BLUE    0x041F
#define C_CYAN    0x07FF

enum AppMode : uint8_t {
  MODE_DEPARTURES = 0,
  MODE_WEATHER    = 1,
  MODE_PLANE      = 2,
  MODE_CLOCK      = 3
};

struct Settings {
  String ssid;
  String pass;
  String hostname = "smalltv-dd";

  uint8_t mode = MODE_DEPARTURES;
  uint8_t brightness = 70;

  bool nightEnabled = true;
  uint16_t nightStart = 22 * 60;
  uint16_t nightEnd = 7 * 60;
  uint8_t nightBrightness = 12;

  String stopName = "Pohlandplatz";
  String stopId = "";
  uint8_t departureCount = 4;
  uint16_t departurePoll = 30;

  String weatherCity = "Dresden";
  float weatherLat = 51.0504f;
  float weatherLon = 13.7373f;
  uint16_t weatherPoll = 600;

  float planeLat = 51.0504f;
  float planeLon = 13.7373f;
  uint16_t planeRadiusKm = 25;
  uint16_t planePoll = 10;
};

static Settings cfg;
static ESP8266WebServer server(80);
static ESP8266HTTPUpdateServer updater;
static DNSServer dns;
static bool apMode = false;
static uint32_t lastSecond = 0;
static uint8_t lastMinute = 255;

// ---- ST7789 quirk -----------------------------------------------------------
class SmallTV_ST7789 : public Arduino_ST7789 {
 public:
  using Arduino_ST7789::Arduino_ST7789;
  bool begin(int32_t speed = GFX_NOT_DEFINED) override {
    _override_datamode = SPI_MODE3;
    return Arduino_TFT::begin(speed);
  }

  void setRotation(uint8_t r) override {
    Arduino_TFT::setRotation(r);
    uint8_t madctl;
    switch (_rotation) {
      case 1:  madctl = ST7789_MADCTL_MX | ST7789_MADCTL_MV; break;
      case 2:  madctl = ST7789_MADCTL_MX | ST7789_MADCTL_MY; break;
      case 3:  madctl = ST7789_MADCTL_MY | ST7789_MADCTL_MV; break;
      default: madctl = 0; break;
    }
    _bus->beginWrite();
    _bus->writeC8D8(ST7789_MADCTL, madctl); // RGB order
    _bus->endWrite();
  }
};

static Arduino_DataBus* bus = nullptr;
static Arduino_GFX* gfx = nullptr;

static const char WEBUI[] PROGMEM = R"HTML(
<!doctype html><html lang="de"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>SmallTV DD</title>
<style>
:root{--bg:#17191c;--card:#24272b;--card2:#2e3237;--text:#f4f4f4;--muted:#aeb4bb;--accent:#f3ce00;--red:#ff5d56;--green:#5dd78b;--border:#3b4047}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
.wrap{max-width:760px;margin:auto;padding:18px}.head{display:flex;justify-content:space-between;align-items:center;margin-bottom:16px}
h1{font-size:24px;margin:0}.chip{font-size:12px;color:#111;background:var(--accent);padding:6px 9px;border-radius:99px;font-weight:700}
nav{display:grid;grid-template-columns:repeat(5,1fr);gap:6px;margin-bottom:14px}.tab{border:0;background:var(--card);color:var(--muted);padding:10px 5px;border-radius:10px;font-size:12px}
.tab.on{background:var(--accent);color:#111;font-weight:700}.page{display:none}.page.on{display:block}
.card{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:16px;margin:10px 0}
h2{font-size:18px;margin:0 0 14px}.hint{font-size:12px;color:var(--muted);line-height:1.45}
label{display:block;font-size:13px;color:var(--muted);margin:11px 0 5px}
input,select{width:100%;background:#16181b;color:var(--text);border:1px solid #4a5058;border-radius:9px;padding:11px;font-size:15px}
.row{display:grid;grid-template-columns:1fr 1fr;gap:10px}.check{display:flex;gap:9px;align-items:center;color:var(--text);margin:12px 0}.check input{width:auto}
button.action,a.action{display:inline-block;border:0;border-radius:10px;background:var(--accent);color:#111;padding:11px 15px;font-weight:750;text-decoration:none}
button.sec,a.sec{background:var(--card2);color:var(--text)}button.danger{background:var(--red);color:#111}
.sticky{position:sticky;bottom:10px;padding-top:12px}.sticky button{width:100%;font-size:16px}
.status{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:12px;white-space:pre-wrap;color:#cdd2d8}.stopres{display:block;width:100%;text-align:left;margin:6px 0;padding:10px;border:1px solid var(--border);border-radius:9px;background:var(--card2);color:var(--text)}
input[type=range]{padding:4px}.val{color:var(--accent);font-weight:700}
@media(max-width:560px){nav{grid-template-columns:repeat(3,1fr)}.row{grid-template-columns:1fr}}
</style></head><body><div class="wrap">
<div class="head"><h1>SmallTV DD</h1><span class="chip">v0.1 TEST</span></div>
<nav>
<button class="tab on" data-p="anzeige">Anzeige</button>
<button class="tab" data-p="abfahrten">Abfahrten</button>
<button class="tab" data-p="wetter">Wetter</button>
<button class="tab" data-p="flugradar">Flugradar</button>
<button class="tab" data-p="system">System</button>
</nav>

<section id="anzeige" class="page on">
<div class="card"><h2>Aktive Ansicht</h2>
<label>Programm</label><select id="mode">
<option value="0">Abfahrten</option><option value="1">Wetter</option><option value="2">Flugradar</option><option value="3">Uhr</option>
</select>
<label>Helligkeit: <span class="val" id="brv"></span>%</label><input id="brightness" type="range" min="0" max="100">
</div>
<div class="card"><h2>Nachtmodus</h2>
<label class="check"><input id="nightEnabled" type="checkbox"> nachts dimmen</label>
<div class="row"><div><label>Beginn</label><input id="nightStart" type="time"></div><div><label>Ende</label><input id="nightEnd" type="time"></div></div>
<label>Nacht-Helligkeit: <span class="val" id="nbv"></span>%</label><input id="nightBrightness" type="range" min="0" max="100">
</div></section>

<section id="abfahrten" class="page">
<div class="card"><h2>Abfahrtsmonitor</h2>
<p class="hint">Die Abfahrten kommen direkt vom VVO. Suche deine Haltestelle, wähle sie aus und speichere anschließend die Einstellungen.</p>
<label>Haltestelle</label><input id="stopName" placeholder="z. B. Pohlandplatz">
<div style="margin-top:9px"><button class="action sec" type="button" onclick="searchStop()">Haltestelle suchen</button></div>
<div id="stopResults" style="margin-top:10px"></div>
<label>VVO-Haltestellen-ID</label><input id="stopId" readonly placeholder="noch keine Haltestelle gewählt">
<div class="row"><div><label>Anzahl Abfahrten</label><select id="departureCount"><option>3</option><option>4</option><option>5</option></select></div>
<div><label>Aktualisierung</label><select id="departurePoll"><option value="15">15 s</option><option value="30">30 s</option><option value="60">60 s</option></select></div></div>
</div></section>

<section id="wetter" class="page">
<div class="card"><h2>Wetter</h2>
<p class="hint">Geplant: aktuelle Temperatur, Tageshoch und Tagestief, Regenwahrscheinlichkeit sowie Sonnenaufgang und Sonnenuntergang. Keine Wind-Daten.</p>
<label>Ort</label><input id="weatherCity" placeholder="Dresden">
<div class="row"><div><label>Breitengrad</label><input id="weatherLat" type="number" step="0.0001"></div><div><label>Längengrad</label><input id="weatherLon" type="number" step="0.0001"></div></div>
<label>Aktualisierung</label><select id="weatherPoll"><option value="300">5 min</option><option value="600">10 min</option><option value="900">15 min</option></select>
</div></section>

<section id="flugradar" class="page">
<div class="card"><h2>Flugradar</h2>
<p class="hint">Geplant: nächstes relevantes Flugzeug mit Callsign, Airline, Route, Typ, Registrierung, Entfernung und Höhe.</p>
<div class="row"><div><label>Breitengrad</label><input id="planeLat" type="number" step="0.0001"></div><div><label>Längengrad</label><input id="planeLon" type="number" step="0.0001"></div></div>
<div class="row"><div><label>Radius</label><select id="planeRadiusKm"><option value="10">10 km</option><option value="25">25 km</option><option value="50">50 km</option><option value="100">100 km</option></select></div>
<div><label>Aktualisierung</label><select id="planePoll"><option value="5">5 s</option><option value="10">10 s</option><option value="15">15 s</option><option value="30">30 s</option></select></div></div>
</div></section>

<section id="system" class="page">
<div class="card"><h2>WLAN</h2>
<label>SSID</label><input id="ssid" autocomplete="off">
<label>Passwort</label><input id="pass" type="password" placeholder="leer = gespeichertes Passwort behalten">
<label>Hostname</label><input id="hostname">
</div>
<div class="card"><h2>Status</h2><div id="status" class="status">lade…</div></div>
<div class="card"><h2>Wartung</h2>
<a class="action sec" href="/update">Firmware-Update</a>
<button class="action sec" onclick="reboot()">Neustart</button>
</div></section>

<div class="sticky"><button class="action" onclick="save()">Einstellungen speichern</button></div>
</div>
<script>
const $=id=>document.getElementById(id);
document.querySelectorAll('.tab').forEach(b=>b.onclick=()=>{document.querySelectorAll('.tab,.page').forEach(x=>x.classList.remove('on'));b.classList.add('on');$(b.dataset.p).classList.add('on')});
function hhmm(m){let h=Math.floor(m/60)%24,mm=m%60;return String(h).padStart(2,'0')+':'+String(mm).padStart(2,'0')}
function mins(s){let p=(s||'00:00').split(':');return (+p[0])*60+(+p[1])}
brightness.oninput=()=>brv.textContent=brightness.value;nightBrightness.oninput=()=>nbv.textContent=nightBrightness.value;
async function load(){
 let c=await fetch('/api/config').then(r=>r.json());
 ['ssid','hostname','stopName','stopId','weatherCity'].forEach(k=>$(k).value=c[k]??'');
 ['mode','brightness','departureCount','departurePoll','weatherPoll','planeRadiusKm','planePoll'].forEach(k=>$(k).value=c[k]);
 ['weatherLat','weatherLon','planeLat','planeLon'].forEach(k=>$(k).value=c[k]);
 nightEnabled.checked=!!c.nightEnabled; nightStart.value=hhmm(c.nightStart); nightEnd.value=hhmm(c.nightEnd);
 nightBrightness.value=c.nightBrightness;brv.textContent=c.brightness;nbv.textContent=c.nightBrightness;
 statusNow();
}
async function searchStop(){
 const box=$('stopResults'), q=$('stopName').value.trim();
 if(q.length<2){box.innerHTML='<span class="hint">Bitte mindestens zwei Zeichen eingeben.</span>';return;}
 box.innerHTML='<span class="hint">suche beim VVO…</span>';
 try{
  const r=await fetch('/api/vvo/search?q='+encodeURIComponent(q));
  const d=await r.json();
  if(!r.ok||!d.ok) throw new Error(d.error||'VVO nicht erreichbar');
  if(!d.stops.length){box.innerHTML='<span class="hint">Keine Haltestelle gefunden.</span>';return;}
  box.innerHTML=d.stops.map((x,i)=>`<button class="stopres" type="button" data-i="${i}">${x.label}</button>`).join('');
  box.querySelectorAll('button').forEach((b,i)=>b.onclick=()=>{const x=d.stops[i];$('stopId').value=x.id;$('stopName').value=x.name;box.innerHTML='<span class="hint">Ausgewählt: '+x.label+'</span>';});
 }catch(e){box.innerHTML='<span class="hint" style="color:var(--red)">'+e.message+'</span>';}
}

async function save(){
 let o={ssid:ssid.value,pass:pass.value,hostname:hostname.value,mode:+mode.value,brightness:+brightness.value,
 nightEnabled:nightEnabled.checked,nightStart:mins(nightStart.value),nightEnd:mins(nightEnd.value),nightBrightness:+nightBrightness.value,
 stopName:stopName.value,stopId:stopId.value,departureCount:+departureCount.value,departurePoll:+departurePoll.value,
 weatherCity:weatherCity.value,weatherLat:+weatherLat.value,weatherLon:+weatherLon.value,weatherPoll:+weatherPoll.value,
 planeLat:+planeLat.value,planeLon:+planeLon.value,planeRadiusKm:+planeRadiusKm.value,planePoll:+planePoll.value};
 let r=await fetch('/api/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(o)}).then(r=>r.json());
 alert(r.reboot?'Gespeichert. WLAN geändert, Gerät startet neu.':'Gespeichert.');
 if(r.reboot)setTimeout(()=>location.reload(),7000);
}
async function statusNow(){try{let s=await fetch('/api/status').then(r=>r.json());status.textContent=
 `Firmware: ${s.fw} ${s.version}\nNetz: ${s.ssid||'-'}\nIP: ${s.ip}\nRSSI: ${s.rssi} dBm\nFreier Heap: ${s.heap} B\nUptime: ${s.uptime}s`;}catch(e){status.textContent='Status nicht erreichbar'}}
async function reboot(){await fetch('/api/reboot',{method:'POST'});setTimeout(()=>location.reload(),6000)}
load();setInterval(statusNow,5000);
</script></body></html>
)HTML";

// ---- helpers ----------------------------------------------------------------
static int textW(const String& s, uint8_t size) { return s.length() * 6 * size; }

static void centerText(const String& s, int y, uint8_t size, uint16_t color) {
  gfx->setTextSize(size);
  gfx->setTextColor(color);
  int x = (TFT_W - textW(s, size)) / 2;
  if (x < 0) x = 0;
  gfx->setCursor(x, y);
  gfx->print(s);
}

static String crop(const String& s, uint8_t maxChars) {
  if (s.length() <= maxChars) return s;
  if (maxChars < 2) return s.substring(0, maxChars);
  return s.substring(0, maxChars - 1) + ".";
}

static String timeHHMM() {
  time_t now = time(nullptr);
  if (now < 1609459200) return "--:--";
  struct tm t;
  localtime_r(&now, &t);
  char b[6];
  snprintf(b, sizeof(b), "%02d:%02d", t.tm_hour, t.tm_min);
  return String(b);
}

static bool nightWindow(uint16_t now, uint16_t start, uint16_t end) {
  if (start == end) return false;
  if (start < end) return now >= start && now < end;
  return now >= start || now < end;
}

static void applyBrightness() {
  uint8_t b = cfg.brightness;
  time_t now = time(nullptr);
  if (cfg.nightEnabled && now > 1609459200) {
    struct tm t; localtime_r(&now, &t);
    uint16_t m = t.tm_hour * 60 + t.tm_min;
    if (nightWindow(m, cfg.nightStart, cfg.nightEnd)) b = cfg.nightBrightness;
  }
  if (b > 100) b = 100;
  // SmallTV backlight is active-low.
  int duty = 255 - ((int)b * 255 / 100);
  analogWrite(TFT_BL, duty);
}

// ---- local config ------------------------------------------------------------
static const char* CFG_PATH = "/config.json";

static void saveConfig() {
  JsonDocument d;
  d["ssid"] = cfg.ssid;
  d["pass"] = cfg.pass;
  d["hostname"] = cfg.hostname;
  d["mode"] = cfg.mode;
  d["brightness"] = cfg.brightness;
  d["nightEnabled"] = cfg.nightEnabled;
  d["nightStart"] = cfg.nightStart;
  d["nightEnd"] = cfg.nightEnd;
  d["nightBrightness"] = cfg.nightBrightness;

  d["stopName"] = cfg.stopName;
  d["stopId"] = cfg.stopId;
  d["departureCount"] = cfg.departureCount;
  d["departurePoll"] = cfg.departurePoll;

  d["weatherCity"] = cfg.weatherCity;
  d["weatherLat"] = cfg.weatherLat;
  d["weatherLon"] = cfg.weatherLon;
  d["weatherPoll"] = cfg.weatherPoll;

  d["planeLat"] = cfg.planeLat;
  d["planeLon"] = cfg.planeLon;
  d["planeRadiusKm"] = cfg.planeRadiusKm;
  d["planePoll"] = cfg.planePoll;

  File f = LittleFS.open(CFG_PATH, "w");
  if (f) { serializeJson(d, f); f.close(); }
}

static void loadConfig() {
  if (!LittleFS.begin()) LittleFS.format(), LittleFS.begin();
  File f = LittleFS.open(CFG_PATH, "r");
  if (!f) return;
  JsonDocument d;
  if (deserializeJson(d, f)) { f.close(); return; }
  f.close();

  cfg.ssid = d["ssid"] | cfg.ssid;
  cfg.pass = d["pass"] | cfg.pass;
  cfg.hostname = d["hostname"] | cfg.hostname;
  cfg.mode = constrain((int)(d["mode"] | cfg.mode), 0, 3);
  cfg.brightness = constrain((int)(d["brightness"] | cfg.brightness), 0, 100);
  cfg.nightEnabled = d["nightEnabled"] | cfg.nightEnabled;
  cfg.nightStart = constrain((int)(d["nightStart"] | cfg.nightStart), 0, 1439);
  cfg.nightEnd = constrain((int)(d["nightEnd"] | cfg.nightEnd), 0, 1439);
  cfg.nightBrightness = constrain((int)(d["nightBrightness"] | cfg.nightBrightness), 0, 100);

  cfg.stopName = d["stopName"] | cfg.stopName;
  cfg.stopId = d["stopId"] | cfg.stopId;
  cfg.departureCount = constrain((int)(d["departureCount"] | cfg.departureCount), 3, 5);
  cfg.departurePoll = constrain((int)(d["departurePoll"] | cfg.departurePoll), 10, 300);

  cfg.weatherCity = d["weatherCity"] | cfg.weatherCity;
  cfg.weatherLat = d["weatherLat"] | cfg.weatherLat;
  cfg.weatherLon = d["weatherLon"] | cfg.weatherLon;
  cfg.weatherPoll = constrain((int)(d["weatherPoll"] | cfg.weatherPoll), 60, 3600);

  cfg.planeLat = d["planeLat"] | cfg.planeLat;
  cfg.planeLon = d["planeLon"] | cfg.planeLon;
  cfg.planeRadiusKm = constrain((int)(d["planeRadiusKm"] | cfg.planeRadiusKm), 1, 250);
  cfg.planePoll = constrain((int)(d["planePoll"] | cfg.planePoll), 3, 300);
}

// ---- display views -----------------------------------------------------------
static void drawFooter(const char* label) {
  gfx->drawFastHLine(8, 218, 224, C_DGRAY);
  gfx->setTextSize(1);
  gfx->setTextColor(C_GRAY);
  gfx->setCursor(8, 226);
  gfx->print(label);
  String tm = timeHHMM();
  gfx->setCursor(232 - textW(tm, 1), 226);
  gfx->print(tm);
}

static String displayAscii(String s) {
  s.replace("Dresden ", "");
  s.replace("Ä", "Ae"); s.replace("Ö", "Oe"); s.replace("Ü", "Ue");
  s.replace("ä", "ae"); s.replace("ö", "oe"); s.replace("ü", "ue"); s.replace("ß", "ss");
  return s;
}

static void drawDepartures() {
  gfx->fillScreen(C_BLACK);
  String title = crop(displayAscii(cfg.stopName.length() ? cfg.stopName : "HALTESTELLE"), 18);
  gfx->setTextSize(2); gfx->setTextColor(C_YELLOW); gfx->setCursor(8, 7); gfx->print(title);
  gfx->drawFastHLine(8, 29, 224, C_DGRAY);

  if (!cfg.stopId.length()) {
    centerText("HALTESTELLE", 78, 2, C_WHITE);
    centerText("IM WEBINTERFACE", 108, 2, C_GRAY);
    centerText("AUSWAEHLEN", 136, 2, C_GRAY);
    drawFooter("VVO NICHT KONFIGURIERT");
    return;
  }

  uint8_t n = vvoCount();
  if (!n) {
    if (vvoError()) {
      centerText("VVO", 82, 4, C_RED);
      centerText("nicht erreichbar", 128, 2, C_GRAY);
      drawFooter("VVO FEHLER");
    } else {
      centerText("VVO", 82, 4, C_YELLOW);
      centerText("lade Abfahrten...", 128, 2, C_GRAY);
      drawFooter("LIVE");
    }
    return;
  }

  if (n > cfg.departureCount) n = cfg.departureCount;
  int y0 = 41, step = (n >= 5 ? 34 : (n == 4 ? 42 : 52));
  for (uint8_t i = 0; i < n; i++) {
    const VvoDeparture& d = vvoAt(i);
    int y = y0 + i * step;
    String line = displayAscii(String(d.line));
    String dest = crop(displayAscii(String(d.direction)), 9);
    String right;
    uint16_t rightColor = C_WHITE;
    if (d.cancelled) { right = "AUS"; rightColor = C_RED; }
    else if (d.minutes < 0) { right = "?"; rightColor = C_GRAY; }
    else if (d.minutes <= 0) { right = "JETZT"; rightColor = C_GREEN; }
    else { right = String(d.minutes); rightColor = d.delayed ? C_YELLOW : C_WHITE; }

    uint8_t lineSize = line.length() <= 2 ? 3 : 2;
    gfx->setTextSize(lineSize); gfx->setTextColor(C_YELLOW); gfx->setCursor(8, y); gfx->print(line);
    gfx->setTextSize(2); gfx->setTextColor(C_WHITE); gfx->setCursor(62, y + 6); gfx->print(dest);
    uint8_t rs = (right == "JETZT") ? 1 : 2;
    gfx->setTextSize(rs); gfx->setTextColor(rightColor);
    gfx->setCursor(232 - textW(right, rs), y + (rs == 1 ? 10 : 6)); gfx->print(right);
  }
  drawFooter(vvoError() ? "LIVE / LETZTER STAND" : "VVO LIVE");
}

static void drawWeatherIconCloud(int cx, int cy) {
  gfx->fillCircle(cx-18, cy+4, 12, C_WHITE);
  gfx->fillCircle(cx, cy-5, 18, C_WHITE);
  gfx->fillCircle(cx+20, cy+4, 13, C_WHITE);
  gfx->fillRect(cx-27, cy+4, 56, 16, C_WHITE);
}

static void drawWeather() {
  gfx->fillScreen(C_BLACK);
  gfx->setTextSize(2); gfx->setTextColor(C_YELLOW); gfx->setCursor(8,7); gfx->print(crop(cfg.weatherCity,18));
  gfx->setTextSize(1); gfx->setTextColor(C_GRAY); gfx->setCursor(187,12); gfx->print(timeHHMM());

  drawWeatherIconCloud(120, 53);
  centerText("14", 82, 6, C_WHITE);
  gfx->setTextSize(2); gfx->setTextColor(C_GRAY); gfx->setCursor(177,101); gfx->print("C");
  centerText("BEWOELKT", 139, 2, C_WHITE);

  gfx->setTextSize(2); gfx->setTextColor(C_GRAY);
  gfx->setCursor(18,166); gfx->print("H 17");
  gfx->setCursor(142,166); gfx->print("T 9");

  gfx->setTextSize(1); gfx->setTextColor(C_CYAN); gfx->setCursor(18,193); gfx->print("REGEN 35%");
  gfx->setTextColor(C_GRAY); gfx->setCursor(126,193); gfx->print("07:08  18:42");
  drawFooter("TESTDATEN");
}

static void drawPlane() {
  gfx->fillScreen(C_BLACK);
  gfx->setTextSize(2); gfx->setTextColor(C_YELLOW); gfx->setCursor(8,7); gfx->print("IN DER NAEHE");
  gfx->drawFastHLine(8,29,224,C_DGRAY);

  centerText("EWG7AB", 42, 4, C_WHITE);
  centerText("Eurowings", 78, 2, C_GRAY);
  centerText("DRS > PMI", 103, 3, C_YELLOW);
  centerText("Airbus A320neo", 136, 2, C_WHITE);
  centerText("D-AENA", 160, 2, C_GRAY);

  gfx->setTextSize(2); gfx->setTextColor(C_CYAN); gfx->setCursor(14,191); gfx->print("8.2 km");
  String alt = "9750 m";
  gfx->setCursor(226-textW(alt,2),191); gfx->print(alt);
  drawFooter("TESTDATEN");
}

static void drawClock() {
  gfx->fillScreen(C_BLACK);
  gfx->setTextSize(2); gfx->setTextColor(C_YELLOW); gfx->setCursor(8,8); gfx->print("UHR");
  String t = timeHHMM();
  centerText(t, 84, 6, C_WHITE);
  time_t now = time(nullptr);
  if (now > 1609459200) {
    struct tm tmv; localtime_r(&now,&tmv);
    static const char* wd[]={"SO","MO","DI","MI","DO","FR","SA"};
    char b[32]; snprintf(b,sizeof(b),"%s  %02d.%02d.%04d",wd[tmv.tm_wday],tmv.tm_mday,tmv.tm_mon+1,tmv.tm_year+1900);
    centerText(b, 145, 2, C_GRAY);
  } else {
    centerText("warte auf NTP", 145, 2, C_GRAY);
  }
  drawFooter("EUROPE/BERLIN");
}

static void drawActive() {
  applyBrightness();
  switch (cfg.mode) {
    case MODE_WEATHER: drawWeather(); break;
    case MODE_PLANE:   drawPlane(); break;
    case MODE_CLOCK:   drawClock(); break;
    default:           drawDepartures(); break;
  }
}

// ---- network ----------------------------------------------------------------
static void startAP() {
  apMode = true;
  WiFi.mode(WIFI_AP);
  IPAddress ip(192,168,4,1);
  WiFi.softAPConfig(ip,ip,IPAddress(255,255,255,0));
  WiFi.softAP("SmallTV-Setup");
  dns.start(53,"*",ip);

  gfx->fillScreen(C_BLACK);
  centerText("SETUP", 55, 4, C_YELLOW);
  centerText("WLAN:", 105, 2, C_GRAY);
  centerText("SmallTV-Setup", 128, 2, C_WHITE);
  centerText("192.168.4.1", 174, 2, C_GREEN);
}

static void connectWiFi() {
  if (!cfg.ssid.length()) { startAP(); return; }
  WiFi.mode(WIFI_STA);
  WiFi.persistent(false);
  WiFi.hostname(cfg.hostname.c_str());
  WiFi.begin(cfg.ssid.c_str(), cfg.pass.c_str());
  gfx->fillScreen(C_BLACK);
  centerText("WLAN", 80, 4, C_YELLOW);
  centerText("verbinden...", 126, 2, C_GRAY);

  uint32_t start=millis();
  while(WiFi.status()!=WL_CONNECTED && millis()-start<18000){delay(200);yield();}
  if(WiFi.status()!=WL_CONNECTED){startAP();return;}

  apMode=false;
  if(MDNS.begin(cfg.hostname.c_str())) MDNS.addService("http","tcp",80);
  configTime("CET-1CEST,M3.5.0,M10.5.0/3","pool.ntp.org","time.cloudflare.com");
}

// ---- web API ----------------------------------------------------------------
static void sendJson(JsonDocument& d) {
  String out; serializeJson(d,out); server.send(200,"application/json",out);
}

static void apiGetConfig() {
  JsonDocument d;
  d["ssid"]=cfg.ssid; d["hostname"]=cfg.hostname;
  d["mode"]=cfg.mode; d["brightness"]=cfg.brightness;
  d["nightEnabled"]=cfg.nightEnabled; d["nightStart"]=cfg.nightStart; d["nightEnd"]=cfg.nightEnd; d["nightBrightness"]=cfg.nightBrightness;
  d["stopName"]=cfg.stopName; d["stopId"]=cfg.stopId; d["departureCount"]=cfg.departureCount; d["departurePoll"]=cfg.departurePoll;
  d["weatherCity"]=cfg.weatherCity; d["weatherLat"]=cfg.weatherLat; d["weatherLon"]=cfg.weatherLon; d["weatherPoll"]=cfg.weatherPoll;
  d["planeLat"]=cfg.planeLat; d["planeLon"]=cfg.planeLon; d["planeRadiusKm"]=cfg.planeRadiusKm; d["planePoll"]=cfg.planePoll;
  sendJson(d);
}

static void apiPostConfig() {
  if(!server.hasArg("plain")){server.send(400,"application/json","{\"ok\":false}");return;}
  JsonDocument d; if(deserializeJson(d,server.arg("plain"))){server.send(400,"application/json","{\"ok\":false}");return;}
  String oldSsid=cfg.ssid, oldHost=cfg.hostname;

  if(d["ssid"].is<const char*>()) cfg.ssid=d["ssid"].as<String>();
  if(d["pass"].is<const char*>()){String p=d["pass"].as<String>();if(p.length())cfg.pass=p;}
  if(d["hostname"].is<const char*>()) cfg.hostname=d["hostname"].as<String>();

  cfg.mode=constrain((int)(d["mode"]|cfg.mode),0,3);
  cfg.brightness=constrain((int)(d["brightness"]|cfg.brightness),0,100);
  cfg.nightEnabled=d["nightEnabled"]|cfg.nightEnabled;
  cfg.nightStart=constrain((int)(d["nightStart"]|cfg.nightStart),0,1439);
  cfg.nightEnd=constrain((int)(d["nightEnd"]|cfg.nightEnd),0,1439);
  cfg.nightBrightness=constrain((int)(d["nightBrightness"]|cfg.nightBrightness),0,100);

  if(d["stopName"].is<const char*>())cfg.stopName=d["stopName"].as<String>();
  if(d["stopId"].is<const char*>())cfg.stopId=d["stopId"].as<String>();
  cfg.departureCount=constrain((int)(d["departureCount"]|cfg.departureCount),3,5);
  cfg.departurePoll=constrain((int)(d["departurePoll"]|cfg.departurePoll),10,300);

  if(d["weatherCity"].is<const char*>())cfg.weatherCity=d["weatherCity"].as<String>();
  cfg.weatherLat=d["weatherLat"]|cfg.weatherLat; cfg.weatherLon=d["weatherLon"]|cfg.weatherLon;
  cfg.weatherPoll=constrain((int)(d["weatherPoll"]|cfg.weatherPoll),60,3600);

  cfg.planeLat=d["planeLat"]|cfg.planeLat; cfg.planeLon=d["planeLon"]|cfg.planeLon;
  cfg.planeRadiusKm=constrain((int)(d["planeRadiusKm"]|cfg.planeRadiusKm),1,250);
  cfg.planePoll=constrain((int)(d["planePoll"]|cfg.planePoll),3,300);

  saveConfig(); vvoReset(); drawActive();
  bool reboot=(oldSsid!=cfg.ssid)||(oldHost!=cfg.hostname);
  server.send(200,"application/json",reboot?"{\"ok\":true,\"reboot\":true}":"{\"ok\":true,\"reboot\":false}");
  if(reboot){delay(500);ESP.restart();}
}

static void apiStatus() {
  JsonDocument d;
  d["fw"]=FW_NAME;d["version"]=FW_VERSION;
  d["ssid"]=apMode?"SmallTV-Setup":WiFi.SSID();
  d["ip"]=apMode?WiFi.softAPIP().toString():WiFi.localIP().toString();
  d["rssi"]=apMode?0:WiFi.RSSI();
  d["heap"]=ESP.getFreeHeap();d["uptime"]=millis()/1000;
  d["vvoCount"]=vvoCount(); d["vvoError"]=vvoError();
  sendJson(d);
}

static void apiVvoSearch() {
  if (apMode || WiFi.status() != WL_CONNECTED) {
    server.send(503, "application/json", "{\"ok\":false,\"error\":\"Kein Internetzugang\"}");
    return;
  }
  String q = server.arg("q"); q.trim();
  if (q.length() < 2) {
    server.send(400, "application/json", "{\"ok\":false,\"error\":\"Suchbegriff zu kurz\"}");
    return;
  }
  String out;
  if (!vvoSearchStops(q, out)) {
    server.send(502, "application/json", "{\"ok\":false,\"error\":\"VVO-Suche fehlgeschlagen\"}");
    return;
  }
  server.send(200, "application/json; charset=utf-8", out);
}

static void setupWeb() {
  server.on("/",HTTP_GET,[]{server.send_P(200,"text/html; charset=utf-8",WEBUI);});
  server.on("/api/config",HTTP_GET,apiGetConfig);
  server.on("/api/config",HTTP_POST,apiPostConfig);
  server.on("/api/status",HTTP_GET,apiStatus);
  server.on("/api/vvo/search",HTTP_GET,apiVvoSearch);
  server.on("/api/reboot",HTTP_POST,[]{server.send(200,"application/json","{\"ok\":true}");delay(300);ESP.restart();});
  updater.setup(&server,"/update");
  server.onNotFound([](){
    if(apMode){server.sendHeader("Location","http://192.168.4.1/",true);server.send(302,"text/plain","");}
    else server.send(404,"text/plain","Nicht gefunden");
  });
  server.begin();
}

// ---- setup / loop ------------------------------------------------------------
void setup() {
  Serial.begin(115200);
  analogWriteRange(255);
  pinMode(TFT_BL,OUTPUT);

  bus = new Arduino_HWSPI(TFT_DC,TFT_CS);
  gfx = new SmallTV_ST7789(bus,TFT_RST,0,true,TFT_W,TFT_H,0,0,0,80);
  gfx->begin();
  gfx->setRotation(0);
  gfx->setTextWrap(false);
  gfx->fillScreen(C_BLACK);
  centerText("SmallTV DD",82,3,C_YELLOW);
  centerText(FW_VERSION,118,2,C_GRAY);

  loadConfig();
  applyBrightness();
  connectWiFi();
  setupWeb();

  if(!apMode){
    gfx->fillScreen(C_BLACK);
    centerText("VERBUNDEN",50,3,C_GREEN);
    centerText(WiFi.localIP().toString(),105,2,C_WHITE);
    centerText(cfg.hostname+".local",137,2,C_GRAY);
    delay(2200);
    drawActive();
  }
}

void loop() {
  server.handleClient();
  if(apMode) dns.processNextRequest();
  else MDNS.update();

  uint32_t now=millis();
  if(now-lastSecond>=1000){
    lastSecond=now;
    applyBrightness();
    if(cfg.mode==MODE_CLOCK){
      time_t ep=time(nullptr);
      if(ep>1609459200){
        struct tm t;localtime_r(&ep,&t);
        if(t.tm_min!=lastMinute){lastMinute=t.tm_min;drawClock();}
      }
    }
  }

  if(!apMode && cfg.mode==MODE_DEPARTURES && cfg.stopId.length() && vvoPollDue(cfg.departurePoll)){
    vvoFetchDepartures(cfg.stopId, cfg.departureCount);
    drawDepartures();
  }
  yield();
}
