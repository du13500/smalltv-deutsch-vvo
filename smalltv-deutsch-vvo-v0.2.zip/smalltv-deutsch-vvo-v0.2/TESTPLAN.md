# v0.2 Testplan

## Build-Gate

- PlatformIO-Build für `smalltv_ultra` muss grün sein
- Flash- und RAM-Nutzung dokumentieren
- `firmware.bin` als Actions-Artefakt erzeugen

## Nach dem ersten sicheren Flash

1. WLAN verbinden
2. Webinterface öffnen
3. unter Abfahrten nach `Pohlandplatz` suchen
4. Haltestelle auswählen und speichern
5. Live-Abfahrten mit VVO-App gegenprüfen
6. Ausfälle und Verspätungsdarstellung beobachten
7. mehrere Stunden laufen lassen und freien Heap beobachten

## Noch Testdaten

- Wetter
- Flugradar
