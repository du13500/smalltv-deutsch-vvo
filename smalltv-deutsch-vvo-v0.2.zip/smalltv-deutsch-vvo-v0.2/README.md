# SmallTV Deutsch/VVO

Eigene Firmware für den **GeekMagic SmallTV-Ultra** mit ESP8266 und 240×240-Display.

## v0.2

- deutsches lokales Webinterface
- WLAN + Fallback-Hotspot
- Helligkeit und Nachtmodus
- OTA-Firmwareupdate
- NTP-Uhr
- **VVO-Haltestellensuche direkt im Webinterface**
- **Live-Abfahrten direkt vom VVO**
- Echtzeit-Minuten
- `JETZT` für unmittelbar anstehende Fahrten
- `AUS` bei Ausfällen
- Wetter und Flugradar weiterhin als Testlayouts

## Ziel

Vier schlanke Ansichten ohne zusätzlichen Server:

1. Abfahrten
2. Wetter
3. Flugradar
4. Uhr

Der SmallTV läuft nach der Einrichtung nur mit USB-Strom und WLAN.

## Datenquellen

- Abfahrten: VVO WebAPI
- Wetter: Open-Meteo, folgt in v0.3
- Flugradar: ADS-B, folgt danach

## Hinweis

Noch nicht auf den SmallTV-Ultra flashen, bevor der v0.2-Build erfolgreich durchgelaufen ist und der Loader-/Recovery-Weg geprüft wurde.

## Basis

Display-Hardwarewissen basiert auf `giovi321/smalltv-mod` (WTFPL).
