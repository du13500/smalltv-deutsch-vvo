# SmallTV Deutsch/VVO v0.4.3 Testplan

## Vor dem Flash

- GitHub Actions muss grün sein.
- Build-Log auf Compilerfehler/-warnungen und RAM-/Flash-Auslastung prüfen.
- Firmwaredatei muss `smalltv-dd-v0.4.3-firmware.bin` heißen.
- Update von einer laufenden v0.4/v0.4.1 direkt per `/update`, **ohne Loader**.

## Smoke-Test nach OTA

1. Gerät startet und verbindet sich mit dem bisherigen WLAN.
2. Webinterface zeigt `SmallTV Deutsch/VVO` und v0.4.3.
3. Vorhandene Konfiguration wurde übernommen.
4. Display ist korrekt ausgerichtet, Backlight und Farben funktionieren.
5. `/update` bleibt erreichbar.

## Webinterface / Feedback

- Speichern erzeugt einen grünen Toast und **kein Browser-OK-Popup**.
- Validierungsfehler erscheinen als Toast statt `alert()`.
- Countdown Start/Stop zeigt Toasts.
- Neustart zeigt eine kurze Rückmeldung und führt danach zum Reload.
- Footer zeigt `SmallTV Deutsch/VVO · entwickelt von du13500 · GitHub`.
- GitHub-Link öffnet das Repository.

## Karten-Picker Wetter

- `Dresden` suchen und Treffer auswählen.
- Koordinaten werden übernommen.
- `Auf Karte auswählen` lädt Leaflet/OpenStreetMap erst bei Bedarf.
- Marker startet an den gespeicherten/ausgewählten Koordinaten.
- Klick auf die Karte aktualisiert Breitengrad/Längengrad sofort.
- Marker lässt sich ziehen; nach Drag-End werden die Koordinaten aktualisiert.
- Manuelle Änderung der Koordinaten bleibt möglich und bewegt bei offener Karte den Marker.
- Anzeigename bleibt unabhängig vom Kartenpunkt editierbar.
- Ohne Internet darf die Karte fehlschlagen, das übrige Webinterface muss weiter funktionieren.
- Es gibt **keinen** Button `Aktuelle Position` und keine Browser-Geolocation-Abhängigkeit mehr.

## Karten-Picker Flugradar

- Ort suchen, Karte öffnen, Radar-Mittelpunkt abweichend von der Ortsmitte setzen.
- Gespeicherte Koordinaten nach Reload prüfen.
- Flugradar verwendet anschließend den gewählten exakten Mittelpunkt.
- Wetter- und Radar-Koordinaten bleiben unabhängig voneinander.

## WLAN

- Netzwerke suchen.
- Doppelte SSIDs nur einmal.
- Sortierung stärkstes Netz zuerst.
- Balken und dBm plausibel.
- Klick übernimmt SSID.

## Anzeige / Rotation

- Nur eine Checkbox: Ansicht bleibt dauerhaft.
- Mehrere Checkboxen: Wechsel nach den eingestellten Zeiten.
- Datenrefresh und Ansichtswechsel laufen unabhängig.
- Countdown-Slots laufen weiter, auch wenn sie nicht sichtbar sind.

## Uhr

- Gelbe Überschrift `UHR` ist entfernt.
- Minutenwechsel erfolgt ohne sichtbares Fullscreen-Blinken.
- Große Uhrzeit und Datum werden korrekt aktualisiert.
- Footer-Uhr bleibt synchron.

## Countdown

- Tages-Countdown mehrere Minuten beobachten: **kein sekündliches Pulsieren/Blinken**.
- Tageswert wird erst bei tatsächlicher Änderung neu gezeichnet.
- HH:MM:SS und MM:SS laufen weiterhin sekündlich.
- Vor Ziel: Minus.
- Exakt Null: feste leere Vorzeichenspalte.
- Nach Ziel: Plus.
- Stromverlust/Neustart: absolute Zielzeiten bleiben korrekt.

## Umlaute / Wetter / VVO

- `Winterbergstraße`, `Bewölkt`, `Müll`, `Übung` prüfen.
- Wetterfarben sowie Sunrise/Sunset-Symbole unverändert korrekt.
- VVO-Verkehrsmittelfilter testen.
- Lange Linienbezeichnungen wie RE50/ICE 1650 prüfen.

## Flugradar

- Routenauflösung weiterhin testen, ohne Routen zu erfinden.
- Bekannte Linienflüge gegen externe Referenz gegenprüfen.
- Sonder-/Militärflug darf bei fehlender Route `N/A > N/A` zeigen.

## Flug-Tracker

- Bestehendes Verhalten regressionsprüfen.
- aviationstack bleibt optional und wird nur bei sichtbarer Tracker-Ansicht gepollt.

## Privacy-/Credit-Check

- Im Webinterface, README und LICENSE darf kein Klarname des Projektinhabers erscheinen.
- Sichtbarer Autoren-Credit ist ausschließlich `du13500`.
