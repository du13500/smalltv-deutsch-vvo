
#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>
#include <WiFiClientSecureBearSSL.h>
#include <ESP8266WebServer.h>
#include <ESP8266HTTPUpdateServer.h>
#include <ESP8266mDNS.h>
#include <DNSServer.h>
#include <LittleFS.h>
#include <ArduinoJson.h>
#include <Arduino_GFX_Library.h>
#include <SPI.h>
#include <time.h>
#include <ctype.h>
#include <stdlib.h>
#include "Vvo.h"
#include "Weather.h"
#include "Flight.h"
#include "TrackFlight.h"
#include "Geo.h"

// -----------------------------------------------------------------------------
// SmallTV-Ultra hardware
// ESP8266 HW SPI: SCLK GPIO14, MOSI GPIO13
// Pin map based on the open-source smalltv-mod hardware definition.
// -----------------------------------------------------------------------------
#define TFT_DC   0
#define TFT_RST  2
#define TFT_CS   15
#define TFT_BL   5
#define TFT_W    240
#define TFT_H    240

#define FW_NAME    "SmallTV DD"
#define FW_VERSION "0.4.3"

#define C_BLACK   0x0000
#define C_WHITE   0xFFFF
#define C_YELLOW  0xFFE0
#define C_RED     0xF800
#define C_GREEN   0x07E0
#define C_GRAY    0x8410
#define C_DGRAY   0x4208
#define C_BLUE    0x041F
#define C_CYAN    0x07FF

enum AppMode : uint8_t {
  MODE_DEPARTURES = 0,
  MODE_WEATHER    = 1,
  MODE_PLANE      = 2,
  MODE_CLOCK      = 3,
  MODE_TRACKED_FLIGHT = 4,
  MODE_COUNTDOWN1 = 5,
  MODE_COUNTDOWN2 = 6,
  MODE_COUNTDOWN3 = 7,
  MODE_COUNTDOWN4 = 8
};

enum CountdownType : uint8_t {
  COUNTDOWN_DAYS = 0,
  COUNTDOWN_HMS  = 1,
  COUNTDOWN_MS   = 2
};

struct CountdownSlot {
  String title = "";
  String titleColor = "#FFFFFF";
  String countColor = "#FF5D56";
  uint8_t type = COUNTDOWN_DAYS;
  String targetDate = "";        // YYYY-MM-DD, intentionally date-only
  uint32_t durationSec = 600;     // used for HMS / MS start/restart
  uint32_t targetEpoch = 0;       // absolute target for running duration timers
  bool active = false;
  uint8_t dayDigits = 3;          // keep leading zeroes stable once activated
};

struct Settings {
  String ssid;
  String pass;
  String hostname = "smalltv-dd";

  uint8_t mode = MODE_DEPARTURES; // current runtime view
  uint16_t rotationMask = (1U << MODE_DEPARTURES);
  uint16_t rotationSec[9] = {30,20,20,15,20,20,20,20,20};
  uint8_t brightness = 70;

  bool nightEnabled = true;
  uint16_t nightStart = 22 * 60;
  uint16_t nightEnd = 7 * 60;
  uint8_t nightBrightness = 12;

  String stopName = "Pohlandplatz";
  String stopId = "";
  uint8_t departureCount = 4;
  uint16_t departurePoll = 30;
  uint8_t vvoMotMask = VVO_MOT_ALL;

  String weatherCity = "Dresden"; // selected real place / fallback title
  String weatherDisplayName = ""; // optional display-only title
  float weatherLat = 51.0504f;
  float weatherLon = 13.7373f;
  uint16_t weatherPoll = 600;
  bool weatherTempColor = false;

  String planePlace = "Dresden";
  float planeLat = 51.0504f;
  float planeLon = 13.7373f;
  uint16_t planeRadiusKm = 25;
  uint16_t planePoll = 10;

  String trackedFlightNo = "";
  String aviationstackKey = "";
  uint16_t trackerStatusPollMin = 15;

  CountdownSlot countdown[4];
};

static Settings cfg;
static ESP8266WebServer server(80);
static ESP8266HTTPUpdateServer updater;
static DNSServer dns;
static bool apMode = false;
static uint32_t lastSecond = 0;
static uint8_t lastMinute = 255;
static uint32_t lastModeSwitchMs = 0;
static String lastCountdownRendered[4];

// ---- ST7789 quirk -----------------------------------------------------------
class SmallTV_ST7789 : public Arduino_ST7789 {
 public:
  using Arduino_ST7789::Arduino_ST7789;
  bool begin(int32_t speed = GFX_NOT_DEFINED) override {
    _override_datamode = SPI_MODE3;
    return Arduino_TFT::begin(speed);
  }

  void setRotation(uint8_t r) override {
    Arduino_TFT::setRotation(r);
    uint8_t madctl;
    switch (_rotation) {
      case 1:  madctl = ST7789_MADCTL_MX | ST7789_MADCTL_MV; break;
      case 2:  madctl = ST7789_MADCTL_MX | ST7789_MADCTL_MY; break;
      case 3:  madctl = ST7789_MADCTL_MY | ST7789_MADCTL_MV; break;
      default: madctl = 0; break;
    }
    _bus->beginWrite();
    _bus->writeC8D8(ST7789_MADCTL, madctl); // RGB order
    _bus->endWrite();
  }
};

static Arduino_DataBus* bus = nullptr;
static Arduino_GFX* gfx = nullptr;

static const char WEBUI[] PROGMEM = R"HTML(
<!doctype html><html lang="de"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>SmallTV Deutsch/VVO</title>
<style>
:root{--bg:#17191c;--card:#24272b;--card2:#2e3237;--text:#f4f4f4;--muted:#aeb4bb;--accent:#f3ce00;--red:#ff5d56;--green:#5dd78b;--border:#3b4047}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}.wrap{max-width:760px;margin:auto;padding:18px}.head{display:flex;justify-content:space-between;align-items:center;margin-bottom:16px}h1{font-size:24px;margin:0}.chip{font-size:12px;color:#111;background:var(--accent);padding:6px 9px;border-radius:99px;font-weight:700}
nav{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-bottom:14px}.tab{border:0;background:var(--card);color:var(--muted);padding:10px 5px;border-radius:10px;font-size:12px}.tab.on{background:var(--accent);color:#111;font-weight:700}.page{display:none}.page.on{display:block}.card{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:16px;margin:10px 0}h2{font-size:18px;margin:0 0 14px}.hint{font-size:12px;color:var(--muted);line-height:1.45}.mini{font-size:11px;color:var(--muted);margin-top:8px}label{display:block;font-size:13px;color:var(--muted);margin:11px 0 5px}input,select{width:100%;background:#16181b;color:var(--text);border:1px solid #4a5058;border-radius:9px;padding:11px;font-size:16px}.row{display:grid;grid-template-columns:1fr 1fr;gap:10px}.triple{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}.colorrow{display:grid;grid-template-columns:1fr 76px;gap:10px;align-items:end}
button.action,a.action{display:inline-block;border:0;border-radius:10px;background:var(--accent);color:#111;padding:11px 15px;font-weight:750;text-decoration:none;min-height:42px}button.sec,a.sec{background:var(--card2);color:var(--text)}button.danger{background:var(--red);color:#111}.actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}.sticky{position:sticky;bottom:10px;padding-top:12px}.sticky button{width:100%;font-size:16px}.status{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:12px;white-space:pre-wrap;color:#cdd2d8}.pickres{display:block;width:100%;text-align:left;margin:6px 0;padding:10px;border:1px solid var(--border);border-radius:9px;background:var(--card2);color:var(--text)}input[type=range]{padding:4px}input[type=color]{padding:3px;height:44px}.val{color:var(--accent);font-weight:700}.hidden{display:none}.checks{display:grid;grid-template-columns:repeat(2,1fr);gap:8px;margin-top:8px}.check{display:flex;align-items:center;gap:8px;background:#1d2024;border:1px solid var(--border);border-radius:9px;padding:9px;color:var(--text);margin:0}.check input{width:auto;margin:0}.modeRow{display:grid;grid-template-columns:1fr 110px;gap:10px;align-items:center;border-bottom:1px solid var(--border);padding:8px 0}.modeRow:last-child{border-bottom:0}.modeLeft{display:flex;align-items:center;gap:9px}.modeLeft input{width:auto}.wifirow{display:grid;grid-template-columns:1fr auto;gap:10px;align-items:center}.sig{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;color:var(--muted);float:right}.ok{color:var(--green)}.err{color:var(--red)}.mapwrap{margin-top:10px;border:1px solid var(--border);border-radius:12px;overflow:hidden;background:#16181b}.map{height:300px;width:100%}.mapnote{padding:8px 10px;font-size:11px;color:var(--muted);border-top:1px solid var(--border)}.footer{text-align:center;color:var(--muted);font-size:11px;line-height:1.5;padding:18px 6px 6px}.footer a{color:var(--muted)}.toast{position:fixed;z-index:9999;top:18px;left:50%;transform:translate(-50%,-18px);opacity:0;pointer-events:none;min-width:220px;max-width:min(90vw,520px);padding:14px 18px;border-radius:12px;font-weight:800;text-align:center;box-shadow:0 8px 28px #0008;transition:opacity .18s ease,transform .18s ease}.toast.show{opacity:1;transform:translate(-50%,0)}.toast.ok{background:var(--green);color:#0b1a10}.toast.err{background:var(--red);color:#200}.toast.warn{background:var(--accent);color:#111}
@media(max-width:560px){nav{grid-template-columns:repeat(3,1fr)}.row,.colorrow,.modeRow,.wifirow{grid-template-columns:1fr}.triple{grid-template-columns:repeat(3,1fr)}.checks{grid-template-columns:1fr}}
</style></head><body><div class="wrap">
<div class="head"><h1>SmallTV Deutsch/VVO</h1><span class="chip">v0.4.3</span></div>
<nav><button class="tab on" data-p="anzeige">Anzeige</button><button class="tab" data-p="abfahrten">Abfahrten</button><button class="tab" data-p="wetter">Wetter</button><button class="tab" data-p="flugradar">Flugradar</button><button class="tab" data-p="flugtracker">Flug-Tracker</button><button class="tab" data-p="countdown">Countdown</button><button class="tab" data-p="system">System</button></nav>

<section id="anzeige" class="page on">
<div class="card"><h2>Anzeigerotation</h2><p class="hint">Programme anhaken und je Ansicht die Anzeigedauer festlegen. Mit nur einem Haken bleibt die Ansicht dauerhaft stehen.</p><div id="modeRows"></div>
<label>Helligkeit: <span class="val" id="brv"></span>%</label><input id="brightness" type="range" min="0" max="100"></div>
<div class="card"><h2>Nachtmodus</h2><label class="check"><input id="nightEnabled" type="checkbox"> nachts dimmen</label><div class="row"><div><label>Beginn</label><input id="nightStart" type="time"></div><div><label>Ende</label><input id="nightEnd" type="time"></div></div><label>Nacht-Helligkeit: <span class="val" id="nbv"></span>%</label><input id="nightBrightness" type="range" min="0" max="100"></div>
</section>

<section id="abfahrten" class="page"><div class="card"><h2>Abfahrtsmonitor</h2><p class="hint">Live vom VVO. Haltestelle suchen, Treffer wählen und Verkehrsmittel auswählen.</p><label>Haltestelle</label><input id="stopName" placeholder="z. B. Pohlandplatz"><div class="actions"><button class="action sec" type="button" id="searchStopBtn">Haltestelle suchen</button></div><div id="stopResults"></div><label>VVO-Haltestellen-ID</label><input id="stopId" readonly placeholder="noch keine Haltestelle gewählt"><label>Verkehrsmittel</label><div class="checks"><label class="check"><input type="checkbox" id="motTrain"> Zug</label><label class="check"><input type="checkbox" id="motSuburban"> S-Bahn</label><label class="check"><input type="checkbox" id="motTram"> Straßenbahn</label><label class="check"><input type="checkbox" id="motBus"> Bus</label><label class="check"><input type="checkbox" id="motCable"> Seil-/Schwebebahn</label><label class="check"><input type="checkbox" id="motFerry"> Fähre</label><label class="check"><input type="checkbox" id="motTaxi"> AST / Rufbus</label></div><div class="row"><div><label>Anzahl Abfahrten</label><select id="departureCount"><option>3</option><option>4</option><option>5</option></select></div><div><label>Aktualisierung</label><select id="departurePoll"><option value="15">15 s</option><option value="30">30 s</option><option value="60">60 s</option></select></div></div></div></section>

<section id="wetter" class="page"><div class="card"><h2>Wetter</h2><p class="hint">Ort suchen und bei Bedarf den Punkt auf der Karte exakt verschieben. Die Karte benötigt Internetzugang im Browser.</p><label>Ort suchen</label><input id="weatherSearch" placeholder="z. B. Dresden oder 01237"><div class="actions"><button class="action sec" type="button" id="weatherSearchBtn">Suchen</button><button class="action sec" type="button" id="weatherMapBtn">Auf Karte auswählen</button></div><div id="weatherResults"></div><div id="weatherMapWrap" class="mapwrap hidden"><div id="weatherMap" class="map"></div><div class="mapnote">Kartenmaterial © OpenStreetMap-Mitwirkende. Auf die gewünschte Position tippen, um die Koordinaten zu übernehmen.</div></div><label>Ausgewählter Wetterort</label><input id="weatherCity" readonly><label>Anzeigename <span class="mini">optional, leer = gefundener Ortsname</span></label><input id="weatherDisplayName" placeholder="z. B. ZUHAUSE"><div class="row"><div><label>Breitengrad</label><input id="weatherLat" inputmode="decimal"></div><div><label>Längengrad</label><input id="weatherLon" inputmode="decimal"></div></div><label class="check"><input id="weatherTempColor" type="checkbox"> Aktuelle Temperatur farbig darstellen</label><label>Aktualisierung</label><select id="weatherPoll"><option value="300">5 min</option><option value="600">10 min</option><option value="900">15 min</option></select></div></section>

<section id="flugradar" class="page"><div class="card"><h2>Flugradar</h2><p class="hint">Live von adsb.lol. Ort suchen und den Beobachtungspunkt auf der Karte exakt setzen. Standort gilt nur für dieses Programm.</p><label>Ort suchen</label><input id="planeSearch" placeholder="z. B. Schönefeld"><div class="actions"><button class="action sec" type="button" id="planeSearchBtn">Suchen</button><button class="action sec" type="button" id="planeMapBtn">Auf Karte auswählen</button></div><div id="planeResults"></div><div id="planeMapWrap" class="mapwrap hidden"><div id="planeMap" class="map"></div><div class="mapnote">Kartenmaterial © OpenStreetMap-Mitwirkende. Auf die gewünschte Position tippen, um den Radar-Mittelpunkt zu setzen.</div></div><label>Ausgewählter Radar-Standort</label><input id="planePlace" readonly><div class="row"><div><label>Breitengrad</label><input id="planeLat" inputmode="decimal"></div><div><label>Längengrad</label><input id="planeLon" inputmode="decimal"></div></div><div class="row"><div><label>Radius</label><select id="planeRadiusKm"><option value="10">10 km</option><option value="25">25 km</option><option value="50">50 km</option><option value="100">100 km</option></select></div><div><label>Aktualisierung</label><select id="planePoll"><option value="5">5 s</option><option value="10">10 s</option><option value="15">15 s</option><option value="30">30 s</option></select></div></div></div></section>

<section id="flugtracker" class="page"><div class="card"><h2>Flug-Tracker</h2><p class="hint">Verfolgt genau einen Flug. Plan-/Ist-Zeiten kommen von aviationstack; Höhe und Geschwindigkeit während des Fluges zusätzlich über adsb.lol.</p><label>Flugnummer</label><input id="trackedFlightNo" placeholder="z. B. AF1234" autocapitalize="characters"><label>aviationstack API-Key</label><input id="aviationstackKey" type="password" autocomplete="off" placeholder="API-Key eintragen"><label>Status-Aktualisierung</label><select id="trackerStatusPollMin"><option value="10">10 min</option><option value="15">15 min</option><option value="30">30 min</option><option value="60">60 min</option></select><p class="mini">Statusabfragen laufen sparsam und nur, wenn der Tracker tatsächlich angezeigt wird.</p></div></section>

<section id="countdown" class="page"><p class="hint">Vier dauerhaft gespeicherte Slots. Tages-Countdowns sind reine Kalendertage; Zeit-Countdowns laufen nach Null automatisch mit Plus weiter.</p><div id="countdownSlots"></div></section>

<section id="system" class="page"><div class="card"><h2>WLAN</h2><div class="actions"><button class="action sec" type="button" id="wifiScanBtn">Netzwerke suchen</button></div><div id="wifiResults"></div><label>SSID</label><input id="ssid" autocomplete="off"><label>Passwort</label><input id="pass" type="password" placeholder="leer = gespeichertes Passwort behalten"><label>Hostname</label><input id="hostname"></div><div class="card"><h2>Status</h2><div id="status" class="status">lade…</div></div><div class="card"><h2>Wartung</h2><a class="action sec" href="/update">Firmware-Update</a> <button class="action sec" type="button" id="rebootBtn">Neustart</button></div></section>
<div class="sticky"><button class="action" type="button" id="saveBtn">Einstellungen speichern</button></div><footer class="footer">SmallTV Deutsch/VVO · entwickelt von du13500 · <a href="https://github.com/du13500/smalltv-deutsch-vvo" target="_blank" rel="noopener">GitHub</a></footer></div><div id="toast" class="toast" role="status" aria-live="polite"></div>
<script>
const $=id=>document.getElementById(id),clamp=(n,a,b)=>Math.max(a,Math.min(b,Number(n)||0));
const modeNames=['Abfahrten','Wetter','Flugradar','Uhr','Flug-Tracker','Countdown 1','Countdown 2','Countdown 3','Countdown 4'];
const modeDefaults=[30,20,20,15,20,20,20,20,20];
function friendly(e){if(e&&e.userMessage)return e.userMessage;if(e instanceof TypeError||String(e).includes('fetch'))return 'Verbindung zum SmallTV fehlgeschlagen. Ist der Würfel eingeschaltet und mit dem WLAN verbunden?';return e?.message||'Unbekannter Fehler.'}
async function fetchJson(url,opt){let r;try{r=await fetch(url,opt)}catch(e){let x=new Error();x.userMessage='Verbindung zum SmallTV fehlgeschlagen. Ist der Würfel eingeschaltet und mit dem WLAN verbunden?';throw x}let d={};try{d=await r.json()}catch(e){}if(!r.ok||d.ok===false){let x=new Error();x.userMessage=d.error||('Anfrage fehlgeschlagen ('+r.status+').');throw x}return d}
function showBox(id,msg,err=false){$(id).innerHTML='<span class="hint '+(err?'err':'')+'">'+msg+'</span>'}
let toastTimer;function toast(msg,type='ok',ms=2200){const t=$('toast');clearTimeout(toastTimer);t.textContent=msg;t.className='toast '+type+' show';toastTimer=setTimeout(()=>t.classList.remove('show'),ms)}
const maps={weather:null,plane:null},markers={weather:null,plane:null};let leafletPromise=null;
function loadLeaflet(){if(window.L)return Promise.resolve();if(leafletPromise)return leafletPromise;leafletPromise=new Promise((resolve,reject)=>{if(!document.querySelector('link[data-leaflet]')){let l=document.createElement('link');l.rel='stylesheet';l.href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';l.dataset.leaflet='1';document.head.appendChild(l)}let sc=document.createElement('script');sc.src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';sc.onload=resolve;sc.onerror=()=>{leafletPromise=null;reject(new Error('Leaflet konnte nicht geladen werden'))};document.head.appendChild(sc)});return leafletPromise}
function parseCoord(v){return Number(String(v??'').trim().replace(',','.'))}function coords(kind){return[parseCoord($(kind+'Lat').value),parseCoord($(kind+'Lon').value)]}
function setMapPoint(kind,lat,lon,center=true){if(!Number.isFinite(lat)||!Number.isFinite(lon))return;$(kind+'Lat').value=lat.toFixed(5);$(kind+'Lon').value=lon.toFixed(5);if(maps[kind]){markers[kind].setLatLng([lat,lon]);if(center)maps[kind].setView([lat,lon],Math.max(maps[kind].getZoom(),14))}}
async function ensureMap(kind){await loadLeaflet();let [lat,lon]=coords(kind);if(!Number.isFinite(lat)||!Number.isFinite(lon)){lat=51.0504;lon=13.7373}if(!maps[kind]){const m=L.map(kind+'Map').setView([lat,lon],14);L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap-Mitwirkende</a>'}).addTo(m);const marker=L.marker([lat,lon],{draggable:true}).addTo(m);const picked=p=>{setMapPoint(kind,p.lat,p.lng,false);marker.setLatLng(p);showBox(kind+'Results','Kartenposition übernommen: '+p.lat.toFixed(5)+', '+p.lng.toFixed(5))};m.on('click',e=>picked(e.latlng));marker.on('dragend',()=>picked(marker.getLatLng()));maps[kind]=m;markers[kind]=marker}else{maps[kind].setView([lat,lon],maps[kind].getZoom());markers[kind].setLatLng([lat,lon])}setTimeout(()=>maps[kind].invalidateSize(),50)}
async function toggleMap(kind){const w=$(kind+'MapWrap'),opening=w.classList.contains('hidden');w.classList.toggle('hidden',!opening);if(!opening)return;showBox(kind+'Results','Karte wird geladen…');try{await ensureMap(kind);showBox(kind+'Results','Auf die gewünschte Position in der Karte tippen.')}catch(e){w.classList.add('hidden');showBox(kind+'Results','Karte konnte nicht geladen werden. Bitte Internetverbindung prüfen oder Koordinaten manuell eingeben.',true)}}
function syncMapFromInputs(kind){let [lat,lon]=coords(kind);if(Number.isFinite(lat)&&Number.isFinite(lon)&&maps[kind]){markers[kind].setLatLng([lat,lon]);maps[kind].setView([lat,lon],maps[kind].getZoom())}}
document.querySelectorAll('.tab').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.tab,.page').forEach(x=>x.classList.remove('on'));b.classList.add('on');$(b.dataset.p).classList.add('on')}));
function hhmm(m){let h=Math.floor(m/60)%24,mm=m%60;return String(h).padStart(2,'0')+':'+String(mm).padStart(2,'0')}function mins(s){let p=(s||'00:00').split(':');return (+p[0])*60+(+p[1])}
function buildModeRows(){let h='';modeNames.forEach((n,i)=>h+=`<div class="modeRow"><label class="modeLeft"><input type="checkbox" id="modeOn${i}"><span>${n}</span></label><select id="modeSec${i}"><option value="10">10 s</option><option value="15">15 s</option><option value="20">20 s</option><option value="30">30 s</option><option value="45">45 s</option><option value="60">60 s</option></select></div>`);$('modeRows').innerHTML=h}
function buildCountdownCards(){const root=$('countdownSlots');let html='';for(let i=0;i<4;i++)html+=`<div class="card"><h2>Countdown ${i+1}</h2><div class="colorrow"><div><label>Optionaler Titel</label><input id="cdTitle${i}" maxlength="24" placeholder="z. B. URLAUB"></div><div><label>Titelfarbe</label><input id="cdTitleColor${i}" type="color" value="#ffffff"></div></div><label>Timer-Art</label><select id="cdType${i}"><option value="0">Tage</option><option value="1">Stunden : Minuten : Sekunden</option><option value="2">Minuten : Sekunden</option></select><div id="cdDays${i}"><label>Zieltag</label><input id="cdDate${i}" type="date"></div><div id="cdHms${i}" class="triple hidden"><div><label>Stunden</label><input id="cdH${i}" type="number" min="0" max="999" value="0"></div><div><label>Minuten</label><input id="cdM${i}" type="number" min="0" max="59" value="10"></div><div><label>Sekunden</label><input id="cdS${i}" type="number" min="0" max="59" value="0"></div></div><div id="cdMs${i}" class="row hidden"><div><label>Minuten</label><input id="cdOnlyM${i}" type="number" min="0" max="9999" value="10"></div><div><label>Sekunden</label><input id="cdOnlyS${i}" type="number" min="0" max="59" value="0"></div></div><div class="colorrow"><div><label>Countdown-Farbe</label><span class="mini" id="cdStatus${i}">inaktiv</span></div><div><label>Farbe</label><input id="cdCountColor${i}" type="color" value="#ff5d56"></div></div><div class="actions"><button type="button" class="action" id="cdStart${i}">Start / aktivieren</button><button type="button" class="action sec" id="cdStop${i}">Stoppen</button></div></div>`;root.innerHTML=html;for(let i=0;i<4;i++){$(`cdType${i}`).addEventListener('change',()=>updateCdFields(i));$(`cdStart${i}`).addEventListener('click',()=>countdownAction(i,'start'));$(`cdStop${i}`).addEventListener('click',()=>countdownAction(i,'stop'))}}
function updateCdFields(i){let t=+$(`cdType${i}`).value;$(`cdDays${i}`).classList.toggle('hidden',t!==0);$(`cdHms${i}`).classList.toggle('hidden',t!==1);$(`cdMs${i}`).classList.toggle('hidden',t!==2)}
function countdownPayload(i){let t=+$(`cdType${i}`).value,d=0;if(t===1)d=clamp($(`cdH${i}`).value,0,999)*3600+clamp($(`cdM${i}`).value,0,59)*60+clamp($(`cdS${i}`).value,0,59);if(t===2)d=clamp($(`cdOnlyM${i}`).value,0,9999)*60+clamp($(`cdOnlyS${i}`).value,0,59);return{title:$(`cdTitle${i}`).value,titleColor:$(`cdTitleColor${i}`).value,countColor:$(`cdCountColor${i}`).value,type:t,targetDate:$(`cdDate${i}`).value,durationSec:d}}
function loadCountdown(i,c){$(`cdTitle${i}`).value=c.title||'';$(`cdTitleColor${i}`).value=c.titleColor||'#ffffff';$(`cdCountColor${i}`).value=c.countColor||'#ff5d56';$(`cdType${i}`).value=c.type??0;$(`cdDate${i}`).value=c.targetDate||'';let d=Number(c.durationSec||0),h=Math.floor(d/3600),m=Math.floor((d%3600)/60),sec=d%60;$(`cdH${i}`).value=h;$(`cdM${i}`).value=m;$(`cdS${i}`).value=sec;$(`cdOnlyM${i}`).value=Math.floor(d/60);$(`cdOnlyS${i}`).value=sec;$(`cdStatus${i}`).textContent=c.active?'aktiv':'inaktiv';updateCdFields(i)}
async function countdownAction(i,action){let body=countdownPayload(i);body.slot=i;body.action=action;try{await fetchJson('/api/countdown',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});await load();toast(action==='start'?'Countdown gestartet':'Countdown gestoppt')}catch(e){try{let c=await load();let wanted=action==='start';if(c?.countdowns?.[i]?.active===wanted){toast(action==='start'?'Countdown gestartet':'Countdown gestoppt');return}}catch(_){}toast(friendly(e),'err',4200)}}
$('brightness').addEventListener('input',()=> $('brv').textContent=$('brightness').value);$('nightBrightness').addEventListener('input',()=> $('nbv').textContent=$('nightBrightness').value);
async function load(){try{let c=await fetchJson('/api/config');['ssid','hostname','stopName','stopId','weatherCity','weatherDisplayName','planePlace','trackedFlightNo'].forEach(k=>{if($(k))$(k).value=c[k]??''});['brightness','departureCount','departurePoll','weatherPoll','planeRadiusKm','planePoll','trackerStatusPollMin'].forEach(k=>$(k).value=c[k]);['weatherLat','weatherLon','planeLat','planeLon'].forEach(k=>$(k).value=Number(c[k]).toFixed(4));$('weatherSearch').value=c.weatherCity||'';$('planeSearch').value=c.planePlace||'';$('nightEnabled').checked=!!c.nightEnabled;$('nightStart').value=hhmm(c.nightStart);$('nightEnd').value=hhmm(c.nightEnd);$('nightBrightness').value=c.nightBrightness;$('weatherTempColor').checked=!!c.weatherTempColor;$('brv').textContent=c.brightness;$('nbv').textContent=c.nightBrightness;let mask=Number(c.rotationMask||0),secs=c.rotationSec||modeDefaults;for(let i=0;i<9;i++){$(`modeOn${i}`).checked=!!(mask&(1<<i));$(`modeSec${i}`).value=secs[i]||modeDefaults[i]}let mm=Number(c.vvoMotMask??127);$('motTrain').checked=!!(mm&1);$('motSuburban').checked=!!(mm&2);$('motTram').checked=!!(mm&4);$('motBus').checked=!!(mm&8);$('motCable').checked=!!(mm&16);$('motFerry').checked=!!(mm&32);$('motTaxi').checked=!!(mm&64);$('aviationstackKey').value='';$('aviationstackKey').placeholder=c.aviationstackKeySet?'API-Key gespeichert, leer = behalten':'API-Key eintragen';(c.countdowns||[]).forEach((x,i)=>{if(i<4)loadCountdown(i,x)});statusNow();return c}catch(e){toast(friendly(e),'err',4200);throw e}}
async function searchStop(){const box=$('stopResults'),q=$('stopName').value.trim();if(q.length<2){showBox('stopResults','Bitte mindestens zwei Zeichen eingeben.');return}showBox('stopResults','suche beim VVO…');try{const d=await fetchJson('/api/vvo/search?q='+encodeURIComponent(q));if(!d.stops.length){showBox('stopResults','Keine Haltestelle gefunden.');return}box.innerHTML=d.stops.map((x,i)=>`<button class="pickres" type="button" data-i="${i}">${x.label}</button>`).join('');box.querySelectorAll('button').forEach((b,i)=>b.addEventListener('click',()=>{const x=d.stops[i];$('stopId').value=x.id;$('stopName').value=x.name;showBox('stopResults','Ausgewählt: '+x.label)}))}catch(e){showBox('stopResults',friendly(e),true)}}
async function searchPlace(kind){const q=$(kind+'Search').value.trim(),box=$(kind+'Results');if(q.length<2){showBox(kind+'Results','Bitte mindestens zwei Zeichen eingeben.');return}showBox(kind+'Results','suche Ort…');try{const d=await fetchJson('/api/geo/search?q='+encodeURIComponent(q));if(!d.places?.length){showBox(kind+'Results','Kein Ort gefunden.');return}box.innerHTML=d.places.map((x,i)=>`<button class="pickres" type="button" data-i="${i}">${x.label}<span class="sig">${Number(x.lat).toFixed(4)}, ${Number(x.lon).toFixed(4)}</span></button>`).join('');box.querySelectorAll('button').forEach((b,i)=>b.addEventListener('click',()=>{const x=d.places[i];if(kind==='weather')$('weatherCity').value=x.name;else $('planePlace').value=x.name;setMapPoint(kind,Number(x.lat),Number(x.lon),true);showBox(kind+'Results','Ausgewählt: '+x.label+(maps[kind]?' · Marker auf Ortsmitte gesetzt':''))}))}catch(e){showBox(kind+'Results',friendly(e),true)}}
function signalBars(r){return r>=-50?'▁▂▄▆█':r>=-60?'▁▂▄▆':r>=-70?'▁▂▄':r>=-80?'▁▂':'▁'}
async function scanWifi(){showBox('wifiResults','suche WLAN-Netze…');try{let d=await fetchJson('/api/wifi/scan'),best=new Map();(d.networks||[]).forEach(n=>{if(!n.ssid)return;let o=best.get(n.ssid);if(!o||n.rssi>o.rssi)best.set(n.ssid,n)});let a=[...best.values()].sort((x,y)=>y.rssi-x.rssi);if(!a.length){showBox('wifiResults','Keine WLAN-Netze gefunden.');return}$('wifiResults').innerHTML=a.map((n,i)=>`<button class="pickres" type="button" data-i="${i}">${n.open?'○':'●'} ${n.ssid}<span class="sig">${signalBars(n.rssi)} ${n.rssi} dBm</span></button>`).join('');$('wifiResults').querySelectorAll('button').forEach((b,i)=>b.addEventListener('click',()=>{$('ssid').value=a[i].ssid;showBox('wifiResults','Ausgewählt: '+a[i].ssid)}))}catch(e){showBox('wifiResults',friendly(e),true)}}
async function save(){let mask=0,rotationSec=[];for(let i=0;i<9;i++){if($(`modeOn${i}`).checked)mask|=1<<i;rotationSec.push(+$(`modeSec${i}`).value)}if(!mask){toast('Bitte mindestens ein Programm für die Anzeige auswählen.','warn',3500);return}let mot=($('motTrain').checked?1:0)|($('motSuburban').checked?2:0)|($('motTram').checked?4:0)|($('motBus').checked?8:0)|($('motCable').checked?16:0)|($('motFerry').checked?32:0)|($('motTaxi').checked?64:0);if(!mot){toast('Bitte mindestens ein Verkehrsmittel auswählen.','warn',3500);return}let [wlat,wlon]=coords('weather'),[plat,plon]=coords('plane');if(!Number.isFinite(wlat)||wlat<-90||wlat>90||!Number.isFinite(wlon)||wlon<-180||wlon>180){toast('Bitte gültige Wetter-Koordinaten eingeben.','warn',3500);return}if(!Number.isFinite(plat)||plat<-90||plat>90||!Number.isFinite(plon)||plon<-180||plon>180){toast('Bitte gültige Flugradar-Koordinaten eingeben.','warn',3500);return}let o={ssid:$('ssid').value,pass:$('pass').value,hostname:$('hostname').value,rotationMask:mask,rotationSec,brightness:+$('brightness').value,nightEnabled:$('nightEnabled').checked,nightStart:mins($('nightStart').value),nightEnd:mins($('nightEnd').value),nightBrightness:+$('nightBrightness').value,stopName:$('stopName').value,stopId:$('stopId').value,departureCount:+$('departureCount').value,departurePoll:+$('departurePoll').value,vvoMotMask:mot,weatherCity:$('weatherCity').value,weatherDisplayName:$('weatherDisplayName').value,weatherLat:wlat,weatherLon:wlon,weatherPoll:+$('weatherPoll').value,weatherTempColor:$('weatherTempColor').checked,planePlace:$('planePlace').value,planeLat:plat,planeLon:plon,planeRadiusKm:+$('planeRadiusKm').value,planePoll:+$('planePoll').value,trackedFlightNo:$('trackedFlightNo').value,aviationstackKey:$('aviationstackKey').value,trackerStatusPollMin:+$('trackerStatusPollMin').value,countdowns:[0,1,2,3].map(countdownPayload)};try{let r=await fetchJson('/api/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(o)});toast(r.reboot?'Gespeichert · SmallTV startet neu':'✓ Einstellungen gespeichert','ok',r.reboot?5500:2200);if(r.reboot)setTimeout(()=>location.reload(),7000);else await load()}catch(e){toast(friendly(e),'err',4200)}}
async function statusNow(){try{let s=await fetchJson('/api/status');$('status').textContent=`Firmware: ${s.fw} ${s.version}\nNetz: ${s.ssid||'-'}\nIP: ${s.ip}\nRSSI: ${s.rssi} dBm\nFreier Heap: ${s.heap} B\nUptime: ${s.uptime}s\nTracker: ${s.trackerValid?'Daten vorhanden':(s.trackerError?'Fehler':'bereit')}`}catch(e){$('status').textContent='SmallTV derzeit nicht erreichbar.'}}
async function reboot(){toast('SmallTV startet neu…','ok',5000);try{await fetch('/api/reboot',{method:'POST'})}catch(e){}setTimeout(()=>location.reload(),6000)}
buildModeRows();buildCountdownCards();$('searchStopBtn').addEventListener('click',searchStop);$('weatherSearchBtn').addEventListener('click',()=>searchPlace('weather'));$('planeSearchBtn').addEventListener('click',()=>searchPlace('plane'));$('weatherMapBtn').addEventListener('click',()=>toggleMap('weather'));$('planeMapBtn').addEventListener('click',()=>toggleMap('plane'));['weather','plane'].forEach(k=>{ $(k+'Lat').addEventListener('change',()=>syncMapFromInputs(k));$(k+'Lon').addEventListener('change',()=>syncMapFromInputs(k))});$('wifiScanBtn').addEventListener('click',scanWifi);$('saveBtn').addEventListener('click',save);$('rebootBtn').addEventListener('click',reboot);load();setInterval(statusNow,5000);
</script></body></html>
)HTML";


// ---- helpers ----------------------------------------------------------------
static bool nextCodepoint(const String& s, size_t& i, uint16_t& cp) {
  if (i >= s.length()) return false;
  uint8_t c = (uint8_t)s[i++];
  if (c < 0x80) { cp = c; return true; }
  if ((c & 0xE0) == 0xC0 && i < s.length()) {
    uint8_t c2 = (uint8_t)s[i++];
    cp = ((uint16_t)(c & 0x1F) << 6) | (uint16_t)(c2 & 0x3F);
    return true;
  }
  cp = '?';
  while (i < s.length() && (((uint8_t)s[i] & 0xC0) == 0x80)) i++;
  return true;
}

static uint16_t glyphCount(const String& s) {
  uint16_t n=0,cp=0; size_t i=0;
  while(nextCodepoint(s,i,cp)) n++;
  return n;
}

static const uint8_t* specialGlyph(uint16_t cp) {
  // 5x7 rows, same cell geometry as the built-in pixel font.
  static const uint8_t ae[7] = {0x0A,0x00,0x0E,0x01,0x0F,0x11,0x0F};
  static const uint8_t oe[7] = {0x0A,0x00,0x0E,0x11,0x11,0x11,0x0E};
  static const uint8_t ue[7] = {0x0A,0x00,0x11,0x11,0x11,0x13,0x0D};
  static const uint8_t AE[7] = {0x0A,0x0E,0x11,0x11,0x1F,0x11,0x11};
  static const uint8_t OE[7] = {0x0A,0x0E,0x11,0x11,0x11,0x11,0x0E};
  static const uint8_t UE[7] = {0x0A,0x11,0x11,0x11,0x11,0x11,0x0E};
  static const uint8_t sz[7] = {0x0E,0x11,0x1E,0x11,0x11,0x1E,0x10};
  switch(cp){case 0x00E4:return ae;case 0x00F6:return oe;case 0x00FC:return ue;case 0x00C4:return AE;case 0x00D6:return OE;case 0x00DC:return UE;case 0x00DF:return sz;default:return nullptr;}
}

static void drawSpecialGlyph(int x,int y,uint8_t size,const uint8_t rows[7],uint16_t color) {
  for(uint8_t ry=0;ry<7;ry++) for(uint8_t rx=0;rx<5;rx++) if(rows[ry]&(1U<<(4-rx))) gfx->fillRect(x+rx*size,y+ry*size,size,size,color);
}

static void printDisplayTextAt(int x,int y,const String& s,uint8_t size,uint16_t color) {
  gfx->setTextSize(size); gfx->setTextColor(color);
  size_t i=0; uint16_t cp=0;
  while(nextCodepoint(s,i,cp)) {
    const uint8_t* g=specialGlyph(cp);
    if(g) drawSpecialGlyph(x,y,size,g,color);
    else { gfx->setCursor(x,y); gfx->write((uint8_t)(cp<128?cp:'?')); }
    x += 6*size;
  }
}

static int textW(const String& s, uint8_t size) { return glyphCount(s) * 6 * size; }

static void centerText(const String& s, int y, uint8_t size, uint16_t color) {
  int x = (TFT_W - textW(s, size)) / 2;
  if (x < 0) x = 0;
  printDisplayTextAt(x,y,s,size,color);
}

static String crop(const String& s, uint8_t maxChars) {
  if (glyphCount(s) <= maxChars) return s;
  if (maxChars < 2) return "";
  size_t i=0,end=0; uint16_t cp=0; uint8_t n=0;
  while(i<s.length() && n<maxChars-1){size_t before=i;if(!nextCodepoint(s,i,cp))break;end=i;n++;(void)before;}
  return s.substring(0,end)+".";
}

static String timeHHMM() {
  time_t now = time(nullptr);
  if (now < 1609459200) return "--:--";
  struct tm t;
  localtime_r(&now, &t);
  char b[6];
  snprintf(b, sizeof(b), "%02d:%02d", t.tm_hour, t.tm_min);
  return String(b);
}

static bool nightWindow(uint16_t now, uint16_t start, uint16_t end) {
  if (start == end) return false;
  if (start < end) return now >= start && now < end;
  return now >= start || now < end;
}

static void applyBrightness() {
  uint8_t b = cfg.brightness;
  time_t now = time(nullptr);
  if (cfg.nightEnabled && now > 1609459200) {
    struct tm t; localtime_r(&now, &t);
    uint16_t m = t.tm_hour * 60 + t.tm_min;
    if (nightWindow(m, cfg.nightStart, cfg.nightEnd)) b = cfg.nightBrightness;
  }
  if (b > 100) b = 100;
  // SmallTV backlight is active-low.
  int duty = 255 - ((int)b * 255 / 100);
  analogWrite(TFT_BL, duty);
}

static bool modeEnabled(uint8_t mode) {
  return mode < 9 && (cfg.rotationMask & (1U << mode));
}

static uint8_t enabledModeCount() {
  uint8_t n=0; for(uint8_t i=0;i<9;i++) if(modeEnabled(i)) n++; return n;
}

static uint8_t firstEnabledMode() {
  for(uint8_t i=0;i<9;i++) if(modeEnabled(i)) return i;
  return MODE_DEPARTURES;
}

static uint8_t nextEnabledMode(uint8_t current) {
  for(uint8_t step=1;step<=9;step++) { uint8_t m=(current+step)%9; if(modeEnabled(m)) return m; }
  return current;
}

// ---- local config ------------------------------------------------------------
static const char* CFG_PATH = "/config.json";

static bool validHexColor(const String& s) {
  if (s.length() != 7 || s[0] != '#') return false;
  for (uint8_t i=1;i<7;i++) if (!isxdigit((unsigned char)s[i])) return false;
  return true;
}

static void saveConfig() {
  JsonDocument d;
  d["ssid"] = cfg.ssid; d["pass"] = cfg.pass; d["hostname"] = cfg.hostname;
  d["mode"] = cfg.mode; d["rotationMask"] = cfg.rotationMask; d["brightness"] = cfg.brightness;
  JsonArray rs = d["rotationSec"].to<JsonArray>(); for(uint8_t i=0;i<9;i++) rs.add(cfg.rotationSec[i]);
  d["nightEnabled"] = cfg.nightEnabled; d["nightStart"] = cfg.nightStart; d["nightEnd"] = cfg.nightEnd; d["nightBrightness"] = cfg.nightBrightness;
  d["stopName"] = cfg.stopName; d["stopId"] = cfg.stopId; d["departureCount"] = cfg.departureCount; d["departurePoll"] = cfg.departurePoll; d["vvoMotMask"] = cfg.vvoMotMask;
  d["weatherCity"] = cfg.weatherCity; d["weatherDisplayName"] = cfg.weatherDisplayName; d["weatherLat"] = cfg.weatherLat; d["weatherLon"] = cfg.weatherLon; d["weatherPoll"] = cfg.weatherPoll; d["weatherTempColor"] = cfg.weatherTempColor;
  d["planePlace"] = cfg.planePlace; d["planeLat"] = cfg.planeLat; d["planeLon"] = cfg.planeLon; d["planeRadiusKm"] = cfg.planeRadiusKm; d["planePoll"] = cfg.planePoll;
  d["trackedFlightNo"] = cfg.trackedFlightNo; d["aviationstackKey"] = cfg.aviationstackKey; d["trackerStatusPollMin"] = cfg.trackerStatusPollMin;
  JsonArray cds = d["countdowns"].to<JsonArray>();
  for (uint8_t i=0;i<4;i++) {
    JsonObject c = cds.add<JsonObject>();
    c["title"] = cfg.countdown[i].title; c["titleColor"] = cfg.countdown[i].titleColor; c["countColor"] = cfg.countdown[i].countColor;
    c["type"] = cfg.countdown[i].type; c["targetDate"] = cfg.countdown[i].targetDate; c["durationSec"] = cfg.countdown[i].durationSec;
    c["targetEpoch"] = cfg.countdown[i].targetEpoch; c["active"] = cfg.countdown[i].active; c["dayDigits"] = cfg.countdown[i].dayDigits;
  }
  File f = LittleFS.open(CFG_PATH, "w");
  if (f) { serializeJson(d, f); f.close(); }
}

static void loadConfig() {
  if (!LittleFS.begin()) LittleFS.format(), LittleFS.begin();
  File f = LittleFS.open(CFG_PATH, "r"); if (!f) return;
  JsonDocument d; if (deserializeJson(d, f)) { f.close(); return; } f.close();
  cfg.ssid = d["ssid"] | cfg.ssid; cfg.pass = d["pass"] | cfg.pass; cfg.hostname = d["hostname"] | cfg.hostname;
  cfg.mode = constrain((int)(d["mode"] | cfg.mode), 0, 8);
  if(d["rotationMask"].is<uint16_t>() || d["rotationMask"].is<int>()) cfg.rotationMask = ((uint16_t)(d["rotationMask"] | cfg.rotationMask)) & 0x01FFU;
  else cfg.rotationMask = (1U << cfg.mode); // migrate v0.4 single-view configuration
  if(!cfg.rotationMask) cfg.rotationMask = (1U << cfg.mode);
  JsonArrayConst rs=d["rotationSec"].as<JsonArrayConst>(); if(!rs.isNull()) for(uint8_t i=0;i<9&&i<rs.size();i++) cfg.rotationSec[i]=constrain((int)(rs[i]|cfg.rotationSec[i]),5,3600);
  cfg.brightness = constrain((int)(d["brightness"] | cfg.brightness), 0, 100);
  cfg.nightEnabled = d["nightEnabled"] | cfg.nightEnabled; cfg.nightStart = constrain((int)(d["nightStart"] | cfg.nightStart), 0, 1439); cfg.nightEnd = constrain((int)(d["nightEnd"] | cfg.nightEnd), 0, 1439); cfg.nightBrightness = constrain((int)(d["nightBrightness"] | cfg.nightBrightness), 0, 100);
  cfg.stopName = d["stopName"] | cfg.stopName; cfg.stopId = d["stopId"] | cfg.stopId; cfg.departureCount = constrain((int)(d["departureCount"] | cfg.departureCount), 3, 5); cfg.departurePoll = constrain((int)(d["departurePoll"] | cfg.departurePoll), 10, 300); cfg.vvoMotMask = ((uint8_t)(d["vvoMotMask"] | cfg.vvoMotMask)) & VVO_MOT_ALL; if(!cfg.vvoMotMask)cfg.vvoMotMask=VVO_MOT_ALL;
  cfg.weatherCity = d["weatherCity"] | cfg.weatherCity; cfg.weatherDisplayName = d["weatherDisplayName"] | cfg.weatherDisplayName; cfg.weatherLat = d["weatherLat"] | cfg.weatherLat; cfg.weatherLon = d["weatherLon"] | cfg.weatherLon; cfg.weatherPoll = constrain((int)(d["weatherPoll"] | cfg.weatherPoll), 60, 3600); cfg.weatherTempColor = d["weatherTempColor"] | cfg.weatherTempColor;
  cfg.planePlace = d["planePlace"] | cfg.planePlace; cfg.planeLat = d["planeLat"] | cfg.planeLat; cfg.planeLon = d["planeLon"] | cfg.planeLon; cfg.planeRadiusKm = constrain((int)(d["planeRadiusKm"] | cfg.planeRadiusKm), 1, 250); cfg.planePoll = constrain((int)(d["planePoll"] | cfg.planePoll), 3, 300);
  cfg.trackedFlightNo = d["trackedFlightNo"] | cfg.trackedFlightNo; cfg.aviationstackKey = d["aviationstackKey"] | cfg.aviationstackKey; cfg.trackerStatusPollMin = constrain((int)(d["trackerStatusPollMin"] | cfg.trackerStatusPollMin), 5, 120);
  JsonArrayConst cds = d["countdowns"].as<JsonArrayConst>();
  if (!cds.isNull()) for (uint8_t i=0;i<4 && i<cds.size();i++) {
    JsonObjectConst c=cds[i].as<JsonObjectConst>(); CountdownSlot& x=cfg.countdown[i];
    x.title = c["title"] | x.title; String tc=c["titleColor"] | x.titleColor; if(validHexColor(tc))x.titleColor=tc; String cc=c["countColor"] | x.countColor; if(validHexColor(cc))x.countColor=cc;
    x.type=constrain((int)(c["type"]|x.type),0,2); x.targetDate=c["targetDate"]|x.targetDate; x.durationSec=c["durationSec"]|x.durationSec; x.targetEpoch=c["targetEpoch"]|x.targetEpoch; x.active=c["active"]|x.active; x.dayDigits=constrain((int)(c["dayDigits"]|x.dayDigits),3,6);
  }
  if(!modeEnabled(cfg.mode)) cfg.mode=firstEnabledMode();
}

// ---- display views -----------------------------------------------------------
static void drawFooterClockOnly() {
  // The footer clock is independent from API refreshes. Only repaint its small
  // rectangle when the minute changes so weather/VVO views can stay untouched.
  gfx->fillRect(196, 224, 36, 12, C_BLACK);
  String tm = timeHHMM();
  printDisplayTextAt(232 - textW(tm, 1), 226, tm, 1, C_GRAY);
}

static void drawFooter(const char* label) {
  gfx->drawFastHLine(8, 218, 224, C_DGRAY);
  printDisplayTextAt(8, 226, String(label), 1, C_GRAY);
  drawFooterClockOnly();
}

static String displayAscii(String s) {
  // Name kept for compatibility with the v0.4 rendering code. UTF-8 German
  // glyphs are rendered natively by printDisplayTextAt()/centerText().
  s.replace("Dresden ", "");
  return s;
}


static uint16_t color565(const String& hex) {
  if (!validHexColor(hex)) return C_WHITE;
  uint32_t rgb = strtoul(hex.substring(1).c_str(), nullptr, 16);
  uint8_t r=(rgb>>16)&0xFF, g=(rgb>>8)&0xFF, b=rgb&0xFF;
  return (uint16_t)(((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3));
}

static int64_t daysFromCivilDate(int y, unsigned m, unsigned d) {
  y -= m <= 2;
  const int era = (y >= 0 ? y : y - 399) / 400;
  const unsigned yoe = (unsigned)(y - era * 400);
  const unsigned doy = (153 * (m + (m > 2 ? -3 : 9)) + 2) / 5 + d - 1;
  const unsigned doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
  return (int64_t)era * 146097 + (int64_t)doe - 719468;
}

static bool parseDateOnly(const String& iso, int& y, int& m, int& d) {
  if (iso.length() != 10 || iso[4] != '-' || iso[7] != '-') return false;
  y=iso.substring(0,4).toInt(); m=iso.substring(5,7).toInt(); d=iso.substring(8,10).toInt();
  return y>=1970 && m>=1 && m<=12 && d>=1 && d<=31;
}

static bool countdownDayDifference(const String& target, int32_t& outDays) {
  time_t now=time(nullptr); if(now<1609459200) return false;
  struct tm t; localtime_r(&now,&t);
  int y,m,d; if(!parseDateOnly(target,y,m,d)) return false;
  int64_t today=daysFromCivilDate(t.tm_year+1900,(unsigned)(t.tm_mon+1),(unsigned)t.tm_mday);
  int64_t goal=daysFromCivilDate(y,(unsigned)m,(unsigned)d);
  int64_t diff=goal-today;
  if(diff>2147483647LL || diff<-2147483647LL) return false;
  outDays=(int32_t)diff; return true;
}

static uint8_t decimalDigits(uint32_t v) {
  uint8_t n=1; while(v>=10){v/=10;n++;} return n;
}

static String padUnsigned(uint32_t v, uint8_t digits) {
  String s=String(v); while(s.length()<digits)s="0"+s; return s;
}

static uint8_t segMask(uint8_t d) {
  static const uint8_t masks[10]={
    0b00111111, // 0: a b c d e f
    0b00000110, // 1: b c
    0b01011011, // 2: a b d e g
    0b01001111, // 3: a b c d g
    0b01100110, // 4: b c f g
    0b01101101, // 5: a c d f g
    0b01111101, // 6: a c d e f g
    0b00000111, // 7: a b c
    0b01111111, // 8
    0b01101111  // 9
  };
  return d<10?masks[d]:0;
}

static void drawSevenDigit(int x,int y,int w,int h,int t,uint8_t d,uint16_t color) {
  uint8_t m=segMask(d); int half=h/2;
  if(m&0x01)gfx->fillRect(x+t,y,w-2*t,t,color);
  if(m&0x02)gfx->fillRect(x+w-t,y+t,t,half-t,color);
  if(m&0x04)gfx->fillRect(x+w-t,y+half,t,half-t,color);
  if(m&0x08)gfx->fillRect(x+t,y+h-t,w-2*t,t,color);
  if(m&0x10)gfx->fillRect(x,y+half,t,half-t,color);
  if(m&0x20)gfx->fillRect(x,y+t,t,half-t,color);
  if(m&0x40)gfx->fillRect(x+t,y+half-t/2,w-2*t,t,color);
}

static int sevenUnit(char c) {
  if(c>='0'&&c<='9')return 100;
  if(c==':')return 34;
  if(c=='+'||c=='-'||c==' ')return 62;
  return 45;
}

static int sevenCharWidth(char c,int digitW) {
  return max(4,(digitW*sevenUnit(c))/100);
}

static void drawSevenString(const String& value,int centerY,uint16_t color) {
  const int gap=3;
  int units=0; for(size_t i=0;i<value.length();i++)units+=sevenUnit(value[i]);
  int gaps=value.length()>0?(int)(value.length()-1)*gap:0;
  int digitW=(224-gaps)*100/max(100,units);
  digitW=constrain(digitW,18,42);
  int h=(digitW*19)/10;
  int total=gaps; for(size_t i=0;i<value.length();i++)total+=sevenCharWidth(value[i],digitW);
  int x=(TFT_W-total)/2, y=centerY-h/2, t=max(3,digitW/6);
  for(size_t i=0;i<value.length();i++){
    char c=value[i]; int w=sevenCharWidth(c,digitW);
    if(c>='0'&&c<='9') drawSevenDigit(x,y,digitW,h,t,(uint8_t)(c-'0'),color);
    else if(c==':') { int s=max(3,t-1); gfx->fillRect(x+(w-s)/2,y+h/3-s/2,s,s,color); gfx->fillRect(x+(w-s)/2,y+(2*h)/3-s/2,s,s,color); }
    else if(c=='-'||c=='+') { int cy=y+h/2; gfx->fillRect(x,cy-t/2,w,t,color); if(c=='+')gfx->fillRect(x+w/2-t/2,cy-w/2,t,w,color); }
    // Space deliberately draws nothing but keeps the sign column width stable.
    x+=w+gap;
  }
}

static int8_t countdownSlotFromMode(uint8_t mode) {
  if(mode<MODE_COUNTDOWN1||mode>MODE_COUNTDOWN4)return -1;
  return (int8_t)(mode-MODE_COUNTDOWN1);
}

static String countdownValue(const CountdownSlot& c) {
  if(!c.active)return "---";
  if(c.type==COUNTDOWN_DAYS){
    int32_t days=0;if(!countdownDayDifference(c.targetDate,days))return "---";
    uint32_t a=days<0?(uint32_t)(-(int64_t)days):(uint32_t)days;
    String sign=days>0?"-":(days<0?"+":" ");
    return sign+padUnsigned(a,c.dayDigits);
  }
  time_t now=time(nullptr);if(now<1609459200||!c.targetEpoch)return "---";
  int64_t diff=(int64_t)c.targetEpoch-(int64_t)now;
  uint64_t a=diff<0?(uint64_t)(-diff):(uint64_t)diff;
  String sign=diff>0?"-":(diff<0?"+":" ");
  if(c.type==COUNTDOWN_MS){
    uint32_t mins=(uint32_t)(a/60ULL), sec=(uint32_t)(a%60ULL);
    return sign+padUnsigned(mins,2)+":"+padUnsigned(sec,2);
  }
  uint32_t hours=(uint32_t)(a/3600ULL), mins=(uint32_t)((a%3600ULL)/60ULL), sec=(uint32_t)(a%60ULL);
  return sign+padUnsigned(hours,2)+":"+padUnsigned(mins,2)+":"+padUnsigned(sec,2);
}

static String flightStatusGerman(const char* s) {
  if(!s||!*s)return "N/A";
  if(!strcmp(s,"active"))return "IN DER LUFT";
  if(!strcmp(s,"landed"))return "GELANDET";
  if(!strcmp(s,"scheduled"))return "GEPLANT";
  if(!strcmp(s,"cancelled"))return "ANNULLIERT";
  if(!strcmp(s,"diverted"))return "UMGELEITET";
  if(!strcmp(s,"incident"))return "STÖRUNG";
  return String(s);
}

static String trackedFlightDuration(const TrackedFlightSnapshot& f) {
  int64_t start=f.depActualEpoch?f.depActualEpoch:f.depScheduledEpoch;
  if(!start)return "N/A";
  int64_t end=0;
  if(f.arrActualEpoch)end=f.arrActualEpoch;
  else if(f.depActualEpoch){time_t now=time(nullptr);if(now>1609459200)end=now;}
  else end=f.arrScheduledEpoch;
  if(!end||end<start)return "N/A";
  uint64_t sec=(uint64_t)(end-start);uint32_t h=sec/3600ULL,m=(sec%3600ULL)/60ULL;
  return padUnsigned(h,2)+":"+padUnsigned(m,2);
}

static void drawDepartures() {
  gfx->fillScreen(C_BLACK);
  String title = crop(displayAscii(cfg.stopName.length() ? cfg.stopName : "HALTESTELLE"), 18);
  printDisplayTextAt(8, 7, title, 2, C_YELLOW);
  gfx->drawFastHLine(8, 29, 224, C_DGRAY);

  if (!cfg.stopId.length()) {
    centerText("HALTESTELLE", 78, 2, C_WHITE);
    centerText("IM WEBINTERFACE", 108, 2, C_GRAY);
    centerText("AUSWÄHLEN", 136, 2, C_GRAY);
    drawFooter("VVO NICHT KONFIGURIERT");
    return;
  }

  uint8_t n = vvoCount();
  if (!n) {
    if (vvoError()) {
      centerText("VVO", 82, 4, C_RED);
      centerText("nicht erreichbar", 128, 2, C_GRAY);
      drawFooter("VVO FEHLER");
    } else {
      centerText("VVO", 82, 4, C_YELLOW);
      centerText("lade Abfahrten...", 128, 2, C_GRAY);
      drawFooter("LIVE");
    }
    return;
  }

  if (n > cfg.departureCount) n = cfg.departureCount;
  int y0 = 41, step = (n >= 5 ? 34 : (n == 4 ? 42 : 52));
  for (uint8_t i = 0; i < n; i++) {
    const VvoDeparture& d = vvoAt(i);
    int y = y0 + i * step;
    String line = displayAscii(String(d.line));
    String dest = crop(displayAscii(String(d.direction)), 9);
    String right;
    uint16_t rightColor = C_WHITE;
    if (d.cancelled) { right = "AUS"; rightColor = C_RED; }
    else if (d.minutes < 0) { right = "?"; rightColor = C_GRAY; }
    else if (d.minutes <= 0) { right = "JETZT"; rightColor = C_GREEN; }
    else { right = String(d.minutes); rightColor = d.delayed ? C_YELLOW : C_WHITE; }

    uint16_t lc = glyphCount(line);
    uint8_t lineSize = lc <= 2 ? 3 : (lc <= 4 ? 2 : 1);
    int lineY = y + (lineSize == 3 ? 0 : (lineSize == 2 ? 6 : 12));
    printDisplayTextAt(8, lineY, line, lineSize, C_YELLOW);
    printDisplayTextAt(62, y + 6, dest, 2, C_WHITE);
    uint8_t rs = (right == "JETZT") ? 1 : 2;
    printDisplayTextAt(232 - textW(right, rs), y + (rs == 1 ? 10 : 6), right, rs, rightColor);
  }
  drawFooter(vvoError() ? "LIVE / LETZTER STAND" : "VVO LIVE");
}

static void drawCloud(int cx, int cy, uint16_t color) {
  gfx->fillCircle(cx-18, cy+4, 11, color);
  gfx->fillCircle(cx, cy-5, 17, color);
  gfx->fillCircle(cx+20, cy+4, 12, color);
  gfx->fillRect(cx-27, cy+4, 56, 15, color);
}

static void drawSun(int cx, int cy, uint16_t color) {
  gfx->fillCircle(cx, cy, 15, color);
  for (int a=0; a<360; a+=45) {
    float r=a*(float)PI/180.0f;
    int x1=cx+(int)(22*cosf(r)), y1=cy+(int)(22*sinf(r));
    int x2=cx+(int)(30*cosf(r)), y2=cy+(int)(30*sinf(r));
    gfx->drawLine(x1,y1,x2,y2,color);
  }
}

static void drawWeatherIcon(int code, bool day) {
  if (code == 0 || code == 1) {
    if (day) drawSun(120,55,C_YELLOW);
    else { gfx->fillCircle(120,55,18,C_WHITE); gfx->fillCircle(129,48,18,C_BLACK); }
    return;
  }
  if (code == 2) { drawSun(103,47,C_YELLOW); drawCloud(125,58,C_WHITE); return; }
  if (code == 3 || code == 45 || code == 48) { drawCloud(120,55,C_WHITE); return; }
  drawCloud(120,48,C_WHITE);
  if ((code >= 51 && code <= 67) || (code >= 80 && code <= 82) || code >= 95) {
    for (int x=96;x<=144;x+=16) gfx->drawLine(x,73,x-5,84,C_CYAN);
  } else if ((code >= 71 && code <= 77) || (code >= 85 && code <= 86)) {
    gfx->setTextSize(2); gfx->setTextColor(C_CYAN);
    gfx->setCursor(92,72); gfx->print("*  *  *");
  }
  if (code >= 95) {
    gfx->drawLine(123,66,113,84,C_YELLOW); gfx->drawLine(113,84,124,81,C_YELLOW); gfx->drawLine(124,81,116,94,C_YELLOW);
  }
}

static uint16_t weatherTempColor565(float c) {
  if(c <= -10.0f) return 0x001F; // deep blue
  if(c <=   0.0f) return C_BLUE;
  if(c <=  10.0f) return C_CYAN;
  if(c <=  17.0f) return C_WHITE;
  if(c <=  23.0f) return C_GREEN;
  if(c <=  28.0f) return C_YELLOW;
  if(c <=  34.0f) return 0xFD20; // orange
  return C_RED;
}

static void drawSunEventIcon(int x,int y,bool rise) {
  // 13x9 tiny pixel-style sunrise/sunset mark. No emoji/font dependency.
  uint16_t c=C_GRAY;
  gfx->drawFastHLine(x,y+7,13,c);
  gfx->drawPixel(x+6,y+1,c);
  gfx->drawPixel(x+3,y+3,c); gfx->drawPixel(x+9,y+3,c);
  gfx->drawLine(x+4,y+6,x+4,y+5,c); gfx->drawLine(x+8,y+6,x+8,y+5,c);
  gfx->drawFastHLine(x+5,y+4,3,c);
  gfx->drawLine(x+6,y+8,x+6,y+8,c);
  if(rise){gfx->drawLine(x+6,y+8,x+4,y+6,c);gfx->drawLine(x+6,y+8,x+8,y+6,c);}
  else{gfx->drawLine(x+6,y+6,x+4,y+8,c);gfx->drawLine(x+6,y+6,x+8,y+8,c);}
}

static void drawWeather() {
  gfx->fillScreen(C_BLACK);
  String weatherTitle = cfg.weatherDisplayName.length() ? cfg.weatherDisplayName : cfg.weatherCity;
  printDisplayTextAt(8,7,crop(displayAscii(weatherTitle),18),2,C_YELLOW);

  const WeatherSnapshot& w = weatherData();
  if (!w.valid) {
    centerText(w.error ? "WETTER FEHLER" : "WETTER LÄDT", 88, 2, w.error ? C_RED : C_YELLOW);
    centerText(w.error ? "Open-Meteo nicht erreichbar" : "Daten werden geladen...", 124, 1, C_GRAY);
    drawFooter("OPEN-METEO");
    return;
  }

  drawWeatherIcon(w.code, w.isDay);
  String temp=String((int)lroundf(w.currentC));
  uint16_t tempColor=cfg.weatherTempColor ? weatherTempColor565(w.currentC) : C_WHITE;
  centerText(temp, 88, 6, tempColor);
  printDisplayTextAt(176,103,"C",2,cfg.weatherTempColor ? tempColor : C_GRAY);
  centerText(weatherLabel(w.code), 142, 2, C_WHITE);

  String hi="H "+String((int)lroundf(w.highC));
  String lo="T "+String((int)lroundf(w.lowC));
  printDisplayTextAt(18,169,hi,2,C_GRAY);
  printDisplayTextAt(144,169,lo,2,C_GRAY);

  String rain = w.rainPct >= 0 ? String("REGEN ")+String(w.rainPct)+"%" : String("REGEN --");
  printDisplayTextAt(18,197,rain,1,C_CYAN);
  drawSunEventIcon(118,196,true);  printDisplayTextAt(133,197,String(w.sunrise),1,C_GRAY);
  drawSunEventIcon(174,196,false); printDisplayTextAt(189,197,String(w.sunset),1,C_GRAY);
  drawFooter(w.error ? "LIVE / LETZTER STAND" : "OPEN-METEO LIVE");
}

static void drawPlane() {
  gfx->fillScreen(C_BLACK);
  printDisplayTextAt(8,7,"IN DER NÄHE",2,C_YELLOW);
  gfx->drawFastHLine(8,29,224,C_DGRAY);

  const FlightSnapshot& f = flightData();
  if (!f.valid) {
    if (f.error) {
      centerText("FLUGRADAR", 80, 3, C_RED);
      centerText("adsb.lol nicht erreichbar", 125, 1, C_GRAY);
    } else {
      centerText("KEIN FLUGZEUG", 80, 2, C_WHITE);
      centerText("im gewählten Radius", 116, 1, C_GRAY);
    }
    drawFooter("ADSB.LOL");
    return;
  }

  String cs=f.callsign[0]?String(f.callsign):String("N/A");
  uint8_t csSize=cs.length()<=6?4:3;
  centerText(cs, 42, csSize, C_WHITE);
  centerText(f.airline[0]?String(f.airline):String("N/A"), 80, 2, C_GRAY);
  String route=String(f.origin[0]?f.origin:"N/A")+" > "+String(f.destination[0]?f.destination:"N/A");
  centerText(route, 105, 3, C_YELLOW);
  String type=f.typeName[0]?String(f.typeName):(f.typeCode[0]?String(f.typeCode):String("N/A"));
  centerText(crop(type,20), 139, 2, C_WHITE);
  centerText(f.registration[0]?String(f.registration):String("N/A"), 164, 2, C_GRAY);

  String dist=String(f.distanceKm,1)+" km";
  String alt=f.altitudeFt>0?String((int)lroundf(f.altitudeFt*0.3048f))+" m":String("N/A");
  gfx->setTextSize(2); gfx->setTextColor(C_CYAN); gfx->setCursor(10,194); gfx->print(dist);
  gfx->setCursor(230-textW(alt,2),194); gfx->print(alt);
  drawFooter(f.error ? "LIVE / LETZTER STAND" : "ADSB.LOL LIVE");
}

static void drawTrackedFlight() {
  gfx->fillScreen(C_BLACK);
  if(!cfg.trackedFlightNo.length()){
    centerText("N/A",72,5,C_WHITE);centerText("N/A > N/A",126,3,C_YELLOW);centerText("Flugnummer im Webinterface",176,1,C_GRAY);return;
  }
  if(!cfg.aviationstackKey.length()){
    centerText(displayAscii(cfg.trackedFlightNo),62,4,C_WHITE);centerText("N/A > N/A",116,3,C_YELLOW);centerText("API-KEY FEHLT",166,2,C_RED);return;
  }
  const TrackedFlightSnapshot& f=trackedFlightData();
  if(!f.valid){
    centerText(displayAscii(cfg.trackedFlightNo),56,4,C_WHITE);
    centerText("N/A > N/A",108,3,C_YELLOW);
    if(f.error)centerText("TRACKER FEHLER",158,2,C_RED);
    else if(f.notFound)centerText("FLUG N/A",158,2,C_GRAY);
    else centerText("lade Flugdaten...",158,2,C_GRAY);
    return;
  }
  String no=f.flightIata[0]?String(f.flightIata):cfg.trackedFlightNo;
  centerText(no,5,no.length()<=7?3:2,C_WHITE);
  centerText(String(f.origin[0]?f.origin:"N/A")+" > "+String(f.destination[0]?f.destination:"N/A"),36,3,C_YELLOW);
  centerText(flightStatusGerman(f.status),64,1,C_GRAY);

  auto row=[](const char* label,const char* value,int y,uint16_t col){
    gfx->setTextSize(1);gfx->setTextColor(C_GRAY);gfx->setCursor(8,y+5);gfx->print(label);
    String v=(value&&*value)?String(value):String("N/A");gfx->setTextSize(2);gfx->setTextColor(col);gfx->setCursor(232-textW(v,2),y);gfx->print(v);
  };
  row("AB PLAN",f.depScheduled,82,C_WHITE);
  row("AB IST",f.depActual,105,C_WHITE);
  row("AN PLAN",f.arrScheduled,128,C_WHITE);
  if(strcmp(f.arrActual,"N/A"))row("AN IST",f.arrActual,151,C_GREEN);else row("AN ETA",f.arrEstimated,151,C_CYAN);
  String dur=trackedFlightDuration(f);row("FLUGZEIT",dur.c_str(),174,C_WHITE);
  String alt=f.altitudeM>0?String(f.altitudeM)+" m":String("N/A");
  String spd=f.speedKmh>1?String((int)lroundf(f.speedKmh))+" km/h":String("N/A");
  gfx->setTextSize(1);gfx->setTextColor(C_CYAN);gfx->setCursor(8,204);gfx->print(alt);gfx->setCursor(232-textW(spd,1),204);gfx->print(spd);
  drawFooter("AVIATIONSTACK + ADSB.LOL");
}

static void drawCountdown(uint8_t slot) {
  if(slot>3)return;
  const CountdownSlot& c=cfg.countdown[slot];
  gfx->fillScreen(C_BLACK);
  String title=crop(displayAscii(c.title),24);
  bool hasTitle=glyphCount(title)>0;
  if(hasTitle)centerText(title,28,glyphCount(title)<=12?3:2,color565(c.titleColor));
  String value=countdownValue(c);
  lastCountdownRendered[slot]=value;
  uint16_t cc=color565(c.countColor);
  if(c.type==COUNTDOWN_DAYS){
    drawSevenString(value,hasTitle?127:111,cc);
    centerText("TAGE",hasTitle?183:168,2,cc);
  } else {
    drawSevenString(value,hasTitle?135:120,cc);
  }
}

static void drawClock(bool fullRedraw=true) {
  if(fullRedraw){
    gfx->fillScreen(C_BLACK);
    drawFooter("EUROPE/BERLIN");
  } else {
    // Only repaint the dynamic clock/date areas. This avoids a visible full-screen
    // flash at every minute change.
    gfx->fillRect(0,72,TFT_W,66,C_BLACK);
    gfx->fillRect(0,140,TFT_W,28,C_BLACK);
  }
  String t = timeHHMM();
  centerText(t, 84, 6, C_WHITE);
  time_t now = time(nullptr);
  if (now > 1609459200) {
    struct tm tmv; localtime_r(&now,&tmv);
    static const char* wd[]={"SO","MO","DI","MI","DO","FR","SA"};
    char b[32]; snprintf(b,sizeof(b),"%s  %02d.%02d.%04d",wd[tmv.tm_wday],tmv.tm_mday,tmv.tm_mon+1,tmv.tm_year+1900);
    centerText(b, 145, 2, C_GRAY);
  } else {
    centerText("warte auf NTP", 145, 2, C_GRAY);
  }
  if(!fullRedraw) drawFooterClockOnly();
}

static void drawActive() {
  applyBrightness();
  int8_t slot=countdownSlotFromMode(cfg.mode);
  if(slot>=0){drawCountdown((uint8_t)slot);return;}
  switch (cfg.mode) {
    case MODE_WEATHER: drawWeather(); break;
    case MODE_PLANE: drawPlane(); break;
    case MODE_CLOCK: drawClock(); break;
    case MODE_TRACKED_FLIGHT: drawTrackedFlight(); break;
    default: drawDepartures(); break;
  }
}

// ---- network ----------------------------------------------------------------
static void startAP() {
  apMode = true;
  // Keep STA enabled while hosting setup AP so /api/wifi/scan can scan nearby networks.
  WiFi.mode(WIFI_AP_STA);
  IPAddress ip(192,168,4,1);
  WiFi.softAPConfig(ip,ip,IPAddress(255,255,255,0));
  WiFi.softAP("SmallTV-Setup");
  dns.start(53,"*",ip);

  gfx->fillScreen(C_BLACK);
  centerText("SETUP", 55, 4, C_YELLOW);
  centerText("WLAN:", 105, 2, C_GRAY);
  centerText("SmallTV-Setup", 128, 2, C_WHITE);
  centerText("192.168.4.1", 174, 2, C_GREEN);
}

static void connectWiFi() {
  if (!cfg.ssid.length()) { startAP(); return; }
  WiFi.mode(WIFI_STA);
  WiFi.persistent(false);
  WiFi.hostname(cfg.hostname.c_str());
  WiFi.begin(cfg.ssid.c_str(), cfg.pass.c_str());
  gfx->fillScreen(C_BLACK);
  centerText("WLAN", 80, 4, C_YELLOW);
  centerText("verbinden...", 126, 2, C_GRAY);

  uint32_t start=millis();
  while(WiFi.status()!=WL_CONNECTED && millis()-start<18000){delay(200);yield();}
  if(WiFi.status()!=WL_CONNECTED){startAP();return;}

  apMode=false;
  if(MDNS.begin(cfg.hostname.c_str())) MDNS.addService("http","tcp",80);
  configTime("CET-1CEST,M3.5.0,M10.5.0/3","pool.ntp.org","time.cloudflare.com");
}

// ---- web API ----------------------------------------------------------------
static void sendJson(JsonDocument& d) {
  String out; serializeJson(d,out); server.send(200,"application/json",out);
}

static void countdownToJson(JsonObject out,const CountdownSlot& c) {
  out["title"]=c.title;out["titleColor"]=c.titleColor;out["countColor"]=c.countColor;out["type"]=c.type;out["targetDate"]=c.targetDate;
  out["durationSec"]=c.durationSec;out["targetEpoch"]=c.targetEpoch;out["active"]=c.active;out["dayDigits"]=c.dayDigits;
}

static void updateCountdownSettings(JsonObjectConst in,CountdownSlot& c) {
  if(in["title"].is<const char*>())c.title=in["title"].as<String>();
  if(c.title.length()>24)c.title.remove(24);
  if(in["titleColor"].is<const char*>()){String x=in["titleColor"].as<String>();if(validHexColor(x))c.titleColor=x;}
  if(in["countColor"].is<const char*>()){String x=in["countColor"].as<String>();if(validHexColor(x))c.countColor=x;}
  uint8_t oldType=c.type;c.type=constrain((int)(in["type"]|c.type),0,2);
  if(oldType!=c.type){c.active=false;c.targetEpoch=0;c.dayDigits=3;}
  if(in["targetDate"].is<const char*>())c.targetDate=in["targetDate"].as<String>();
  uint32_t dur=in["durationSec"]|c.durationSec;if(dur>31536000UL)dur=31536000UL;c.durationSec=dur;
}

static void apiGetConfig() {
  JsonDocument d;
  d["ssid"]=cfg.ssid;d["hostname"]=cfg.hostname;d["mode"]=cfg.mode;d["rotationMask"]=cfg.rotationMask;d["brightness"]=cfg.brightness;
  JsonArray rs=d["rotationSec"].to<JsonArray>();for(uint8_t i=0;i<9;i++)rs.add(cfg.rotationSec[i]);
  d["nightEnabled"]=cfg.nightEnabled;d["nightStart"]=cfg.nightStart;d["nightEnd"]=cfg.nightEnd;d["nightBrightness"]=cfg.nightBrightness;
  d["stopName"]=cfg.stopName;d["stopId"]=cfg.stopId;d["departureCount"]=cfg.departureCount;d["departurePoll"]=cfg.departurePoll;d["vvoMotMask"]=cfg.vvoMotMask;
  d["weatherCity"]=cfg.weatherCity;d["weatherDisplayName"]=cfg.weatherDisplayName;d["weatherLat"]=cfg.weatherLat;d["weatherLon"]=cfg.weatherLon;d["weatherPoll"]=cfg.weatherPoll;d["weatherTempColor"]=cfg.weatherTempColor;
  d["planePlace"]=cfg.planePlace;d["planeLat"]=cfg.planeLat;d["planeLon"]=cfg.planeLon;d["planeRadiusKm"]=cfg.planeRadiusKm;d["planePoll"]=cfg.planePoll;
  d["trackedFlightNo"]=cfg.trackedFlightNo;d["trackerStatusPollMin"]=cfg.trackerStatusPollMin;d["aviationstackKeySet"]=cfg.aviationstackKey.length()>0;
  JsonArray a=d["countdowns"].to<JsonArray>();for(uint8_t i=0;i<4;i++)countdownToJson(a.add<JsonObject>(),cfg.countdown[i]);
  sendJson(d);
}

static void apiPostConfig() {
  if(!server.hasArg("plain")){server.send(400,"application/json","{\"ok\":false,\"error\":\"Keine Daten empfangen.\"}");return;}
  JsonDocument d;if(deserializeJson(d,server.arg("plain"))){server.send(400,"application/json","{\"ok\":false,\"error\":\"Einstellungen konnten nicht gelesen werden.\"}");return;}
  String oldSsid=cfg.ssid,oldHost=cfg.hostname,oldTracked=cfg.trackedFlightNo,oldKey=cfg.aviationstackKey;
  if(d["ssid"].is<const char*>())cfg.ssid=d["ssid"].as<String>();
  if(d["pass"].is<const char*>()){String x=d["pass"].as<String>();if(x.length())cfg.pass=x;}
  if(d["hostname"].is<const char*>())cfg.hostname=d["hostname"].as<String>();
  uint16_t mask=((uint16_t)(d["rotationMask"]|cfg.rotationMask))&0x01FFU;if(mask)cfg.rotationMask=mask;
  JsonArrayConst rs=d["rotationSec"].as<JsonArrayConst>();if(!rs.isNull())for(uint8_t i=0;i<9&&i<rs.size();i++)cfg.rotationSec[i]=constrain((int)(rs[i]|cfg.rotationSec[i]),5,3600);
  if(!modeEnabled(cfg.mode))cfg.mode=firstEnabledMode();
  cfg.brightness=constrain((int)(d["brightness"]|cfg.brightness),0,100);
  cfg.nightEnabled=d["nightEnabled"]|cfg.nightEnabled;cfg.nightStart=constrain((int)(d["nightStart"]|cfg.nightStart),0,1439);cfg.nightEnd=constrain((int)(d["nightEnd"]|cfg.nightEnd),0,1439);cfg.nightBrightness=constrain((int)(d["nightBrightness"]|cfg.nightBrightness),0,100);
  if(d["stopName"].is<const char*>()) cfg.stopName=d["stopName"].as<String>();
  if(d["stopId"].is<const char*>()) cfg.stopId=d["stopId"].as<String>();
  cfg.departureCount=constrain((int)(d["departureCount"]|cfg.departureCount),3,5);
  cfg.departurePoll=constrain((int)(d["departurePoll"]|cfg.departurePoll),10,300);
  cfg.vvoMotMask=((uint8_t)(d["vvoMotMask"]|cfg.vvoMotMask))&VVO_MOT_ALL;
  if(!cfg.vvoMotMask) cfg.vvoMotMask=VVO_MOT_ALL;
  if(d["weatherCity"].is<const char*>()) cfg.weatherCity=d["weatherCity"].as<String>();
  if(d["weatherDisplayName"].is<const char*>()) cfg.weatherDisplayName=d["weatherDisplayName"].as<String>();
  cfg.weatherLat=d["weatherLat"]|cfg.weatherLat; cfg.weatherLon=d["weatherLon"]|cfg.weatherLon;
  cfg.weatherPoll=constrain((int)(d["weatherPoll"]|cfg.weatherPoll),60,3600);
  cfg.weatherTempColor=d["weatherTempColor"]|cfg.weatherTempColor;
  if(d["planePlace"].is<const char*>()) cfg.planePlace=d["planePlace"].as<String>();
  cfg.planeLat=d["planeLat"]|cfg.planeLat; cfg.planeLon=d["planeLon"]|cfg.planeLon;
  cfg.planeRadiusKm=constrain((int)(d["planeRadiusKm"]|cfg.planeRadiusKm),1,250);
  cfg.planePoll=constrain((int)(d["planePoll"]|cfg.planePoll),3,300);
  if(d["trackedFlightNo"].is<const char*>()){cfg.trackedFlightNo=d["trackedFlightNo"].as<String>();cfg.trackedFlightNo.trim();cfg.trackedFlightNo.toUpperCase();}
  if(d["aviationstackKey"].is<const char*>()){String x=d["aviationstackKey"].as<String>();x.trim();if(x.length())cfg.aviationstackKey=x;}
  cfg.trackerStatusPollMin=constrain((int)(d["trackerStatusPollMin"]|cfg.trackerStatusPollMin),5,120);
  JsonArrayConst a=d["countdowns"].as<JsonArrayConst>();if(!a.isNull())for(uint8_t i=0;i<4&&i<a.size();i++){updateCountdownSettings(a[i].as<JsonObjectConst>(),cfg.countdown[i]);if(cfg.countdown[i].active&&cfg.countdown[i].type==COUNTDOWN_DAYS){int32_t dd=0;if(countdownDayDifference(cfg.countdown[i].targetDate,dd)){uint32_t av=dd<0?(uint32_t)(-(int64_t)dd):(uint32_t)dd;cfg.countdown[i].dayDigits=max(cfg.countdown[i].dayDigits,max((uint8_t)3,decimalDigits(av)));}}}
  saveConfig();vvoReset();weatherReset();flightReset();if(oldTracked!=cfg.trackedFlightNo||oldKey!=cfg.aviationstackKey)trackedFlightReset();lastModeSwitchMs=millis();drawActive();
  bool reboot=(oldSsid!=cfg.ssid)||(oldHost!=cfg.hostname);server.send(200,"application/json",reboot?"{\"ok\":true,\"reboot\":true}":"{\"ok\":true,\"reboot\":false}");if(reboot){delay(500);ESP.restart();}
}

static void apiCountdown() {
  if(!server.hasArg("plain")){server.send(400,"application/json","{\"ok\":false,\"error\":\"Keine Daten empfangen.\"}");return;}
  JsonDocument d;if(deserializeJson(d,server.arg("plain"))){server.send(400,"application/json","{\"ok\":false,\"error\":\"Ungültige Daten.\"}");return;}
  int slot=d["slot"]|-1;if(slot<0||slot>3){server.send(400,"application/json","{\"ok\":false,\"error\":\"Ungültiger Countdown-Slot.\"}");return;}
  CountdownSlot& c=cfg.countdown[slot];updateCountdownSettings(d.as<JsonObjectConst>(),c);String action=d["action"]|"";
  if(action=="stop"){c.active=false;}
  else if(action=="start"){
    if(c.type==COUNTDOWN_DAYS){
      int32_t diff=0;if(!countdownDayDifference(c.targetDate,diff)){server.send(409,"application/json","{\"ok\":false,\"error\":\"Zieltag fehlt oder Uhrzeit ist noch nicht synchronisiert\"}");return;}
      uint32_t a=diff<0?(uint32_t)(-(int64_t)diff):(uint32_t)diff;c.dayDigits=max((uint8_t)3,decimalDigits(a));c.active=true;c.targetEpoch=0;
    } else {
      time_t now=time(nullptr);if(now<1609459200){server.send(409,"application/json","{\"ok\":false,\"error\":\"Uhrzeit ist noch nicht synchronisiert\"}");return;}
      if(c.durationSec==0){server.send(400,"application/json","{\"ok\":false,\"error\":\"Dauer muss größer als 0 sein.\"}");return;}
      c.targetEpoch=(uint32_t)now+c.durationSec;c.active=true;
    }
  } else {server.send(400,"application/json","{\"ok\":false,\"error\":\"Unbekannte Aktion.\"}");return;}
  saveConfig();if(countdownSlotFromMode(cfg.mode)==slot)drawCountdown((uint8_t)slot);server.send(200,"application/json","{\"ok\":true}");
}

static void apiStatus() {
  JsonDocument d;d["fw"]=FW_NAME;d["version"]=FW_VERSION;d["ssid"]=apMode?"SmallTV-Setup":WiFi.SSID();d["ip"]=apMode?WiFi.softAPIP().toString():WiFi.localIP().toString();d["rssi"]=apMode?0:WiFi.RSSI();d["heap"]=ESP.getFreeHeap();d["uptime"]=millis()/1000;
  d["vvoCount"]=vvoCount();d["vvoError"]=vvoError();d["weatherValid"]=weatherData().valid;d["weatherError"]=weatherData().error;d["flightValid"]=flightData().valid;d["flightError"]=flightData().error;d["trackerValid"]=trackedFlightData().valid;d["trackerError"]=trackedFlightData().error;sendJson(d);
}

static void apiVvoSearch() {
  if(apMode||WiFi.status()!=WL_CONNECTED){server.send(503,"application/json; charset=utf-8","{\"ok\":false,\"error\":\"Kein Internetzugang.\"}");return;}
  String q=server.arg("q");q.trim();if(q.length()<2){server.send(400,"application/json; charset=utf-8","{\"ok\":false,\"error\":\"Suchbegriff zu kurz.\"}");return;}
  String out;if(!vvoSearchStops(q,out)){server.send(502,"application/json; charset=utf-8","{\"ok\":false,\"error\":\"VVO-Suche fehlgeschlagen.\"}");return;}server.send(200,"application/json; charset=utf-8",out);
}

static void apiGeoSearch() {
  if(apMode||WiFi.status()!=WL_CONNECTED){server.send(503,"application/json; charset=utf-8","{\"ok\":false,\"error\":\"Kein Internetzugang.\"}");return;}
  String q=server.arg("q");q.trim();
  if(q.length()<2){server.send(400,"application/json; charset=utf-8","{\"ok\":false,\"error\":\"Suchbegriff zu kurz.\"}");return;}
  String out;
  if(!geoSearchPlaces(q,out)){server.send(502,"application/json; charset=utf-8","{\"ok\":false,\"error\":\"Ortssuche fehlgeschlagen.\"}");return;}
  server.send(200,"application/json; charset=utf-8",out);
}

static void apiWifiScan() {
  int n=WiFi.scanNetworks(false,false);
  if(n<0){server.send(500,"application/json; charset=utf-8","{\"ok\":false,\"error\":\"WLAN-Suche fehlgeschlagen.\"}");return;}
  JsonDocument d; d["ok"]=true; JsonArray a=d["networks"].to<JsonArray>();
  for(int i=0;i<n;i++){
    String ssid=WiFi.SSID(i); if(!ssid.length())continue;
    JsonObject x=a.add<JsonObject>(); x["ssid"]=ssid; x["rssi"]=WiFi.RSSI(i); x["open"]=(WiFi.encryptionType(i)==ENC_TYPE_NONE);
  }
  WiFi.scanDelete(); sendJson(d);
}

static void setupWeb() {
  server.on("/",HTTP_GET,[]{server.send_P(200,"text/html; charset=utf-8",WEBUI);});
  server.on("/api/config",HTTP_GET,apiGetConfig);server.on("/api/config",HTTP_POST,apiPostConfig);server.on("/api/countdown",HTTP_POST,apiCountdown);server.on("/api/status",HTTP_GET,apiStatus);server.on("/api/vvo/search",HTTP_GET,apiVvoSearch);server.on("/api/geo/search",HTTP_GET,apiGeoSearch);server.on("/api/wifi/scan",HTTP_GET,apiWifiScan);
  server.on("/api/reboot",HTTP_POST,[]{server.send(200,"application/json","{\"ok\":true}");delay(300);ESP.restart();});updater.setup(&server,"/update");
  server.onNotFound([](){if(apMode){server.sendHeader("Location","http://192.168.4.1/",true);server.send(302,"text/plain","");}else server.send(404,"text/plain","Nicht gefunden");});server.begin();
}

// ---- setup / loop ------------------------------------------------------------
void setup() {
  Serial.begin(115200);
  analogWriteRange(255);
  pinMode(TFT_BL,OUTPUT);

  bus = new Arduino_HWSPI(TFT_DC,TFT_CS);
  gfx = new SmallTV_ST7789(bus,TFT_RST,0,true,TFT_W,TFT_H,0,0,0,80);
  gfx->begin();
  gfx->setRotation(0);
  gfx->setTextWrap(false);
  gfx->fillScreen(C_BLACK);
  centerText("SmallTV DD",82,3,C_YELLOW);
  centerText(FW_VERSION,118,2,C_GRAY);

  loadConfig();
  applyBrightness();
  connectWiFi();
  setupWeb();

  if(!apMode){
    gfx->fillScreen(C_BLACK);
    centerText("VERBUNDEN",50,3,C_GREEN);
    centerText(WiFi.localIP().toString(),105,2,C_WHITE);
    centerText(cfg.hostname+".local",137,2,C_GRAY);
    delay(2200);
    drawActive();
    lastModeSwitchMs=millis();
  }
}

void loop() {
  server.handleClient();
  if(apMode)dns.processNextRequest();else MDNS.update();

  uint32_t nowMs=millis();
  if(nowMs-lastSecond>=1000){
    lastSecond=nowMs; applyBrightness();
    time_t ep=time(nullptr);
    if(ep>1609459200){
      struct tm t; localtime_r(&ep,&t);
      if(t.tm_min!=lastMinute){
        lastMinute=t.tm_min;
        if(cfg.mode==MODE_CLOCK) drawClock(false);
        else if(cfg.mode==MODE_DEPARTURES||cfg.mode==MODE_WEATHER||cfg.mode==MODE_PLANE||(cfg.mode==MODE_TRACKED_FLIGHT&&trackedFlightData().valid)) drawFooterClockOnly();
      }
    }
    int8_t slot=countdownSlotFromMode(cfg.mode);
    if(slot>=0){
      String visible=countdownValue(cfg.countdown[(uint8_t)slot]);
      if(visible!=lastCountdownRendered[(uint8_t)slot]) drawCountdown((uint8_t)slot);
    }
  }

  // View rotation is separate from data refreshes. API data can stay fresh while hidden.
  if(!apMode&&enabledModeCount()>1){
    uint32_t stayMs=(uint32_t)max((uint16_t)5,cfg.rotationSec[cfg.mode])*1000UL;
    if(nowMs-lastModeSwitchMs>=stayMs){
      cfg.mode=nextEnabledMode(cfg.mode); lastModeSwitchMs=nowMs; drawActive();
    }
  }

  if(!apMode&&modeEnabled(MODE_DEPARTURES)&&cfg.stopId.length()&&vvoPollDue(cfg.departurePoll)){
    vvoFetchDepartures(cfg.stopId,cfg.departureCount,cfg.vvoMotMask);
    if(cfg.mode==MODE_DEPARTURES)drawDepartures();
  }
  if(!apMode&&modeEnabled(MODE_WEATHER)&&weatherPollDue(cfg.weatherPoll)){
    weatherFetch(cfg.weatherLat,cfg.weatherLon);
    if(cfg.mode==MODE_WEATHER)drawWeather();
  }
  if(!apMode&&modeEnabled(MODE_PLANE)&&flightPollDue(cfg.planePoll)){
    flightFetch(cfg.planeLat,cfg.planeLon,cfg.planeRadiusKm);
    if(cfg.mode==MODE_PLANE)drawPlane();
  }
  // Keep Aviationstack conservative: tracker is refreshed only while its view is visible.
  if(!apMode&&cfg.mode==MODE_TRACKED_FLIGHT&&cfg.trackedFlightNo.length()&&cfg.aviationstackKey.length()){
    if(trackedFlightStatusPollDue(cfg.trackerStatusPollMin)){trackedFlightFetchStatus(cfg.aviationstackKey,cfg.trackedFlightNo);drawTrackedFlight();}
    if(trackedFlightLivePollDue(15)){trackedFlightFetchLive();drawTrackedFlight();}
  }
  yield();
}

