# SmallTV Deutsch/VVO

Experimentelle Firmware für den **GeekMagic SmallTV-Ultra** mit ESP8266 und 240×240-ST7789-Display.

## v0.1

Diese Version ist absichtlich ein **Layout- und Infrastruktur-Prototyp**. Sie soll vor dem ersten echten Flash zeigen, dass unsere gewünschte Struktur sauber auf den ESP8266 passt.

Enthalten:

- deutsches lokales Webinterface
- WLAN-Einrichtung mit Fallback-Hotspot `SmallTV-Setup`
- vier auswählbare Ansichten
  - Abfahrten
  - Wetter
  - Flugradar
  - Uhr
- Helligkeit
- Nachtmodus
- NTP-Zeit für Europa/Berlin
- LittleFS-Konfiguration
- OTA-Firmwareupdate über `/update`
- auf dem Display zunächst **Testdaten**, noch keine echten API-Abfragen

## Geplante Datenquellen

- Abfahrten: VVO
- Wetter: Open-Meteo
- Flugradar: adsb.lol plus Routendaten

## Sicherheit beim ersten Test

Noch **nicht auf den SmallTV flashen**, bevor der GitHub-Actions- oder lokale PlatformIO-Build für `smalltv_ultra` erfolgreich durchgelaufen ist und die Firmwaregröße geprüft wurde.

Beim SmallTV-Ultra mit Stock-Firmware `Ultra-V9.0.50` wird für den ersten Wechsel auf eine eigene Firmware voraussichtlich der zweistufige Loader-Weg benötigt.

## Webinterface

Im WLAN ist das Gerät unter seiner IP bzw. standardmäßig als `smalltv-dd.local` erreichbar.

Beim ersten Start ohne gespeichertes WLAN öffnet es den Hotspot:

- SSID: `SmallTV-Setup`
- Adresse: `http://192.168.4.1`

## Basis

Display-Pinbelegung und der für dieses Panel nötige SPI-Modus orientieren sich an `giovi321/smalltv-mod`, Lizenz WTFPL.
