# v0.1 Testplan

## Noch nicht flashen

Diese v0.1 ist zum ersten Build gedacht. Vor dem echten Gerät prüfen:

1. `pio run -e smalltv_ultra` muss erfolgreich sein.
2. Firmwaregröße muss in den OTA-Slot des 4M1M-Layouts passen.
3. Static RAM und freier Heap werden im Build bzw. später unter `/api/status` geprüft.
4. Erst dann wird der Ultra-Loader benutzt.

## Was v0.1 auf dem Display macht

- Abfahrten: 3 bis 5 Beispielzeilen, Haltestellenname aus der Web-Konfiguration
- Wetter: Beispielwerte in minimalistischem Layout
- Flugradar: ein Beispiel-Flug
- Uhr: echte NTP-Zeit, sobald WLAN und NTP funktionieren

## v0.2

- VVO-Haltestellensuche
- echte VVO-Abfahrten
- sauberer Zustand `JETZT` / `AUS`
- Offline-Markierung und letzter erfolgreicher Abruf

## v0.3

- Open-Meteo
- eigene Wettericons
- H/T, Regenwahrscheinlichkeit, Sonnenaufgang/-untergang

## v0.4

- adsb.lol
- nächstes Flugzeug
- Route-Anreicherung
- Airline- und Typauflösung
