#!/usr/bin/env python3
"""Compile real display functions against a recorder, including partial radar updates."""
from pathlib import Path
import re,subprocess,tempfile,os
root=Path(__file__).resolve().parents[1]
s=(root/'src/main.cpp').read_text()
def fn(name):
 m=re.search(r'^static [^\n]+\b'+name+r'\([^\n]*\) \{',s,re.M);assert m,name
 i=s.index('{',m.start());depth=1;j=i+1
 while depth:
  if s[j]=='{':depth+=1
  if s[j]=='}':depth-=1
  j+=1
 return s[m.start():j]
def struct(name,file):
 return 'struct '+name+' {'+(root/'src'/file).read_text().split('struct '+name+' {',1)[1].split('};',1)[0]+'};'
pre=r'''
#include <string>
#include <vector>
#include <cassert>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include "PixelFont.h"
#include "FlightRoute.h"
#include "WeatherVisual.h"
struct String:std::string {
 using std::string::string;
 String(const std::string& s):std::string(s){}
 String(int n):std::string(std::to_string(n)){}
 String(float n,int digits){char b[48];snprintf(b,sizeof(b),"%.*f",digits,(double)n);assign(b);}
 String substring(size_t a,size_t b)const{return substr(a,b-a);}
};
struct Draw {String text;int y,size;};
struct Rect {int x,y,w,h,color;};
struct Circle {int x,y,r,color;};
struct Line {int x,y,x2,y2,color;};
std::vector<Draw> draws;std::vector<Rect> rects;std::vector<Circle> circles;std::vector<Line> lines;
String footer;int fullScreens=0;
struct Gfx {
 int x=0,y=0,size=1;
 void fillScreen(int){fullScreens++;} void setTextSize(int n){size=n;} void setTextColor(int){}
 void setCursor(int a,int b){x=a;y=b;} void print(const String& t){draws.push_back({t,y,size});}
 void write(uint8_t){x+=6*size;} void fillRect(int x,int y,int w,int h,int c){rects.push_back({x,y,w,h,c});}
 void fillCircle(int x,int y,int r,int c){circles.push_back({x,y,r,c});}
 void drawLine(int x,int y,int x2,int y2,int c){lines.push_back({x,y,x2,y2,c});}
 void drawFastHLine(int x,int y,int w,int c){drawLine(x,y,x+w-1,y,c);}
} display;
Gfx* gfx=&display;
const double PI=3.14159265358979323846;
const int C_BLACK=0,C_WHITE=1,C_YELLOW=2,C_GRAY=3,C_RED=4,C_GREEN=5,C_CYAN=6,C_DGRAY=7,TFT_W=240;
void centerText(const String& s,int y,int size,int){draws.push_back({s,y,size});}
void drawFooter(const char* s){footer=s;}
String displayAscii(String s){return s;}
String flightStatusGerman(const char*){return "STATUS";}
struct Settings{String trackedFlightNo,aviationstackKey,planePlace,planeDisplayName;bool planeShowPlace=false;} cfg;
bool planePlacePhase=false;
'''
pre+='\n'+struct('TrackedFlightSnapshot','TrackFlight.h')+'\n'+struct('FlightSnapshot','Flight.h')
pre+=r'''
TrackedFlightSnapshot data={};FlightSnapshot plane={};FlightSnapshot lastPlaneRendered={};bool planeRendered=false;
const TrackedFlightSnapshot& trackedFlightData(){return data;}
const FlightSnapshot& flightData(){return plane;}
String trackedFlightDuration(const TrackedFlightSnapshot&){return "01:30";}
void clearDraws(){draws.clear();rects.clear();circles.clear();lines.clear();fullScreens=0;footer="not drawn";}
'''
post=r'''
int main(){
 FlightRoute route={};
 for(const char* text:{"OSL-IST","LEJ-BLR-HKG","AAA-BBB-CCC-DDD","AAA-BBB-CCC-DDD-EEE-FFF-GGG-HHH","AAA-BBB-CCC-DDD-EEE-FFF-GGG-HHH-III"}){
   assert(parseFlightRoute(text,route));clearDraws();
   drawFlightRoute(route,route.airports[0],route.airports[route.count-1],105);
   for(auto d:draws){assert(textW(d.text,d.size)<=224);assert(d.y>=105&&d.y+d.size*7<=133);}
   if(route.count==2){assert(draws.size()==1&&draws[0].text=="OSL > IST"&&draws[0].size==3&&draws[0].y==105);}
 }
 cfg={};clearDraws();drawTrackedFlight();assert(footer=="");
 bool hint=false;for(auto d:draws)if(d.text=="Webinterface eingeben")hint=true;assert(hint);
 cfg.trackedFlightNo="AF1234";footer="not drawn";drawTrackedFlight();assert(footer=="");
 cfg.aviationstackKey="fixture";footer="";drawTrackedFlight();assert(footer=="LADE FLUGDATEN");
 data.error=true;footer="";drawTrackedFlight();assert(footer=="TRACKER FEHLER");
 data.error=false;data.notFound=true;footer="";drawTrackedFlight();assert(footer=="FLUG NICHT GEFUNDEN");
 data.valid=true;data.notFound=false;strcpy(data.origin,"OSL");strcpy(data.destination,"IST");
 strcpy(data.arrActual,"N/A");clearDraws();drawTrackedFlight();assert(footer=="AVIATIONSTACK + ADSB.LOL");
 assert(draws[1].text=="OSL > IST"&&draws[1].y==36&&draws[1].size==3);
 data.error=true;footer="";drawTrackedFlight();assert(footer=="LETZTER STAND");
 // Radar: same ICAO -> only changed visible fields; new aircraft -> complete redraw.
 plane.valid=true;strcpy(plane.hex,"abc123");strcpy(plane.callsign,"THY1JU");strcpy(plane.registration,"TC-JRS");
 strcpy(plane.origin,"OSL");strcpy(plane.destination,"IST");plane.distanceKm=12.8f;plane.altitudeFt=33000;
 clearDraws();drawPlane();assert(fullScreens==1&&footer=="ADSB.LOL LIVE");
 clearDraws();drawPlane(false);assert(fullScreens==0&&rects.empty()&&draws.empty()&&footer=="not drawn");
 plane.distanceKm=9.7f;clearDraws();drawPlane(false);assert(fullScreens==0&&rects.size()==1&&draws.size()==1);
 assert(rects[0].x==8&&rects[0].y==190&&rects[0].w==112&&rects[0].h==24);assert(draws[0].text=="9.7 km");
 plane.altitudeFt=30000;clearDraws();drawPlane(false);assert(fullScreens==0&&rects.size()==1&&rects[0].x==120);
 strcpy(plane.airline,"Turkish Airlines");clearDraws();drawPlane(false);assert(fullScreens==0&&rects.size()==1&&rects[0].y==78);
 parseFlightRoute("OSL-LEJ-IST",plane.route);clearDraws();drawPlane(false);assert(fullScreens==0&&rects.size()==1&&rects[0].y==102);
 plane.error=true;clearDraws();drawPlane(false);assert(fullScreens==0&&footer=="LETZTER STAND");
 strcpy(plane.hex,"def456");clearDraws();drawPlane(false);assert(fullScreens==1);
 plane.valid=false;clearDraws();drawPlane(false);assert(fullScreens==1&&footer=="ABRUF FEHLGESCHLAGEN");
 plane.error=false;clearDraws();drawPlane(false);assert(fullScreens==1&&footer=="ADSB.LOL");
 // Weather motifs: night partly clouded must have a moon; fog has no cloud.
 clearDraws();drawWeatherIcon(2,false);assert(circles.size()==5&&circles[0].color==C_WHITE&&circles[1].color==C_BLACK);
 clearDraws();drawWeatherIcon(45,true);assert(circles.empty()&&rects.size()==4&&lines.empty());
 clearDraws();drawWeatherIcon(51,true);auto drizzle=lines.size();assert(drizzle==2);
 clearDraws();drawWeatherIcon(55,true);assert(lines.size()==6);
 clearDraws();drawWeatherIcon(61,true);assert(lines[0].y2-lines[0].y==10);
 clearDraws();drawWeatherIcon(71,true);assert(lines.size()==8);
 clearDraws();drawWeatherIcon(77,true);assert(circles.size()==5&&circles[3].r==1);
 clearDraws();drawWeatherIcon(96,true);assert(circles.size()==5&&circles[3].r==2&&lines.size()==3);
 for(int code:{0,1,2,3,45,48,51,53,55,56,57,61,63,65,66,67,71,73,75,77,80,81,82,85,86,95,96,99})for(bool day:{false,true}){
   clearDraws();drawWeatherIcon(code,day);
   for(auto q:rects)assert(q.x>=0&&q.x+q.w<=240&&q.y>=22&&q.y+q.h<=88);
   for(auto q:circles)assert(q.x-q.r>=0&&q.x+q.r<240&&q.y-q.r>=22&&q.y+q.r<=87);
   for(auto q:lines)assert(q.x>=0&&q.x2>=0&&q.x<240&&q.x2<240&&q.y>=22&&q.y2>=22&&q.y<=87&&q.y2<=87);
 }
 // Actual glyph renderer: one cell per Greek/Cyrillic letter; width/crop agree.
 String title="Київ Αθήνα";assert(glyphCount(title)==10&&textW(title,2)==120);
 assert(crop("Москва",4)=="Мос.");clearDraws();printDisplayTextAt(0,0,"Ж",2,C_WHITE);assert(!rects.empty());
 for(auto q:rects)assert(q.x+q.w<=10&&q.y+q.h<=14);
 puts("Real display: selective radar/new aircraft, stale states, tracker footer, weather motifs and Unicode bounds OK");
}
'''
names=['nextCodepoint','glyphCount','drawSpecialGlyph','printDisplayTextAt','textW','crop','planePlaceTitle','drawPlaneHeader','routePart','drawFlightRoute','samePlane','planeDistance','planeAltitude','drawPlane','drawTrackedFlight','drawCloud','drawSun','drawMoon','drawSnowflake','drawWeatherIcon']
with tempfile.TemporaryDirectory() as t:
 p=Path(t);(p/'test.cpp').write_text(pre+'\n'+'\n'.join(fn(name) for name in names)+'\n'+post)
 subprocess.run(['g++','-std=c++11','-Wall','-Wextra','-Werror','-I'+str(root/'src'),str(p/'test.cpp'),'-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],check=True)
