# Validierung v0.4.7

## Erfolgreich ausgeführt

- Vollständiger PlatformIO-Build für smalltv_ultra, ESP8266-Plattform 4.2.1,
  Arduino-Core 3.1.2, ArduinoJson 7.4.3, GFX Library for Arduino 1.6.8.
- Statischer RAM: 48.052 / 81.920 Byte, 58,7 %.
- Programm-Flash: 672.839 / 1.044.464 Byte, 64,4 %.
- UTF-8, lateinische/griechische/kyrillische Glyphen, zusammengesetzte Akzente,
  Herzen, Routen und Kürzung mit C++11 und Warnungen als Fehlern geprüft.
- Zeitzonen: Auswahlvalidierung sowie Sommer-/Winterfälle für Berlin,
  New York, Tokyo und Sydney. POSIX-Regeln im Flash; 50 IDs.
- Wetter: alle 28 unterstützten Codes, Beschriftungen und tatsächliche
  Zeichenfunktionen bei Tag/Nacht auf Grenzen des Iconbereichs geprüft.
- Radar: reale Vorab-Speicherprüfungen, Poll-Timer, Fehlerzustände,
  30-Sekunden-Ablauf, Wiederaufnahme und millis-Überlauf im Hosttest.
  Die gemeldeten Screenshotwerte lassen den Request bei 512/1024/4096 Byte
  RX zu. Das beweist keine erfolgreiche TLS-Verbindung auf dem Gerät.
- Tatsächliche Displayfunktionen mit aufgezeichneten Zeichenoperationen:
  keine Änderung ohne neue sichtbare Werte; Teilupdates bei Entfernung,
  Höhe, Airline und Route; Vollupdate bei neuem Flugzeug; Wechsel zwischen
  LIVE, LETZTER STAND, Fehler und leerer erfolgreicher Antwort.
- Tracker-Footer ohne Flugnummer oder API-Key enthält nur die Uhr.

## Noch am Gerät zu prüfen

TLS-Verbindungsaufbau bei realer Fragmentierung, HTTP-Antwortgrößen,
Radar-Dauerlauf, Displaywirkung, NTP nach Neustart, native Safari-Bedienelemente
und Betrieb mit mehr als zwei Programmen. Diese Firmware wurde hier nicht
auf einem echten SmallTV ausgeführt. GitHub wurde nicht verändert.

## Browserprüfung

Playwright-WebKit besteht lokal an allen neun Breiten von 320 bis 1024 Pixeln.
Geprüft: Nachtzeitfelder, Abstände, kein Seitenüberlauf, Radar-Beschriftungen,
abhängige Auswahl sowie Laden und Speichern der Zeitzone. Der lokale Lauf
verwendete unveränderte WebKit-Binaries mit separat entpackten Systembibliotheken.
Der GitHub-Workflow installiert die Bibliotheken regulär und führt dieselben
Assertions aus. Echtes iOS-Safari bleibt ein gesonderter Gerätetest.
