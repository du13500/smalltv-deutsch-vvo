#include "Flight.h"
#include "RadarPolicy.h"
#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>
#include <WiFiClientSecureBearSSL.h>
#include <ArduinoJson.h>
#include <math.h>

static FlightSnapshot g_f = {};
static uint32_t g_lastPollMs = 0;
static bool g_hasPolled = false;
static uint32_t g_lastOkMs = 0;
static uint32_t g_firstFailureMs = 0;
static uint8_t g_consecutiveFailures = 0;
static BearSSL::Session g_adsbSession;
static BearSSL::Session g_routeSession;
static BearSSL::Session g_adsbDbSession;
static uint16_t g_adsbLolRx = 0;
static int g_lastHttp = 0;
static const char* g_stage = "bereit";
static char g_routeCallsign[12] = "";
static char g_routeOrigin[4] = "N/A";
static char g_routeDestination[4] = "N/A";
static FlightRoute g_routeChain = {};
static uint32_t g_routeLastAttemptMs = 0;
static bool g_routeRetryDone = false;

static uint16_t adsbLolRx() {
  if (g_adsbLolRx) return g_adsbLolRx;
  if (BearSSL::WiFiClientSecure::probeMaxFragmentLength("api.adsb.lol", 443, 512)) g_adsbLolRx = 512;
  else if (BearSSL::WiFiClientSecure::probeMaxFragmentLength("api.adsb.lol", 443, 1024)) g_adsbLolRx = 1024;
  else g_adsbLolRx = 4096;
  return g_adsbLolRx;
}

static bool tlsHeapReady(uint16_t rx) {
  return radarTlsFits(ESP.getFreeHeap(), ESP.getMaxFreeBlockSize(), rx, sizeof(br_ssl_client_context));
}

static void makeSecure(BearSSL::WiFiClientSecure& client, BearSSL::Session* session, uint16_t rxBuf = 4096) {
  client.setInsecure();
  client.setBufferSizes(rxBuf, 512);
  client.setSession(session);
  client.setTimeout(9000);
}

static void trimTail(char* s) {
  int n = strlen(s);
  while (n > 0 && (s[n-1] == ' ' || s[n-1] == '\t')) s[--n] = 0;
}

static float distanceKm(float lat1, float lon1, float lat2, float lon2) {
  float dLat = (lat2 - lat1) * 111.0f;
  float dLon = (lon2 - lon1) * 111.0f * cosf(lat1 * (float)PI / 180.0f);
  return sqrtf(dLat*dLat + dLon*dLon);
}

static const char* airlineFor(const char* cs) {
  if (!cs || strlen(cs) < 3) return "";
  struct M { const char* p; const char* n; };
  static const M map[] = {
    {"EWG","Eurowings"},{"DLH","Lufthansa"},{"RYR","Ryanair"},{"EJU","easyJet"},
    {"EZY","easyJet"},{"CFG","Condor"},{"WZZ","Wizz Air"},{"TVS","Smartwings"},
    {"AUA","Austrian"},{"SWR","SWISS"},{"KLM","KLM"},{"AFR","Air France"},
    {"BAW","British Airways"},{"LOT","LOT"},{"SAS","SAS"},{"THY","Turkish Airlines"},
    {"BEL","Brussels Airlines"},{"UAE","Emirates"},{"QTR","Qatar Airways"},{"EXS","Jet2"},
    {"TUI","TUI"},{"ITY","ITA Airways"},{"IBE","Iberia"},{"VLG","Vueling"}
  };
  for (const auto& m : map) if (!strncmp(cs, m.p, 3)) return m.n;
  return "";
}

static const char* typeNameFor(const char* t) {
  if (!t || !*t) return "";
  struct M { const char* c; const char* n; };
  static const M map[] = {
    {"A20N","Airbus A320neo"},{"A21N","Airbus A321neo"},{"A320","Airbus A320"},
    {"A321","Airbus A321"},{"A319","Airbus A319"},{"A318","Airbus A318"},
    {"A359","Airbus A350-900"},{"A35K","Airbus A350-1000"},{"A333","Airbus A330-300"},
    {"A332","Airbus A330-200"},{"B738","Boeing 737-800"},{"B737","Boeing 737-700"},
    {"B38M","Boeing 737 MAX 8"},{"B39M","Boeing 737 MAX 9"},{"B788","Boeing 787-8"},
    {"B789","Boeing 787-9"},{"B772","Boeing 777-200"},{"B77W","Boeing 777-300ER"},
    {"E190","Embraer E190"},{"E195","Embraer E195"},{"E290","Embraer E190-E2"},
    {"E295","Embraer E195-E2"},{"CRJ9","CRJ900"},{"BCS1","Airbus A220-100"},
    {"BCS3","Airbus A220-300"},{"AT76","ATR 72-600"},{"DH8D","Dash 8 Q400"}
  };
  for (const auto& m : map) if (!strcmp(t, m.c)) return m.n;
  return t;
}

static void routeFallback(char outOrigin[4], char outDestination[4]) {
  strlcpy(outOrigin, "N/A", 4);
  strlcpy(outDestination, "N/A", 4);
}

static bool routeComplete(const char origin[4], const char destination[4]) {
  return routeCode(origin) && routeCode(destination);
}

static bool lookupRouteAdsbLol(const char* callsign, float lat, float lon, char origin[4], char destination[4], FlightRoute& chain) {
  if (!tlsHeapReady(g_adsbLolRx ? g_adsbLolRx : 512)) return false;
  const uint16_t rx=adsbLolRx();
  if (!tlsHeapReady(rx)) return false;
  BearSSL::WiFiClientSecure client;
  makeSecure(client, &g_routeSession, rx);
  HTTPClient http;
  http.useHTTP10(true);
  http.setTimeout(9000);
  http.setReuse(false);
  if (!http.begin(client, "https://api.adsb.lol/api/0/routeset")) return false;
  http.addHeader("Content-Type", "application/json");
  http.addHeader("Accept", "application/json");
  http.setUserAgent("SmallTV-DD/0.4.7");

  JsonDocument req;
  JsonArray planes = req["planes"].to<JsonArray>();
  JsonObject p = planes.add<JsonObject>();
  p["callsign"] = callsign;
  p["lat"] = lat;
  p["lng"] = lon;
  String body;
  serializeJson(req, body);

  int code = http.POST(body);
  if (code != HTTP_CODE_OK) { http.end(); return false; }

  JsonDocument filter;
  JsonArray filterArray = filter.to<JsonArray>();
  JsonObject filterItem = filterArray.add<JsonObject>();
  filterItem["_airport_codes_iata"] = true;
  JsonDocument doc;
  DeserializationError err = deserializeJson(doc, http.getStream(), DeserializationOption::Filter(filter));
  http.end();
  if (err || !doc.is<JsonArrayConst>() || doc.as<JsonArrayConst>().size() == 0) return false;

  String route = doc[0]["_airport_codes_iata"] | "";
  route.trim();
  if (!route.length() || route == "unknown") return false;
  if (!parseFlightRoute(route.c_str(), chain)) return false;
  strlcpy(origin, chain.airports[0], 4);
  // Preserve the true final airport even if the bounded display chain overflows.
  String last=route.substring(route.lastIndexOf('-')+1);last.trim();last.toUpperCase();
  strlcpy(destination, last.c_str(), 4);
  return routeComplete(origin, destination);
}

static bool lookupRouteAdsbDb(const char* callsign, char origin[4], char destination[4], FlightRoute& chain) {
  if (!tlsHeapReady(4096)) return false;
  BearSSL::WiFiClientSecure client;
  makeSecure(client, &g_adsbDbSession);
  HTTPClient http;
  http.useHTTP10(true);
  http.setTimeout(9000);
  http.setReuse(false);
  String url = F("https://api.adsbdb.com/v0/callsign/");
  url += callsign;
  if (!http.begin(client, url)) return false;
  http.addHeader("Accept", "application/json");
  http.setUserAgent("SmallTV-DD/0.4.7");

  int code = http.GET();
  if (code != HTTP_CODE_OK) { http.end(); return false; }

  JsonDocument filter;
  filter["response"]["flightroute"]["origin"]["iata_code"] = true;
  filter["response"]["flightroute"]["destination"]["iata_code"] = true;
  filter["response"]["flightroute"]["midpoint"]["iata_code"] = true;
  JsonDocument doc;
  DeserializationError err = deserializeJson(doc, http.getStream(), DeserializationOption::Filter(filter));
  http.end();
  if (err) return false;

  String a = doc["response"]["flightroute"]["origin"]["iata_code"] | "";
  String b = doc["response"]["flightroute"]["destination"]["iata_code"] | "";
  a.trim(); b.trim(); a.toUpperCase(); b.toUpperCase();
  if (a.length() == 3) strlcpy(origin, a.c_str(), 4);
  if (b.length() == 3) strlcpy(destination, b.c_str(), 4);
  if (!routeComplete(origin,destination)) return false;
  chain={};appendRouteAirport(chain,origin);
  String midpoint=doc["response"]["flightroute"]["midpoint"]["iata_code"] | "";
  midpoint.trim();midpoint.toUpperCase();
  if(midpoint.length())appendRouteAirport(chain,midpoint.c_str());
  appendRouteAirport(chain,destination);
  return true;
}

static bool performRouteLookup(const char* callsign, float lat, float lon, char origin[4], char destination[4], FlightRoute& chain) {
  routeFallback(origin, destination);
  chain={};
  bool ok = !isnan(lat) && !isnan(lon) && lookupRouteAdsbLol(callsign, lat, lon, origin, destination, chain);
  if (!ok) {
    routeFallback(origin, destination);
    ok = lookupRouteAdsbDb(callsign, origin, destination, chain);
  }
  return ok;
}

static bool lookupRoute(const char* callsign, float lat, float lon, char origin[4], char destination[4], FlightRoute& chain) {
  routeFallback(origin, destination);
  if (!callsign || strlen(callsign) < 3) return false;

  const bool sameCallsign = !strcmp(callsign, g_routeCallsign);
  if (sameCallsign) {
    strlcpy(origin, g_routeOrigin, 4);
    strlcpy(destination, g_routeDestination, 4);
    chain=g_routeChain;

    // Positive Treffer bleiben fuer diesen Callsign gecacht.
    if (routeComplete(origin, destination)) return true;

    // Ein N/A darf genau einmal nach 60 Sekunden erneut geprueft werden.
    // Danach bleibt es bei N/A, bis ein anderer Callsign zum naechsten Flugzeug wird.
    if (g_routeRetryDone || (uint32_t)(millis() - g_routeLastAttemptMs) < 60000UL) return false;
    g_routeRetryDone = true;
  } else {
    // Neuer Callsign: genau einen regulaeren Lookup starten und Cache zuruecksetzen.
    strlcpy(g_routeCallsign, callsign, sizeof(g_routeCallsign));
    strlcpy(g_routeOrigin, "N/A", sizeof(g_routeOrigin));
    strlcpy(g_routeDestination, "N/A", sizeof(g_routeDestination));
    g_routeRetryDone = false;
    g_routeChain = {};
  }

  g_routeLastAttemptMs = millis();
  bool ok = performRouteLookup(callsign, lat, lon, origin, destination, chain);
  strlcpy(g_routeOrigin, origin, sizeof(g_routeOrigin));
  strlcpy(g_routeDestination, destination, sizeof(g_routeDestination));
  g_routeChain=chain;
  return ok;
}

void flightReset() {
  memset(&g_f, 0, sizeof(g_f));
  g_lastPollMs = 0;
  g_hasPolled = false;
  g_lastOkMs = 0;
  g_firstFailureMs = 0;
  g_consecutiveFailures = 0;
  g_routeCallsign[0] = 0;
  g_routeChain={};
  strlcpy(g_routeOrigin, "N/A", sizeof(g_routeOrigin));
  strlcpy(g_routeDestination, "N/A", sizeof(g_routeDestination));
  g_routeLastAttemptMs = 0;
  g_routeRetryDone = false;
  g_lastHttp = 0;
  g_stage = "bereit";
}

bool flightPollDue(uint16_t pollSec) {
  if (!g_hasPolled) return true;
  return (uint32_t)(millis() - g_lastPollMs) >= (uint32_t)pollSec * 1000UL;
}

const FlightSnapshot& flightData() { return g_f; }
uint32_t flightLastOkMs() { return g_lastOkMs; }
const char* flightStageName() { return g_stage; }
int flightLastHttp() { return g_lastHttp; }
uint16_t flightTlsRx() { return g_adsbLolRx; }
uint32_t flightTlsMinBlock() { return radarTlsBudget(g_adsbLolRx ? g_adsbLolRx : 512, sizeof(br_ssl_client_context)).block; }
bool flightExpire() {
  if(!radarExpired(millis(),g_lastOkMs,g_f.valid))return false;
  g_f.valid=false;g_f.error=true;g_stage="Daten veraltet";
  return true;
}

static bool flightFailure(const char* stage = "Fehler") {
  g_stage = stage;
  uint32_t now = millis();
  if (g_consecutiveFailures == 0) g_firstFailureMs = now;
  if (g_consecutiveFailures < 255) g_consecutiveFailures++;
  uint32_t since = g_lastOkMs ? (uint32_t)(now - g_lastOkMs) : (uint32_t)(now - g_firstFailureMs);
  g_f.error = true;
  if (since >= RADAR_MAX_AGE_MS) {
    g_f.valid = false;
    g_f.error = true;
  }
  return false;
}

static void flightSuccess(const char* stage = "ok") {
  g_stage = stage;
  g_consecutiveFailures = 0;
  g_firstFailureMs = 0;
  g_lastOkMs = millis();
}

bool flightFetch(float homeLat, float homeLon, uint16_t radiusKm) {
  g_lastPollMs = millis();
  g_hasPolled = true;
  g_lastHttp = 0;
  if (WiFi.status() != WL_CONNECTED) return flightFailure("kein WLAN");
  if (!tlsHeapReady(g_adsbLolRx ? g_adsbLolRx : 512)) return flightFailure("übersprungen: Heap");
  const uint16_t rx=adsbLolRx();
  if (!tlsHeapReady(rx)) return flightFailure("übersprungen: Heap");

  uint16_t radiusNm = (uint16_t)ceilf(radiusKm / 1.852f);
  if (radiusNm < 1) radiusNm = 1;
  if (radiusNm > 250) radiusNm = 250;

  FlightSnapshot next = {};
  char routeOrigin[4] = "N/A";
  char routeDestination[4] = "N/A";
  float acLat = NAN, acLon = NAN;

  {
    BearSSL::WiFiClientSecure client;
    makeSecure(client, &g_adsbSession, rx);
    HTTPClient http;
    http.useHTTP10(true);
    http.setTimeout(9000);
    http.setReuse(false);

    String url = F("https://api.adsb.lol/v2/closest/");
    url += String(homeLat, 4); url += '/';
    url += String(homeLon, 4); url += '/';
    url += String(radiusNm);
    if (!http.begin(client, url)) return flightFailure("Verbindung fehlgeschlagen");
    http.addHeader("Accept", "application/json");
    http.setUserAgent("SmallTV-DD/0.4.7");

    int code = http.GET();
    g_lastHttp = code;
    if (code != HTTP_CODE_OK) { http.end(); return flightFailure(code < 0 ? "Verbindung fehlgeschlagen" : "HTTP-Fehler"); }

    JsonDocument filter;
    JsonObject f = filter["ac"][0].to<JsonObject>();
    f["flight"] = true; f["r"] = true; f["t"] = true;
    f["lat"] = true; f["lon"] = true; f["alt_baro"] = true; f["hex"] = true;
    JsonDocument doc;
    DeserializationError err = deserializeJson(doc, http.getStream(), DeserializationOption::Filter(filter));
    http.end();
    if (err) return flightFailure("JSON-Fehler");

    JsonArrayConst ac = doc["ac"].as<JsonArrayConst>();
    if (ac.isNull() || ac.size() == 0) {
      memset(&g_f, 0, sizeof(g_f));
      g_f.error = false;
      flightSuccess("keine Flugzeuge");
      return true;
    }

    JsonObjectConst a = ac[0].as<JsonObjectConst>();
    const char* rawCall = a["flight"] | (a["hex"] | "");
    strlcpy(next.callsign, rawCall, sizeof(next.callsign));
    trimTail(next.callsign);
    strlcpy(next.hex, a["hex"] | "", sizeof(next.hex));
    strlcpy(next.registration, a["r"] | "", sizeof(next.registration));
    strlcpy(next.typeCode, a["t"] | "", sizeof(next.typeCode));
    strlcpy(next.typeName, typeNameFor(next.typeCode), sizeof(next.typeName));
    strlcpy(next.airline, airlineFor(next.callsign), sizeof(next.airline));
    next.altitudeFt = a["alt_baro"].is<int>() ? a["alt_baro"].as<int>() : 0;
    if (a["lat"].is<float>() || a["lat"].is<int>()) acLat = a["lat"].as<float>();
    if (a["lon"].is<float>() || a["lon"].is<int>()) acLon = a["lon"].as<float>();
    if (!isnan(acLat) && !isnan(acLon)) next.distanceKm = distanceKm(homeLat, homeLon, acLat, acLon);
    next.valid = true;
    next.error = false;
  }

  if (next.callsign[0] && !isnan(acLat) && !isnan(acLon)) {
    lookupRoute(next.callsign, acLat, acLon, routeOrigin, routeDestination, next.route);
  }
  strlcpy(next.origin, routeOrigin, sizeof(next.origin));
  strlcpy(next.destination, routeDestination, sizeof(next.destination));

  g_f = next;
  flightSuccess();
  return true;
}

