#pragma once
#include <Arduino.h>
#include "FlightRoute.h"

struct FlightSnapshot {
  bool valid;
  bool error;
  char hex[8]; // ICAO address identifies the aircraft even when callsign changes.
  char callsign[12];
  char airline[24];
  char registration[16];
  char typeCode[8];
  char typeName[28];
  char origin[4];
  char destination[4];
  FlightRoute route;
  float distanceKm;
  int32_t altitudeFt;
};

void flightReset();
bool flightPollDue(uint16_t pollSec);
bool flightFetch(float homeLat, float homeLon, uint16_t radiusKm);
const FlightSnapshot& flightData();
uint32_t flightLastOkMs();
const char* flightStageName();
int flightLastHttp();
uint16_t flightTlsRx();

bool flightExpire();
uint32_t flightTlsMinBlock();
