const {webkit,chromium}=require('playwright');
const fs=require('fs');const path=require('path');const assert=require('assert');
const source=fs.readFileSync(path.join(__dirname,'../src/main.cpp'),'utf8');
const html=source.split('R"HTML(')[1].split(')HTML"')[0];
const fixture={ssid:'Testnetz',hostname:'smalltv-dd',timeZone:'Europe/Berlin',stopName:'Pohlandplatz',stopId:'fixture',weatherCity:'Dresden',weatherLat:51,weatherLon:13,planePlace:'Dresden',planeLat:51,planeLon:13,nightStart:1320,nightEnd:420,nightEnabled:true,brightness:70,nightBrightness:12,rotationMask:1,rotationSec:[30,20,20,15,20,20,20,20,20],departureCount:4,departurePoll:30,weatherPoll:600,planeRadiusKm:25,planePoll:10,planePlaceToggleSec:10,trackerStatusPollMin:15,vvoMotMask:127,countdowns:[]};
(async()=>{
 const engine=process.env.SMALLTV_BROWSER==='chromium'?chromium:webkit;
 const browser=await engine.launch({headless:true,...(process.env.SMALLTV_WEBKIT_EXECUTABLE?{executablePath:process.env.SMALLTV_WEBKIT_EXECUTABLE}:{})});
 try {
  for(const width of [320,375,390,430,560,561,768,820,1024]){
   const context=await browser.newContext({viewport:{width,height:1000},isMobile:true,hasTouch:true});
   const page=await context.newPage();
   let posted=null;const config={...fixture};
   await page.route('http://smalltv.test/**',r=>{
    if(r.request().method()==='POST'){posted=r.request().postDataJSON();Object.assign(config,posted);return r.fulfill({contentType:'application/json',body:JSON.stringify({ok:true,reboot:false})});}
    return r.fulfill({contentType:r.request().url().endsWith('/')?'text/html':'application/json',body:r.request().url().endsWith('/')?html:JSON.stringify(r.request().url().includes('/api/config')?config:{ok:true})});
   });
   await page.goto('http://smalltv.test/');
   await page.waitForFunction(()=>document.getElementById('nightStart').value==='22:00');
   assert.strictEqual(await page.locator('#timeZone').inputValue(),'Europe/Berlin');
   assert.strictEqual(await page.locator('#timeZone option').count(),50);
   const tzOrder=await page.evaluate(()=>{
    const cards=[...document.querySelectorAll('#anzeige .card')];
    return cards.map(c=>c.querySelector('h2')?.textContent);
   });
   assert(tzOrder.indexOf('Zeitzone')<tzOrder.indexOf('Nachtmodus'));
   const layout=await page.evaluate(()=>{
    const a=document.getElementById('nightStart'),b=document.getElementById('nightEnd');
    const rect=e=>{const r=e.getBoundingClientRect();return {left:r.left,right:r.right,top:r.top,bottom:r.bottom,width:r.width,height:r.height}};
    return {a:rect(a),b:rect(b),card:rect(a.closest('.card')),overflow:document.documentElement.scrollWidth>innerWidth};
   });
   for(const box of [layout.a,layout.b]){assert(box.left>=layout.card.left+15&&box.right<=layout.card.right-15,JSON.stringify({width,layout}));assert(box.height<=46);}
   if(width<=560)assert(layout.b.top>=layout.a.bottom+5);
   else {assert(layout.b.left-layout.a.right>=9);assert(Math.abs(layout.a.width-layout.b.width)<1);}
   assert(!layout.overflow,`Page overflow at ${width}`);
   await page.locator('[data-p="flugradar"]').click();
   assert(await page.locator('#planePlaceToggleSec').isDisabled());
   await page.locator('#planeShowPlace').check();assert(await page.locator('#planePlaceToggleSec').isEnabled());
   const style=await page.evaluate(()=>{
    const h=getComputedStyle(document.querySelector('#flugradar .subhead'));
    const l=getComputedStyle(document.querySelector('#flugradar label'));
    return {head:[h.color,h.fontSize,h.fontWeight],label:[l.color,l.fontSize,l.fontWeight]};
   });
   assert.deepStrictEqual(style.head,style.label);
   if(process.env.SMALLTV_SCREENSHOTS&&[390,820].includes(width)){
    await page.locator('[data-p="anzeige"]').click();
    await page.locator('#nightStart').scrollIntoViewIfNeeded();
    await page.screenshot({path:path.join(process.env.SMALLTV_SCREENSHOTS,`night-${width}.png`)});
   }
   await page.locator('[data-p="anzeige"]').click();
   await page.locator('#timeZone').selectOption('Asia/Tokyo');
   await page.getByRole('button',{name:'Einstellungen speichern',exact:true}).click();
   await page.waitForFunction(()=>document.querySelector('.toast')?.textContent.includes('gespeichert'));
   assert(posted&&posted.timeZone==='Asia/Tokyo','Selected zone missing in save payload');
   await page.waitForFunction(()=>document.getElementById('timeZone').value==='Asia/Tokyo');
   console.log(`${engine.name()} ${width}px: time fields, spacing, captions, dependent select and time-zone load/save OK`);
   await context.close();
  }
 } finally {await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1});
