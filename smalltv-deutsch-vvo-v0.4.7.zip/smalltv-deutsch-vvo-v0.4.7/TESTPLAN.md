# Testplan v0.4.7

## Automatisiert

`tools/check.py`: Version, Dateien, JavaScript, identische Zeitzonen in UI
und Firmware, reproduzierbarer Font und README ohne Links.
`tools/test_radar.py`: tatsächliche Speicher-/Abrufentscheidungen und
Fehler-/Ablaufzustände mit simulierten Heapwerten und Uhr.
`tools/test_display.py`: tatsächliche Zeichenfunktionen einschließlich
Radar-Teilupdates, Neuaufnahme, Tracker-Footer und Wetter.
`tests/test_core.cpp`: UTF-8/Glyphen, Akzente, Routen, Wettercodes,
Zeitzonen und Zeitüberlauf.
`tests/webui.cjs`: WebKit-Layout an 320, 375, 390, 430, 560, 561, 768, 820
und 1024 Pixeln; Nachtzeitfelder, Zeitzonenauswahl/Speichern, Radaroptionen.
PlatformIO baut die vollständige Firmware für den ESP8266.

## Gerät zuerst mit höchstens zwei Programmen

1. Bestehende Einstellungen nach OTA prüfen; neue Zeitzone standardmäßig Berlin.
2. Radar fünf Sekunden: erfolgreiche Abrufe, wechselnde Positionen, korrekte
   Entfernung/Höhe, Routen mit Zwischenstopps und neue Flugzeuge beobachten.
3. Heap, größter Block und benötigter Block werden im Systemstatus angezeigt.
   Kein stilles Behalten alter Daten als LIVE bei Speicher-/TLS-/HTTP-Fehlern.
4. WLAN unterbrechen: LETZTER STAND, nach 30 Sekunden keine alten Flugzeugdaten;
   nach Wiederherstellung gültige Daten. Leere Antwort ist kein Fehler.
5. Gleiches Flugzeug: Teilupdates. Neue Identität oder Zustandswechsel: Vollupdate.
6. Wetter mit Tag/Nacht, teilweiser Bewölkung, Nebel und Intensitäten vergleichen.
7. Zeitzone wechseln, speichern und neu starten; Uhr, Footer, Nachtmodus und
   Tages-Countdown müssen übereinstimmen. Dauer-Countdown bleibt absolut.
8. Griechische/kyrillische Titel, Akzente und nicht unterstützte Zeichen prüfen.
9. Tracker ohne Nummer/Key: Footer nur Uhr; Hauptbereich weiterhin Hinweis.
10. iPhone/iPad-Safari: Speichern, Zeitfelder und Zeitzone ohne Überlauf.
11. Mehrstündiger Radar-Dauerlauf. Erst danach zusätzliche parallele Programme.
