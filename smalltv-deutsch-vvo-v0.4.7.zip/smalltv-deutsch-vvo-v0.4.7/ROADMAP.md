# Themenspeicher nach v0.4.7

Die gesammelten Änderungen an Radar, Zeitzone, Wetter, Font und Tracker-Footer
sind in v0.4.7 umgesetzt. Zuerst folgt der Radar-Praxistest auf dem Würfel.

Danach:

- Dauerbetrieb und Speichersituation mit mehr als zwei aktivierten Programmen
  messen. Daraus gegebenenfalls gezielte Änderungen ableiten.
- Radar-TLS-Budget anhand echter erfolgreicher und fehlgeschlagener Verbindungen
  bewerten. Keine zusätzliche pauschale Optimierung ohne diese Messungen.
- Native Darstellung in iPhone-/iPad-Safari überprüfen.

Keine neue automatische Ortsnamen-Transliteration oder Sprachfallback-Regel.
Bei nicht darstellbaren Zeichen bleibt das Freitextfeld die Alternative.
Ein Ausbau für chinesische, japanische oder arabische Schrift ist nicht
Bestandteil dieser Version.
