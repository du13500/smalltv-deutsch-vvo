#!/usr/bin/env python3
"""Exercise the production GeoResponse with short-write and transfer failures."""
from pathlib import Path
import subprocess, tempfile
root=Path(__file__).resolve().parents[1]
source=(root/'src/Geo.cpp').read_text()
buffer=source[source.index('class GeoResponse'):source.index('\nstatic BearSSL::Session')]
stub=r'''
#include <cassert>
#include <string>
#include <cstdint>
#include <algorithm>
#include <memory>
enum {SeekSet};
struct Stream {virtual ~Stream(){};virtual size_t write(uint8_t)=0;virtual size_t write(const uint8_t*,size_t)=0;virtual int available()=0;virtual int read()=0;virtual int peek()=0;virtual void flush()=0;};
static size_t writeLimit=100000;static bool openAllowed=true,closed=false,removed=false;
struct File {
 std::shared_ptr<std::string> bytes;size_t pos=0;
 explicit operator bool()const{return bool(bytes);}
 size_t write(const uint8_t* p,size_t n){size_t take=std::min(n,writeLimit);bytes->append((const char*)p,take);return take;}
 int available(){return bytes->size()-pos;}int read(){return available()?(*bytes)[pos++]:-1;}int peek(){return available()?(*bytes)[pos]:-1;}
 void flush(){}bool seek(size_t n,int){pos=n;return n<=bytes->size();}void close(){closed=true;}
};
struct FS {File open(const char* path,const char* mode){assert(std::string(path)=="/geo-response.tmp");assert(std::string(mode)=="w+");File f;if(openAllowed)f.bytes=std::make_shared<std::string>();return f;}void remove(const char* path){assert(std::string(path)=="/geo-response.tmp");removed=true;}} LittleFS;
namespace BearSSL {struct WiFiClientSecure{bool stopped=false;void stop(){stopped=true;}};}
struct HTTPClient {std::string body;bool ended=false,fail=false;int writeToStream(Stream* s){if(fail)return -1;size_t offset=0;while(offset<body.size()){size_t n=std::min(size_t(1024),body.size()-offset);size_t w=s->write((const uint8_t*)body.data()+offset,n);if(w!=n)return -1;offset+=w;}return offset;}void end(){ended=true;}};
'''
test=r'''
int main(){
 {GeoResponse response;HTTPClient http;BearSSL::WiFiClientSecure client;http.body="[{\"name\":\"Dresden\"}]";assert(response.ready());assert(response.receive(http,client));assert(http.ended&&client.stopped);std::string text;while(response.available())text+=char(response.read());assert(text==http.body);}
 assert(closed&&removed);
 {GeoResponse response;HTTPClient http;BearSSL::WiFiClientSecure client;http.body=std::string(GeoResponse::limit+1,'x');assert(!response.receive(http,client));assert(http.ended&&client.stopped);}
 {GeoResponse response;HTTPClient http;BearSSL::WiFiClientSecure client;http.body="partial";writeLimit=2;assert(!response.receive(http,client));assert(http.ended&&client.stopped);}
 writeLimit=100000;
 {GeoResponse response;HTTPClient http;BearSSL::WiFiClientSecure client;http.fail=true;assert(!response.receive(http,client));assert(http.ended&&client.stopped);}
 openAllowed=false;{GeoResponse response;assert(!response.ready());}
}
'''
with tempfile.TemporaryDirectory() as tmp:
 p=Path(tmp);(p/'test.cpp').write_text(stub+buffer+test)
 subprocess.run(['g++','-std=c++11','-Wall','-Wextra','-Werror',str(p/'test.cpp'),'-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],check=True)
# Both production paths release TLS before allocating their JSON filters.
assert source.count('response.receive(http,client)')==2
assert source.count('deserializeJson(doc, response,')==2
for part in source.split('if(!response.receive(http,client))')[1:]:
 assert part.index('JsonDocument filter')<part.index('deserializeJson')
print('Geo response: transfer, size bound, short write, transport error, cleanup and TLS-before-JSON OK')
