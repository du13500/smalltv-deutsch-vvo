# SmallTV DD v0.4.1

Politur der auf echter SmallTV-Ultra-Hardware getesteten v0.4. Die Firmware bleibt komplett autonom auf dem ESP8266: USB-Strom plus WLAN genügen.

## Neu in v0.4.1

- WLAN-Scan im Webinterface: SSID anklicken, Signalbalken und RSSI in dBm.
- Anzeigerotation: mehrere Programme per Checkbox aktivieren und je Ansicht eine Dauer festlegen.
- Footer-Uhr wird minütlich unabhängig von API-Refreshes aktualisiert.
- Wetter: doppelte Uhr oben entfernt, Ortssuche, optionaler Anzeigename, Standort-Button im Browser, Sunrise/Sunset-Pixelmarken und optionale Temperatur-Farbskala.
- Deutsche Pixel-Glyphen für ä, ö, ü, Ä, Ö, Ü und ß bei gleichbleibendem Display-Stil.
- VVO: Verkehrsmittel einzeln auswählbar und adaptive Schriftgröße für längere Linienbezeichnungen.
- Countdown: feste Vorzeichen-Spalte verhindert horizontales Springen bei 00:00.
- Deutsche, verständlichere Netzwerkfehler im Webinterface und Status-Nachprüfung nach Countdown-Aktionen.
- Flugradar: eigene Ortssuche und zusätzlicher Route-Fallback über adsbdb, falls adsb.lol keine Route kennt.

## Update von v0.4

Da v0.4 bereits unsere eigene OTA-Seite enthält, ist der Ultra-Loader für dieses Update **nicht** erneut nötig. Nach erfolgreichem GitHub-Actions-Build einfach `smalltv-dd-v0.4.1-firmware.bin` über `http://<IP-des-Würfels>/update` als **Firmware** hochladen.

Die bestehende Konfiguration wird aus `/config.json` übernommen. Neue Felder haben kompatible Standardwerte. Die bisher einzeln ausgewählte Ansicht wird beim ersten Start automatisch als einzige aktive Rotationseinstellung übernommen.

## Build

PlatformIO-Environment: `smalltv_ultra`.

```text
pio run -e smalltv_ultra
```

Ausgabe: `.pio/build/smalltv_ultra/firmware.bin`
