# SmallTV DD v0.4.1 Testplan

## Vor dem Flash

- GitHub Actions muss grün sein.
- Build-Log auf Fehler und ungewöhnlich hohe RAM-/Flash-Auslastung prüfen.
- Firmwaredatei muss `smalltv-dd-v0.4.1-firmware.bin` heißen.

## Smoke-Test nach OTA

1. Gerät startet und verbindet sich mit dem bisherigen WLAN.
2. Webinterface zeigt v0.4.1 und die vorhandene Konfiguration.
3. Display ist korrekt ausgerichtet, Backlight und Farben funktionieren.
4. `/update` bleibt erreichbar.

## WLAN

- Netzwerke suchen.
- Doppelte SSIDs werden im Browser nur einmal gezeigt.
- Sortierung stärkstes Netz zuerst.
- Balken und dBm plausibel.
- Klick übernimmt SSID.

## Anzeige / Rotation

- Nur eine Checkbox: Ansicht bleibt dauerhaft.
- Mehrere Checkboxen: Wechsel nach den eingestellten Zeiten.
- Datenrefresh und Ansichtswechsel laufen unabhängig.
- Countdown-Slots laufen weiter, auch wenn sie gerade nicht sichtbar sind.

## Uhr

- Footer-Uhr wechselt bei jeder neuen Minute auch dann, wenn VVO/Wetter nicht neu geladen werden.
- Wetter hat oben rechts keine zweite Uhr mehr.

## Umlaute

Mindestens testen: `Winterbergstraße`, `Bewölkt`, `Müll`, `Übung`.

## Wetter

- `Dresden` suchen und Treffer wählen.
- Anzeigename leer: Ortsname erscheint oben.
- Anzeigename `Pizza 420`: nur Titel ändert sich, Koordinaten bleiben am gewählten Wetterort.
- Sunrise/Sunset-Symbole sind eindeutig und ohne Überlappung.
- Temperaturfarbe aus: bisheriger cleaner Look.
- Temperaturfarbe an: nur große Ist-Temperatur inklusive C-Akzent wird farbig, H/T bleiben neutral.
- Aktuelle Position testen; bei HTTP-Blockade erscheint deutsche Erklärung statt Browser-Rohfehler.

## VVO

- Haltestellensuche unverändert funktionsfähig.
- Verkehrsmittel einzeln an-/abwählen.
- Dresden Hbf mit Zug/S-Bahn testen.
- Lange Linienbezeichnungen wie RE50/ICE 1650 dürfen nicht abgeschnitten werden; nur die Linien-Schrift wird kleiner.

## Countdown

- Vor Ziel: Minus.
- Exakt Null: Zahlenblock bleibt an derselben X-Position, Sign-Spalte leer.
- Nach Ziel: Plus.
- Zwei Slots parallel starten, Ansicht wechseln, Gerät stromlos machen und erneut starten.
- Beide Slots müssen aus den absoluten Zielzeiten korrekt weiterlaufen.
- Gerät aus: Webinterface zeigt verständliche deutsche Verbindungsfehlermeldung.

## Flugradar

- Ortssuche und eigener Radarstandort unabhängig vom Wetter.
- Testfall `SWR9GE`: wenn Datenanbieter aktuell passende Daten haben, Route ZRH > BER erwarten.
- Testfall `RYR58RA`: wenn Datenanbieter aktuell passende Daten haben, Route BER > STN erwarten.
- Militär-/Sonderfall `PRIMR01`: N/A > N/A ist korrekt, wenn keine Route vorliegt.
- Keine Route erfinden.

## Flug-Tracker

- Bestehendes Verhalten unverändert testen.
- Aviationstack nur bei sichtbarer Tracker-Ansicht pollen.
