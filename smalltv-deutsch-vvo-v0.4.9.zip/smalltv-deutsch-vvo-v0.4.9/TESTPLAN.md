# Hardwaretest v0.4.9

| Bereich | Prüfung | Erwartung |
| --- | --- | --- |
| Radar | Mit einem Programm zunächst 10 bis 15 Minuten beobachten | Position und Höhe ändern sich bei neuen Daten; unveränderte Felder bleiben stehen. Zusatzdaten können später erscheinen. |
| Radarfehler | Nach Aussetzern System → Diagnose öffnen und Log herunterladen | Log unterscheidet Radar.Position, Radar.Route, Radar.Metadata und Radar.Airline. HTTP 429 führt zu einer Pause; neue erfolgreiche Positionsdaten stellen LIVE wieder her. |
| Datenalter | Bei anhaltenden Fehlern weiter beobachten | LETZTER STAND läuft nach etwa 30 Sekunden ohne erfolgreiche Positionsdaten ab. Keine Änderung am gewünschten Fehlertext. |
| Wetter | Ort wechseln, Namen abwarten, speichern; danach mehrmals wiederholen | Kein Reboot. Nach Fehlern selbstständiger Wiederholungsversuch, kein erneutes Speichern erforderlich. Bei Problemen sofort Log laden. |
| VVO | Haltestelle oder Verkehrsmittelfilter ändern; Programm einschalten | Daten werden neu geladen. Ein erster Abruffehler wird selbstständig erneut versucht. |
| Speichersperre | Direkt nach Karten-Pick und während laufender Ortsabfrage speichern versuchen | Taste ist grau und deaktiviert; nach Name oder Fehler wieder nutzbar. Auch die letzte von mehreren schnellen Auswahlen wird berücksichtigt. |
| Einstellungserhalt | Nur Helligkeit oder einen Countdown ändern und speichern | Andere Programme verlieren ihre gültigen Daten nicht und beginnen keinen unnötigen Neuabruf. |
| Diagnose | Log anzeigen und herunterladen; anschließend neu starten | Text enthält Endpunktgruppe, HTTP-Ergebnis, Zeit, Dauer und Speicherwerte. Nach Neustart Reset-Grund und gegebenenfalls vorheriger RTC-Marker. Keine Zugangsdaten. |
| Darstellung | Gleiche Daten, geänderte Werte, Programmwechsel, kürzere Texte | Bestätigte Teilaktualisierungen bleiben erhalten; keine Zeichenreste. |
| Dauerbetrieb | Zunächst ein oder zwei Programme, wie bisher | Keine neuen Hänger oder Neustarts. Bei Auffälligkeiten Log sichern. |
| Tracker | Später mit gültigem API-Schlüssel testen | Betrieb und Quellenabhängigkeiten prüfen; derzeit noch offen. |

Wetter-Icon-Design und Belastungstests mit mehr als zwei Programmen bleiben separate spätere Aufgaben. Lizenzwechsel ist nicht Bestandteil dieses Builds.
