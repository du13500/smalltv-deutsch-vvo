# Änderungen

## v0.4.9

- **Diagnose im Webinterface:** Im Reiter System lassen sich die letzten 24 Ereignisse anzeigen und als Textdatei herunterladen. Abrufe werden nach Position, Route, Metadaten, Airline, Wetter, VVO und Ortsabfrage unterschieden. Aufgeführt werden HTTP-Ergebnis, Zeit seit Start, Dauer, freier Heap und größter Speicherblock. Passwörter, API-Schlüssel, Suchtexte und vollständige URLs werden nicht protokolliert.
- **Neustart-Hinweise:** Reset-Grund und Reset-Information werden angezeigt. Ein kleiner RTC-Marker hält den letzten protokollierten Arbeitsschritt des vorherigen Starts fest, soweit er einen Neustart übersteht. Er liefert einen Hinweis, keinen Beweis für die Absturzursache. Der normale Ereignislog beginnt nach jedem Neustart neu.
- **Radar-Abrufe:** Positionsdaten werden vor den Zusatzabfragen übernommen. Route, Metadaten und Airline werden getrennt und nacheinander ergänzt. Der Positionspfad verwendet nur zwischengespeicherte Zusatzdaten. Bei wechselnden Flugzeugen liegen mindestens 60 Sekunden zwischen neuen Ergänzungszyklen; fehlende Routen werden frühestens nach zwei Minuten erneut geprüft. Gültige Routen bleiben höchstens fünf Minuten verwendbar und werden weiterhin gegen die Position geprüft.
- **Hintergrundabfragen:** Abfahrten, Wetter, Radar und Tracker werden im Wechsel bedient. Zwischen Hintergrundaufgaben liegt eine kurze Pause; das Webinterface kann dazwischen Anfragen bearbeiten. Eine einzelne HTTPS-Abfrage kann weiterhin einige Sekunden blockieren.
- **Erholung bei Fehlern:** Wetter und VVO wiederholen fehlgeschlagene Abrufe nach 15, 30, 60 und höchstens 120 Sekunden. Nach Erfolg gilt wieder das eingestellte Intervall. Bei HTTP 429/503 werden zusätzlich Anbieterpausen berücksichtigt. TLS-Abfragen für Wetter, VVO, Ortsnamen und Tracker prüfen den verfügbaren Speicher vor dem Verbindungsaufbau.
- **Einstellungen speichern:** Unveränderte Programme behalten ihre Daten und Abrufzeiten. Neue Standorte, Haltestellen, Datenfilter oder neu aktivierte Programme lösen den jeweiligen Neuabruf aus. Während eine Karten-Ortsabfrage wartet oder läuft, ist die Speichertaste sichtbar deaktiviert. Nach Erfolg, fehlendem Ortsnamen oder einem Fehler wird sie wieder freigegeben.
- **Antwortprüfung:** Eine Radar-Antwort ohne Flugzeugliste oder mit ungültigen Positionskoordinaten gilt als Abruffehler. Eine ausdrücklich leere Liste bleibt ein erfolgreicher Abruf ohne Flugzeuge.

## Ältere Versionen

| Version | Wichtigste Neuerungen |
| --- | --- |
| **v0.4.8** | Anbieterpausen, positionsgeprüfte Radar-Routen, Online-Ergänzung von Airline und Typ, Bodenstatus GND, Kartenkorrekturen und Teilaktualisierungen in weiteren Programmen |
| **v0.4.7** | Einstellbare Zeitzonen, griechische und kyrillische Zeichen, differenziertere Wetterbilder sowie Verbesserungen bei Radar-Abrufen und der Anzeige veralteter Daten |
| **v0.4.6** | Erweiterter lateinischer Zeichensatz, mehrteilige Flugrouten, Tracker-Footer und Verbesserungen am Webinterface |
| **v0.4.5** | Kompakte Abfahrtsziele, Verbesserungen an Karten- und Standortauswahl, Speichern der Einstellungen und Radar-Verbindungen |
| **v0.4.4** | Bis zu zehn Abfahrten mit Seitenwechsel, Temperatureinheiten, Uhr im Footer und robustere Radarfehlerbehandlung |
| **v0.4.3** | Überarbeitung der öffentlichen Projektangaben |
| **v0.4.2** | Karten-Picker, Rückmeldungen im Webinterface und ruhigere Uhr- und Countdown-Anzeige |
| **v0.4.1** | Programmrotation, WLAN-Scan, Ortssuche, deutsche Sonderzeichen und Verkehrsmittelfilter |
| **v0.4** | Flug-Tracker und vier speicherbare Countdowns |
| **v0.3** | Live-Wetter, Flugradar und weitere Hauptansichten |
| **v0.2** | VVO-Haltestellensuche und Abfahrtsmonitor |
| **v0.1** | WLAN-Einrichtung, Webinterface, automatische Zeitabfrage und Firmware-Updates |

