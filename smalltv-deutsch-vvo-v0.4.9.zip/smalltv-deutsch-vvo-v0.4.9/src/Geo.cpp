#include "Geo.h"
#include "RequestPolicy.h"
#include "NetworkGuard.h"
#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>
#include <WiFiClientSecureBearSSL.h>
#include <ArduinoJson.h>

static BearSSL::Session g_geoSession;
static uint32_t g_geoLastRequest=0;static bool g_geoRequested=false;
static bool geoReady(){
  if(serviceWaitMs(SERVICE_GEO))return false;
  if(g_geoRequested&&(uint32_t)(millis()-g_geoLastRequest)<1100UL)return false;
  g_geoRequested=true;g_geoLastRequest=millis();return true;
}

static void makeSecure(BearSSL::WiFiClientSecure& client) {
  client.setInsecure();
  client.setBufferSizes(4096, 512);
  client.setSession(&g_geoSession);
  client.setTimeout(9000);
}

static String urlEncode(const String& in) {
  static const char* hex = "0123456789ABCDEF";
  String out;
  out.reserve(in.length() * 3);
  for (size_t i = 0; i < in.length(); i++) {
    uint8_t c = (uint8_t)in[i];
    if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
        (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.' || c == '~') {
      out += (char)c;
    } else if (c == ' ') {
      out += "%20";
    } else {
      out += '%'; out += hex[c >> 4]; out += hex[c & 15];
    }
  }
  return out;
}

bool geoSearchPlaces(const String& query, bool germanNames, String& outJson) {
  DiagRequest trace(D_GEO_SEARCH);
  if(!networkHeapReady(D_GEO_SEARCH))return false;
  trace.stage(DS_TLS);
  if (WiFi.status() != WL_CONNECTED || serviceWaitMs(SERVICE_GEO)) return false;
  String q = query; q.trim();
  if (q.length() < 2) return false;

  BearSSL::WiFiClientSecure client;
  makeSecure(client);
  HTTPClient http;
  http.useHTTP10(true);
  http.setTimeout(9000);
  http.setReuse(false);

  String url = F("https://nominatim.openstreetmap.org/search?format=jsonv2&addressdetails=1&namedetails=1&limit=8&q=");
  url += urlEncode(q);
  if (germanNames) url += F("&accept-language=de");
  if (!geoReady()||!http.begin(client, url)) return false;
  http.addHeader("Accept", "application/json");
  http.setUserAgent("SmallTV-Deutsch-VVO/0.4.9 (github.com/du13500/smalltv-deutsch-vvo)");

  const char* headers[]={"Retry-After"};http.collectHeaders(headers,1);
  int code = http.GET();trace.http(code);
  serviceResponse(SERVICE_GEO,code,http.header("Retry-After").c_str());
  if (code != HTTP_CODE_OK) { http.end(); return false; }

  JsonDocument filter;
  JsonObject f = filter[0].to<JsonObject>();
  f["name"] = true; f["display_name"] = true; f["lat"] = true; f["lon"] = true;
  f["namedetails"]["name"] = true; f["namedetails"]["name:de"] = true;
  JsonObject af = f["address"].to<JsonObject>();
  af["city"] = true; af["town"] = true; af["village"] = true; af["municipality"] = true;
  af["state"] = true; af["country"] = true;

  JsonDocument doc;
  trace.stage(DS_JSON);
  DeserializationError err = deserializeJson(doc, http.getStream(), DeserializationOption::Filter(filter));
  http.end();
  if (err) return false;

  JsonDocument out;
  out["ok"] = true;
  JsonArray places = out["places"].to<JsonArray>();
  for (JsonObjectConst r : doc.as<JsonArrayConst>()) {
    String name;
    if (germanNames) name = r["namedetails"]["name:de"] | "";
    if (!name.length()) name = r["namedetails"]["name"] | "";
    if (!name.length()) name = r["name"] | "";
    name.trim();
    if (!name.length()) continue;

    JsonObject p = places.add<JsonObject>();
    p["name"] = name;
    p["lat"] = String(r["lat"] | "0").toFloat();
    p["lon"] = String(r["lon"] | "0").toFloat();

    String label = r["display_name"] | name;
    p["label"] = label;
  }
  serializeJson(out, outJson);
  trace.finish(true);return true;
}


static String firstSettlementName(JsonObjectConst a) {
  static const char* keys[] = {
    "neighbourhood", "quarter", "suburb", "city_district", "borough",
    "hamlet", "village", "town", "city", "municipality", "island", "islet"
  };
  for (const char* key : keys) {
    const char* v = a[key] | "";
    if (v && *v) return String(v);
  }
  return String();
}

static String broaderAreaName(JsonObjectConst a) {
  static const char* keys[] = {"county", "state_district", "state", "region", "country"};
  for (const char* key : keys) {
    const char* v = a[key] | "";
    if (v && *v) return String(v);
  }
  return String();
}

bool geoReversePlace(float lat, float lon, bool germanNames, String& outJson) {
  DiagRequest trace(D_GEO_REVERSE);
  if(!networkHeapReady(D_GEO_REVERSE))return false;
  trace.stage(DS_TLS);
  if (WiFi.status() != WL_CONNECTED || serviceWaitMs(SERVICE_GEO)) return false;
  if (lat < -90.0f || lat > 90.0f || lon < -180.0f || lon > 180.0f) return false;

  BearSSL::WiFiClientSecure client;
  makeSecure(client);
  HTTPClient http;
  http.useHTTP10(true);
  http.setTimeout(9000);
  http.setReuse(false);

  String url = F("https://nominatim.openstreetmap.org/reverse?format=jsonv2&addressdetails=1&namedetails=1&zoom=13&layer=address,natural&lat=");
  url += String(lat, 6);
  url += F("&lon=");
  url += String(lon, 6);
  if (germanNames) url += F("&accept-language=de");
  if (!geoReady()||!http.begin(client, url)) return false;
  http.addHeader("Accept", "application/json");
  http.setUserAgent("SmallTV-Deutsch-VVO/0.4.9 (github.com/du13500/smalltv-deutsch-vvo)");

  const char* headers[]={"Retry-After"};http.collectHeaders(headers,1);
  int code = http.GET();trace.http(code);
  serviceResponse(SERVICE_GEO,code,http.header("Retry-After").c_str());
  if (code != HTTP_CODE_OK) {
    http.end();
    if (code != HTTP_CODE_NOT_FOUND) return false;
    JsonDocument out;out["ok"]=true;out["name"]="";out["lat"]=lat;out["lon"]=lon;
    serializeJson(out,outJson);trace.finish(true);return true;
  }

  JsonDocument filter;
  filter["name"] = true;
  filter["display_name"] = true;
  filter["category"] = true;
  filter["type"] = true;
  filter["namedetails"]["name"] = true;
  filter["namedetails"]["name:de"] = true;
  JsonObject af = filter["address"].to<JsonObject>();
  static const char* keys[] = {
    "city", "town", "village", "municipality", "hamlet", "island", "islet",
    "neighbourhood", "quarter", "city_district", "suburb", "borough", "county", "state_district", "state",
    "region", "sea", "ocean", "water", "country"
  };
  for (const char* key : keys) af[key] = true;

  JsonDocument doc;
  trace.stage(DS_JSON);
  DeserializationError err = deserializeJson(doc, http.getStream(), DeserializationOption::Filter(filter));
  http.end();
  if (err) return false;

  JsonObjectConst addr = doc["address"].as<JsonObjectConst>();
  // zoom=13 resolves a locality/district rather than a street or building.
  // Search selections use geoSearchPlaces and keep their selected name.
  String name;
  if (germanNames) name = doc["namedetails"]["name:de"] | "";
  if (!name.length()) name = doc["namedetails"]["name"] | "";
  if (!name.length()) name = doc["name"] | "";
  name.trim();
  if (!name.length()) name = firstSettlementName(addr);
  if (!name.length()) {
    const char* water = addr["sea"] | (addr["ocean"] | (addr["water"] | ""));
    name = water;
  }


  if (!name.length()) name = broaderAreaName(addr);

  if (!name.length()) {
    String display = doc["display_name"] | "";
    int comma = display.indexOf(',');
    name = comma >= 0 ? display.substring(0, comma) : display;
    name.trim();
  }


  JsonDocument out;
  out["ok"] = true;
  out["name"] = name;
  out["lat"] = lat;
  out["lon"] = lon;
  serializeJson(out, outJson);
  trace.finish(true);return true;
}
