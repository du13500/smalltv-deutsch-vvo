#pragma once
#include <ESP8266WiFi.h>
#include <WiFiClientSecureBearSSL.h>
#include "RadarPolicy.h"
#include "Diagnostics.h"
static inline bool networkHeapReady(DiagOp op,uint16_t rx=4096){
 bool ok=radarTlsFits(ESP.getFreeHeap(),ESP.getMaxFreeBlockSize(),rx,sizeof(br_ssl_client_context));
 if(!ok)diagEvent(op,DS_HEAP,0,radarTlsBudget(rx,sizeof(br_ssl_client_context)).total);
 return ok;
}
