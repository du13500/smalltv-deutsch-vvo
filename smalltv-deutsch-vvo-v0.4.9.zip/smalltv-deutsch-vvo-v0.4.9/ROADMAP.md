# Themenspeicher

- Radar-Zuverlässigkeit mit v0.4.9 auf Hardware prüfen; bei Aussetzern den Diagnose-Log auswerten.
- Wetter-Ortswechsel und VVO-Erstabruf testen; Neustart-Hinweise sind noch kein Ursachenbeweis.
- Wetter-Icons in einem zukünftigen Build gestalterisch überarbeiten, zunächst Motive und Varianten gemeinsam vergleichen.
- Flug-Tracker mit gültigem aviationstack-Schlüssel vollständig prüfen.
- Belastungstest mit mehr als zwei Programmen erst nach Stabilisierung des Radars.
- Lizenzentscheidung: CC0 oder MIT für eigene Beiträge nach Quellenprüfung, keine automatische Umstellung.
- Nicht darstellbare Ortsnamen weiterhin über das optionale Freitextfeld lösen.
