#pragma once
#include <Arduino.h>

struct VvoDeparture {
  char line[10];
  char direction[56];
  int16_t minutes;
  bool cancelled;
  bool delayed;
};

void vvoReset();
bool vvoPollDue(uint16_t pollSec);
bool vvoFetchDepartures(const String& stopId, uint8_t limit);
bool vvoSearchStops(const String& query, String& outJson);
uint8_t vvoCount();
const VvoDeparture& vvoAt(uint8_t i);
bool vvoError();
uint32_t vvoLastOkMs();
