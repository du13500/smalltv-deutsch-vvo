# SmallTV DD

Eigene Firmware für den **GeekMagic SmallTV-Ultra** mit ESP8266 und 240×240-Display.

## v0.3

Alle vier geplanten Ansichten sind jetzt als echte Funktionen vorgesehen:

- **Abfahrten**: VVO-Haltestellensuche und Live-Abfahrten
- **Wetter**: Open-Meteo mit aktueller Temperatur, Tageshoch/-tief, Regenwahrscheinlichkeit, Sonnenaufgang und Sonnenuntergang
- **Flugradar**: nächstes Flugzeug über adsb.lol, Registrierung, Typ, Airline und Route soweit verfügbar
- **Uhr**: echte NTP-Zeit für Europe/Berlin

Die Firmware läuft nach der Einrichtung selbstständig mit USB-Strom und WLAN. Es ist kein Raspberry Pi, PC oder Home-Assistant-Server nötig.

## Datenquellen

- VVO WebAPI
- Open-Meteo
- adsb.lol

Die Flugroute wird separat über den adsb.lol-Routenendpunkt ergänzt. Wenn keine verlässliche Route vorliegt, zeigt die Anzeige `N/A > N/A`.

## Noch nicht flashen

v0.3 muss zunächst in GitHub Actions erfolgreich für `smalltv_ultra` gebaut werden. Danach prüfen wir Flash/RAM sowie den sicheren zweistufigen Erstinstallationsweg für die Ultra-Stock-Firmware.

## Basis

Entstanden auf Basis der Hardware- und Displayarbeit von [`giovi321/smalltv-mod`](https://github.com/giovi321/smalltv-mod), WTFPL.
