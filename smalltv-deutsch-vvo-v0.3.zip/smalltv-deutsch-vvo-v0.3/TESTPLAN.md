# v0.3 Testplan

## Build-Gate

1. `pio run -e smalltv_ultra` muss erfolgreich sein.
2. Flash- und statische RAM-Nutzung aus GitHub Actions dokumentieren.
3. Erst danach Loader/Flash auf echter Hardware.

## Abfahrten

- Haltestellensuche liefert VVO-Treffer.
- Gewählte ID bleibt nach Neustart gespeichert.
- Linie, Ziel und Echtzeit-Minuten werden angezeigt.
- Unmittelbare Abfahrt: `JETZT`.
- Ausfall: `AUS`.

## Wetter

- Open-Meteo liefert Temperatur und WMO-Wettercode.
- Tageshoch und Tagestief erscheinen.
- Regenwahrscheinlichkeit erscheint.
- Sonnenaufgang und Sonnenuntergang erscheinen in lokaler Zeit.
- Wettericons werden lokal gezeichnet, keine Bilddownloads.

## Flugradar

- adsb.lol `/v2/closest` liefert das nächste Flugzeug im Radius.
- Callsign, Registrierung und ICAO-Typ werden übernommen.
- Häufige Typcodes und Airline-Präfixe werden lokal lesbar aufgelöst.
- Routensuche erfolgt nur beim Wechsel des Callsigns und wird gecacht.
- Fehlende Route ergibt `N/A > N/A`.

## Uhr

- NTP synchronisiert mit Europe/Berlin inklusive Sommerzeit.
- Datum und Uhr aktualisieren korrekt.

## Fehlerfälle

- Internet weg: letzte Live-Daten bleiben nach Möglichkeit sichtbar, Fehlerstatus wird markiert.
- Kein Flugzeug im Radius: klare Leermeldung statt Testdaten.
- API nicht erreichbar: keine Bootschleife.
