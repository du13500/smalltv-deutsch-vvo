#pragma once
#include <Arduino.h>
#include "FlightRoute.h"

struct FlightSnapshot {
  bool valid;
  bool error;
  char callsign[12];
  char airline[24];
  char registration[16];
  char typeCode[8];
  char typeName[28];
  char origin[4];
  char destination[4];
  FlightRoute route;
  float distanceKm;
  int32_t altitudeFt;
};

void flightReset();
bool flightPollDue(uint16_t pollSec);
bool flightFetch(float homeLat, float homeLon, uint16_t radiusKm);
const FlightSnapshot& flightData();
uint32_t flightLastOkMs();
const char* flightStageName();
int flightLastHttp();
uint16_t flightTlsRx();

// Shared lookup for radar and tracker. NaN coordinates skip the position-based source.
bool flightLookupRoute(const char* callsign, float lat, float lon, FlightRoute& route, char origin[4], char destination[4]);
