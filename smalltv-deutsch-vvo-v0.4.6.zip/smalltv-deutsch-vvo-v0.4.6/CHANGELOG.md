# Änderungen

## v0.4.6

- Europäische lateinische Buchstaben im 5×7-Pixelstil, einschließlich Französisch,
  Tschechisch und Polnisch. Bestehende deutsche Glyphen unverändert.
- Vollständiger UTF-8-Decoder, kombinierte Akzente, Herzvarianten in Textfarbe und
  eigener Kasten für unbekannte Zeichen. Emoji-Präsentationszeichen erzeugen
  keine zusätzliche Lücke.
- Responsive Zeitfelder mit begrenzter Mindestbreite für iPhone/iPad.
- Checkbox-Zwischenüberschriften in normaler grauer Feldbeschriftung.
- H/T ohne Leerzeichen vor der Einheit, etwa `H 21°C` und `T 7°C`.
- Detaillierte Kartenpunkte wieder mit Stadtteil-/Ortsnamen; Ortssuche und
  Sprachwahl bleiben erhalten. Gewässernamen bleiben als Fallback verfügbar.
- Flugtracker mit vollständigem Eingabehinweis und Footer/Uhr in allen Zuständen.
- Mehrteilige Flugrouten einschließlich Zwischenstopps aus adsb.lol und
  optionalem adsbdb-Mittelpunkt. Gemeinsame Darstellung für Radar und Tracker.
  Zwei-Flughäfen-Layout unverändert. Maximal acht Codes mit sichtbarem Hinweis
  auf weitere Einträge; lange Folgen passen in zwei Zeilen.
- README und Beitragsleitfaden aktualisiert; Quellenhinweise getrennt von LICENSE;
  Themenspeicher und gezielter Testplan ergänzt.
- Build prüft aktuelle Quellen statt eines vorab behaupteten Prüfergebnisses.

## Bisherige Versionen

- v0.4.5: kompakte Fahrziele als Option, festes 5-Sekunden-Paging,
  Geo-/UI-Politur, atomare Config-Saves und Radar-TLS-Stabilisierung.
- v0.4.4: robustere Radarfehlerbehandlung, Karten-/Standort-Politur,
  Temperatureinheiten, VVO-10er-Paging und Uhr-Footer.
- v0.4.3: Privacy-Hotfix; öffentliche Credits nur als du13500.
- v0.4.2: Kartenpicker, Toasts und ruhigere Uhr-/Countdown-Redraws.
- v0.4.1: Rotation, WLAN-Scan, Ortssuche, deutsche Glyphen und Verkehrsmittelfilter.
- v0.4: Tracker und vier persistente Countdowns.
- v0.3: Live-Wetter, Flugradar und Hauptansichten.
- v0.2: VVO-Haltestellensuche und Abfahrten.
- v0.1: Webinterface, WLAN, NTP, OTA und erste Ansichten.
