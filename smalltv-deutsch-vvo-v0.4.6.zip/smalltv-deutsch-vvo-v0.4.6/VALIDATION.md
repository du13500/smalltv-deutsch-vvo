# Validierung v0.4.6

Prüfstand: 6. Oktober 2026.

## Erfolgreich ausgeführt

- `python3 tools/check.py`: Release-Dateien, Versionsnummern, eingebettetes
  Web-JavaScript und reproduzierbar erzeugter Font.
- `g++ -std=c++11 -Wall -Wextra -Werror tests/test_core.cpp` und Ausführen
  des Ergebnisses: UTF-8, französische/tschechische/polnische Glyphen,
  Herzvarianten, unbekannte Zeichen, ungültige Sequenzen und Routenparser.
- `python3 tools/test_display.py`: tatsächliche Zeichenfunktionen kompiliert
  und geprüft; Route innerhalb des 240×240-Displays, unverändertes
  Zwei-Flughäfen-Layout und Tracker-Footer in allen Zuständen.
- Build-Workflow als YAML geparst; Archivname, Dokumentationsvergleich,
  Ziel `smalltv_ultra` und Firmware-Ausgabepfad abgeglichen.

## Noch kein erfolgreicher Nachweis

- Der vollständige lokale PlatformIO-Build konnte nicht abgeschlossen werden:
  Der Download des ESP8266-Frameworks scheiterte mehrfach an Zeitüberschreitungen
  der Paketserver. Die Kompilierung startete dadurch nicht. Es liegt keine
  lokal verifizierte Firmware-BIN vor.
- WebKit wurde heruntergeladen, konnte aber mangels Systembibliotheken nicht
  gestartet werden. Die Installation der benötigten Bibliotheken scheiterte
  an den Rechten der Arbeitsumgebung. Die Browserprüfung ist daher lokal
  nicht bestanden oder bewertet worden.

Der mitgelieferte GitHub-Workflow installiert die WebKit-Abhängigkeiten,
führt dieselben Prüfungen aus und baut anschließend die ESP8266-Firmware.
Vor dem OTA-Update muss dieser Workflow vollständig erfolgreich sein.

## Hardwaretest

Noch ausstehend: OTA von v0.4.5, native iOS-Safari-Zeitfelder, Lesbarkeit der
Glyphen, echte Routenquellen und Flugtracker mit eigenem API-Key.
Details: [TESTPLAN.md](TESTPLAN.md).
