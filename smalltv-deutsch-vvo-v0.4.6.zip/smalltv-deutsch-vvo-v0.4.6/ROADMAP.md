# Themenspeicher

Ideen sind keine Funktions- oder Terminzusagen. Die Firmware konzentriert sich
zunächst auf den getesteten SmallTV-Ultra. Nur bestätigte Daten anzeigen.

## Für v0.5 vorgemerkt

- DWD-Wetterwarnungen als zusätzliche Wetterseiten am ausgewählten Standort.
- Bevölkerungsschutzwarnungen ebenfalls als zusätzliche Wetterseiten.
- Beide Quellen separat einschaltbar, Hinweis „nur Deutschland“. Außerhalb
  Deutschlands keine Warnseite und kein zusätzlicher Fehlerhinweis.
- Mehrere aktive Warnungen nacheinander, danach zurück zum normalen Wetter.
- Flughafen-Ankunfts-/Abflugtafel: Flugnummer, Ziel/Herkunft, Plan-/Erwartungszeit,
  Status, gegebenenfalls Gate/Terminal. Bevorzugt kostenlos ohne Account/API-Key.
  Zunächst öffentliche Quellen für DRS und BER auf Nutzbarkeit prüfen.

## Spätere Ideen ohne feste Version

- Textprogramm mit frei editierbarem Text, optional Titel, Farbe, Ausrichtung
  und passender Schriftgröße.
- Listenprogramm: Einkaufs-, Aufgaben- und Packlisten lokal speichern;
  Einträge bearbeiten, löschen und abhaken; seitenweise wechseln.
- Weitere monochrome Pixelsymbole für Text und Listen in der gewählten Textfarbe.
  Das Pixelherz und der Kasten für unbekannte Zeichen sind bereits in v0.4.6.
- Grafisches Regenradar am Wetterstandort, eventuell vergangene Bilder als Film.
  RainViewer war ein Prüfkandidat; Speicherbedarf und Nutzbarkeit sind offen.
- Eigener Bahnhofsmonitor mit Zugnummer, Ziel, Uhrzeit, Verspätung und Gleis.
- Schiffstracker/AIS: ein Schiff verfolgen, Position, Geschwindigkeit, Ziel/ETA
  soweit vorhanden. Nur lose Idee; stabile geeignete Datenquelle zuerst prüfen.
- Flugtracker ohne API-Key: mögliche Grundfunktionen separat bewerten. Kein
  gleichwertiger Ersatz für Planzeiten und Flugstatus bislang belegt.

## Zur v1.0-Veröffentlichung

- Eigene Projektseite, beispielsweise GitHub Pages, mit Einrichtung, Funktionen,
  unterstützter Hardware, Datenquellen und bekannten Grenzen.
- Display-Simulator mit möglichst gemeinsamem Renderer für echte 240×240-PNGs
  und gegebenenfalls GIFs; automatische Erstellung über GitHub Actions prüfen.
- Projektvorstellung mit Bildern/GIFs und Repository-Link vorbereiten.
- Persönliche Danksagung an den ursprünglichen Entwickler vorbereiten.

## Zurückgestellt

Browser-Geolocation wurde zugunsten von Suche und Kartenpicker entfernt.
WireGuard, Home Assistant/MQTT und ein Theme-System sind derzeit nicht geplant.
