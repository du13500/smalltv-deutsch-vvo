#include "../src/PixelFont.h"
#include "../src/FlightRoute.h"
#include <assert.h>
#include <string>
#include <vector>
#include <stdio.h>
static std::vector<uint32_t> decode(const std::string& s){
  size_t i=0;uint32_t cp=0;std::vector<uint32_t> v;
  while(nextDisplayCodepoint(s.data(),s.size(),i,cp))v.push_back(cp);
  return v;
}
int main(){
  assert(decode("é")==decode("e\xCC\x81"));
  assert(decode("č")==decode("c\xCC\x8C"));
  assert(decode("ą")==decode("a\xCC\xA8"));
  for(auto s:{"♥","❤","❤️","💛","💚","💙","💜","🖤","🤍","🤎","🩷","🩵","🩶","💔","💞","❤️‍🔥","❤️‍🩹"})assert(decode(s)==std::vector<uint32_t>{0x2665});
  assert(decode("🤏")==std::vector<uint32_t>{0x1F90F});
  assert(decode("A❤️B").size()==3);
  assert(decode("?")[0]=='?');assert(specialGlyph('?')==nullptr);
  assert(decode("🚀")[0]==0x1F680);assert(specialGlyph(0x1F680)==nullptr);
  auto broken=decode(std::string("\xE2" "A"));assert(broken.size()==2&&broken[0]==0xFFFD&&broken[1]=='A');
  assert(decode("\xC0\xAF")[0]==0xFFFD);assert(decode("\xED\xA0\x80")[0]==0xFFFD);
  assert(decode("\xF4\x90\x80\x80")[0]==0xFFFD);
  for(uint32_t cp:decode("éèêëçČčŘřŠšŽžĚěŮůŇňŤťĎďĄąĆćĘęŁłŃńŚśŹźŻżÖöÜüÄäßØøÆæŒœ"))assert(specialGlyph(cp));
  FlightRoute r={};assert(parseFlightRoute("LEJ-BLR-HKG",r));assert(r.count==3&&!strcmp(r.airports[1],"BLR"));
  assert(parseFlightRoute(" lej - blr - hkg ",r));assert(r.count==3&&!strcmp(r.airports[0],"LEJ"));
  assert(parseFlightRoute("OSL-IST",r));assert(r.count==2);
  assert(parseFlightRoute("AAA-BBB-CCC-DDD-EEE-FFF-GGG-HHH-III",r));assert(r.count==8&&r.truncated);
  for(auto s:{"", "unknown", "LEJ", "LEJ-", "LEJ- ", "LEJ--HKG", "LEJ-N/A-HKG", "LEJ-BL1-HKG", "LEJJ-HKG", "-HKG"}){assert(!parseFlightRoute(s,r));assert(r.count==0);}
  puts("UTF-8, accented glyphs, hearts, invalid sequences and route parsing: OK");
}
