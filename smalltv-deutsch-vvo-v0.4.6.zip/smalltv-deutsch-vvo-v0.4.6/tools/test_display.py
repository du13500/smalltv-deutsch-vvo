#!/usr/bin/env python3
"""Compile the real route/tracker drawing functions with a recording display."""
from pathlib import Path
import re,subprocess,tempfile
root=Path(__file__).resolve().parents[1]
s=(root/'src/main.cpp').read_text()
def fn(name):
 m=re.search(r'static [^\n]+\b'+name+r'\([^\n]*\) \{',s)
 assert m,name
 a=m.start();i=s.index('{',a);depth=1;j=i+1
 while depth:
  if s[j]=='{':depth+=1
  if s[j]=='}':depth-=1
  j+=1
 return s[a:j]
snapshot=(root/'src/TrackFlight.h').read_text().split('struct TrackedFlightSnapshot {',1)[1].split('};',1)[0]
pre=r'''
#include <string>
#include <vector>
#include <cassert>
#include <cstring>
#include <cstdio>
#include <cmath>
#include "PixelFont.h"
#include "FlightRoute.h"
struct String:std::string {
 using std::string::string;
 String(const std::string& s):std::string(s){}
 String(int n):std::string(std::to_string(n)){}
};
struct Draw {String text;int y,size;};
std::vector<Draw> draws;String footer;
struct Gfx {void fillScreen(int){} void setTextSize(int){} void setTextColor(int){} void setCursor(int,int){} void print(const String&){} } display;
Gfx* gfx=&display;
const int C_BLACK=0,C_WHITE=1,C_YELLOW=2,C_GRAY=3,C_RED=4,C_GREEN=5,C_CYAN=6;
int textW(const String& s,int size){size_t i=0;uint32_t cp=0;int n=0;while(nextDisplayCodepoint(s.c_str(),s.size(),i,cp))n++;return n*6*size;}
void centerText(const String& s,int y,int size,int){draws.push_back({s,y,size});}
void drawFooter(const char* s){footer=s;}
String displayAscii(String s){return s;}
String flightStatusGerman(const char*){return "STATUS";}
struct Settings{String trackedFlightNo,aviationstackKey;} cfg;
struct TrackedFlightSnapshot {SNAPSHOT};
TrackedFlightSnapshot data={};
const TrackedFlightSnapshot& trackedFlightData(){return data;}
String trackedFlightDuration(const TrackedFlightSnapshot&){return "01:30";}
'''.replace('SNAPSHOT',snapshot)
post=r'''
int main(){
 FlightRoute route={};
 for(const char* text:{"OSL-IST","LEJ-BLR-HKG","AAA-BBB-CCC-DDD","AAA-BBB-CCC-DDD-EEE-FFF-GGG-HHH","AAA-BBB-CCC-DDD-EEE-FFF-GGG-HHH-III"}){
   assert(parseFlightRoute(text,route));draws.clear();
   drawFlightRoute(route,route.airports[0],route.airports[route.count-1],105);
   for(auto d:draws){assert(textW(d.text,d.size)<=224);assert(d.y>=105&&d.y+d.size*7<=133);}
   if(route.count==2){assert(draws.size()==1&&draws[0].text=="OSL > IST"&&draws[0].size==3&&draws[0].y==105);}
 }
 cfg={};draws.clear();footer="";drawTrackedFlight();assert(footer=="FLUGNUMMER FEHLT");
 bool hint=false;for(auto d:draws)if(d.text=="Webinterface eingeben")hint=true;assert(hint);
 cfg.trackedFlightNo="AF1234";footer="";drawTrackedFlight();assert(footer=="API-KEY FEHLT");
 cfg.aviationstackKey="fixture";footer="";drawTrackedFlight();assert(footer=="LADE FLUGDATEN");
 data.error=true;footer="";drawTrackedFlight();assert(footer=="TRACKER FEHLER");
 data.error=false;data.notFound=true;footer="";drawTrackedFlight();assert(footer=="FLUG NICHT GEFUNDEN");
 data.valid=true;data.notFound=false;strcpy(data.origin,"OSL");strcpy(data.destination,"IST");
 strcpy(data.arrActual,"N/A");draws.clear();footer="";drawTrackedFlight();assert(footer=="AVIATIONSTACK + ADSB.LOL");
 assert(draws[1].text=="OSL > IST"&&draws[1].y==36&&draws[1].size==3);
 data.error=true;footer="";drawTrackedFlight();assert(footer=="LETZTER STAND");
 puts("Real drawing functions: route bounds, unchanged two-airport layout, tracker footer states OK");
}
'''
with tempfile.TemporaryDirectory() as t:
 p=Path(t);(p/'test.cpp').write_text(pre+'\n'+fn('routePart')+'\n'+fn('drawFlightRoute')+'\n'+fn('drawTrackedFlight')+'\n'+post)
 subprocess.run(['g++','-std=c++11','-Wall','-Wextra','-Werror','-I'+str(root/'src'),str(p/'test.cpp'),'-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],check=True)
