#!/usr/bin/env python3
"""Validate the actual release source and its embedded web script."""
from pathlib import Path
import subprocess,tempfile,re
root=Path(__file__).resolve().parents[1]
s=(root/'src/main.cpp').read_text()
assert '#define FW_VERSION "0.4.6"' in s
assert '>v0.4.6</span>' in s
for name in ['README.md','LICENSE','CONTRIBUTING.md','THIRD_PARTY_SERVICES.md','ROADMAP.md','TESTPLAN.md','CHANGELOG.md']:
 assert (root/name).is_file(),name
html=s.split('R"HTML(',1)[1].split(')HTML"',1)[0]
assert 'navigator.geolocation' not in html and 'alert(' not in html
assert 'entwickelt von du13500' in html
ids=re.findall(r'\bid="([^"${]+)"',html)
assert len(ids)==len(set(ids)), 'Duplicate fixed HTML ID'
# Extract every inline script, rather than treating a stored boolean as a test.
with tempfile.TemporaryDirectory() as tmp:
 for i,js in enumerate(re.findall(r'<script>(.*?)</script>',html,re.S)):
  p=Path(tmp)/f'webui-{i}.js';p.write_text(js);subprocess.run(['node','--check',str(p)],check=True)
# Ensure generated font matches its reproducible source.
font=(root/'src/PixelFont.h').read_bytes()
subprocess.run(['python3',str(root/'tools/generate_font.py')],check=True)
assert (root/'src/PixelFont.h').read_bytes()==font,'Regenerate PixelFont.h'
for p in root.glob('src/*'):
 assert '0.4.5' not in p.read_text(),str(p)
print('Release files, version, web JavaScript and generated font: OK')
