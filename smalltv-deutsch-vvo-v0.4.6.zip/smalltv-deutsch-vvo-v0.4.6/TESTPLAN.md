# Testplan v0.4.6

## Automatische Prüfungen

Im entpackten Versionsordner:

```sh
python3 tools/check.py
g++ -std=c++11 -Wall -Wextra -Werror tests/test_core.cpp -o /tmp/smalltv-test-core
/tmp/smalltv-test-core
python3 tools/test_display.py
pio run -e smalltv_ultra
```

`test_core.cpp` prüft echte UTF-8-/Font-/Routenfunktionen, einschließlich
abgebrochener und ungültiger Sequenzen, zusammengesetzter Akzente, Herzvarianten,
fehlender Zeichen und langer/ungültiger Routen.
`test_display.py` kompiliert die tatsächlichen Zeichenfunktionen mit einem
aufzeichnenden Display: Zwei-Flughäfen-Layout, Platzbedarf längerer Routen und
Footer bei leerer Konfiguration, fehlendem Key, Laden, Fehler, fehlendem Flug,
Erfolg und veraltetem Stand.

Browserprüfung: `npm install --ignore-scripts`,
`npx playwright install --with-deps webkit`, dann `npm run test:webui`.
Diese Prüfung läuft ebenfalls im Build-Workflow.
Sie misst Zeitfeldgrenzen bei iPhone-/iPad-Breiten, Feldabstände und einheitliche
Beschriftungen. Diese Emulation ersetzt keinen Test in nativem iOS-Safari.

## Noch auf echter Hardware zu prüfen

1. **OTA und Konfiguration:** Update von v0.4.5; WLAN, Rotation, Orte, Nachtzeiten,
   vier Countdowns und gespeicherter API-Key bleiben erhalten.
2. **Safari:** Beginn/Ende bei 320/375/390/430 px untereinander und bei iPad-Breite
   nebeneinander, innerhalb der Karte und mit Abstand. Zeitauswahl weiterhin bedienbar.
3. **Checkbox-Beschriftungen:** grau, normale Schriftstärke wie Aktualisierung;
   Standortintervall bei ausgeschaltetem Standortnamen sichtbar deaktiviert.
4. **Wetter:** H/T ohne Abstand vor °C/°F, auch negative und dreistellige Werte.
   Haupttemperatur, Farben, Symbole und Ausrichtung unverändert.
5. **Geo:** Suche Dresden auswählen, danach Pin in Seidnitz setzen. Suche liefert
   Dresden, Pin darf Stadtteil liefern. Lokale/deutsche Schreibweise testen;
   Wetter und Radar getrennte Koordinaten. Gewässer-Fallback und HTTP-Fehler prüfen.
6. **Schrift:** `České Budějovice`, `Łódź`, `Tromsø`, `Été`, `François`,
   `äöüÄÖÜß`, `?`, unbekanntes Emoji. Herzen in gelbem/rotem Countdown-Titel
   einschließlich ❤️, 💛, 🩷 und ❤️‍🔥; kein zusätzliches Kästchen oder Leerzeichen.
7. **Radar:** Route mit zwei Flughäfen bleibt optisch gleich. Drei und vier
   Flughäfen werden vollständig und kompakter dargestellt. Längere Ketten
   bleiben im vorgesehenen Bereich, unbekannte Routen bleiben N/A.
8. **Tracker:** kein Flug, kein Key, Ladezustand, Fehler, nicht gefundener Flug
   und echte Daten. Footer immer sichtbar; Uhr wechselt auch ohne API-Erfolg
   zur nächsten Minute. Vollständiger zweizeiliger Eingabehinweis.
9. **Tracker mit Key:** Plan-/Ist-Zeiten und bestehende Pollintervalle prüfen.
   Ergänzte Route muss den gelieferten Flugabschnitt enthalten. Routenquelle
   liefert keine Nonstop-Garantie. Nur wenige Routenabrufe pro Fluginstanz.
10. **Regression:** VVO 3/4/5/10, fester 5-s-Seitenwechsel, rotes Ausfall-X,
    kompakte Ziele an/aus, Uhr, Rotation, Countdowns, Speichern und Neustart.

Buildnachweis und hier ausgeführte Prüfungen: siehe VALIDATION.md im Lieferpaket.
