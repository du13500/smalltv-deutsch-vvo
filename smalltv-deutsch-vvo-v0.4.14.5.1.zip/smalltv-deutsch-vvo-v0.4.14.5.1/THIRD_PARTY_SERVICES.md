# Externe Datenquellen und Dienste

Die Projektlizenz MIT gilt für den eigenen Projektcode und die Dokumentation. Sie überträgt keine
Rechte an fremden Daten, Marken, Bibliotheken oder Diensten. Deren jeweilige
Bedingungen, Limits und Attributionspflichten gelten unabhängig davon.

| Verwendung | Dienst und maßgebliche Informationen |
| --- | --- |
| Haltestellen und Abfahrten | [VVO](https://www.vvo-online.de/), [Impressum](https://www.vvo-online.de/de/impressum/index.cshtml) |
| Wetter | [Open-Meteo](https://open-meteo.com/), [Bedingungen](https://open-meteo.com/en/terms) |
| Ortssuche und Reverse-Geocoding | [Nominatim](https://nominatim.org/release-docs/latest/api/Overview/), [Nutzungsregeln](https://operations.osmfoundation.org/policies/nominatim/) |
| Flugradar, Live-Telemetrie und Routen | [adsb.lol API und Datenlizenz](https://www.adsb.lol/docs/open-data/api/) |
| Routen-Fallback und einzelne Zwischenstopps | [adsbdb](https://www.adsbdb.com/), [Projektdokumentation](https://github.com/mrjackwills/adsbdb) |
| Flugplandaten und Status im Tracker | [aviationstack](https://aviationstack.com/), [API-Dokumentation](https://docs.apilayer.com/aviationstack/docs/api-documentation) |
| Karten und Attribution | [OpenStreetMap Copyright](https://www.openstreetmap.org/copyright), [Kachelserver-Regeln](https://operations.osmfoundation.org/policies/tiles/) |
| Kartenbibliothek im Browser | [Leaflet](https://leafletjs.com/), ausgeliefert über unpkg.com |
| Uhrzeit | pool.ntp.org, time.cloudflare.com |

Ein kostenloser Zugriff ist keine pauschale Freigabe für jede Weiterverwendung.
Vor kommerzieller Nutzung oder Weiterverteilung der Daten die aktuellen
Anbieterbedingungen prüfen. Insbesondere nennt adsbdb in seiner Dokumentation
zusätzliche Bedingungen für die übernommenen Routendaten.

## Flugtracker: Ergebnis der Quellenprüfung für v0.4.6

adsbdb dokumentiert IATA-/ICAO-Rufzeichen, Start und Ziel sowie für manche Routen
einen `midpoint`. Diese Angaben beschreiben eine zugeordnete Route, nicht
zuverlässig den vollständigen aktuellen Flugplan oder Verspätungsstatus.
adsb.lol liefert empfangene Live-Telemetrie und die Routenfolge des Rufzeichens.
Fehlender ADS-B-Empfang bedeutet weder „gelandet“ noch „annulliert“.

Ein gleichwertiger kostenloser Ersatz ohne API-Key für alle bestehenden
Tracker-Felder ist in dieser Prüfung nicht belegt. **v0.4.6 behält aviationstack
für Plan-/Ist-Zeiten und Status bei.** Ohne eigenen Key bleiben diese Angaben
unverfügbar. Der Tracker ergänzt belegte Zwischenstopps über die vorhandenen
Routenquellen, wenn deren Route den gemeldeten Flugabschnitt enthält. Angezeigte
Start-/Zielpaare sind keine Nonstop-Zusage.

Prüfstand: 6. Oktober 2026. Anbieter können APIs und Bedingungen ändern.

## Abrufverhalten ab v0.4.11

Radarpositionen und Zusatzdaten werden getrennt geladen. Mehrteilige Routen bleiben erhalten, wenn die bestehende Positionsprüfung sie akzeptiert. Ein Start- oder Zielflughafen wird nicht allein aus der Nähe zu einem Flughafen abgeleitet. Die Quellen können weiterhin veraltete, unvollständige oder falsche Routen liefern.

## Ergänzungen v0.4.14.5

Die Browser-Ortssuche nutzt Nominatim direkt. Die öffentliche Instanz verlangt manuelle Auswahl, Identifikation der Anwendung, Attribution, Zwischenspeicherung und höchstens eine Anfrage pro Sekunde für die gesamte Anwendung. Die lokale Warteschlange ersetzt keine anwendungsweite Koordination mehrerer Browser. Der Dienst ist ohne Firmwarewechsel unter System austauschbar.

Die adsb.lol-API-Dokumentation nennt ODbL 1.0 für ihre Daten. Die CC0-Angabe zu eingesendeten Feederdaten ist davon zu unterscheiden. Aus den öffentlichen API-Hinweisen lässt sich kein garantierter fester Abrufrhythmus ableiten. HTTP 429 und Retry-After werden respektiert; Verbindungsfehler sind keine bestätigte Anbieterpause.

Open-Meteo erlaubt den kostenlosen Zugang für nichtkommerzielle Nutzung unter den veröffentlichten Grenzen; weitere Nutzung erfordert Prüfung des passenden Angebots. Die Code-Lizenz von adsbdb überträgt keine pauschalen Rechte an übernommenen Routendaten. Die Dokumentation nennt Einschränkungen für deren Veröffentlichung und Übernahme in andere Datenbanken.

Anbieterinformationen am 11. Oktober 2026 geprüft. Maßgeblich bleiben die aktuellen Originalbedingungen. Links sind im Webinterface unter System zugänglich.
