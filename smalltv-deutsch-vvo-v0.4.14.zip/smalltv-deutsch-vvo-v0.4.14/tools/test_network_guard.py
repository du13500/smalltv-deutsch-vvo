#!/usr/bin/env python3
"""Exercise production guards before and after TLS stack allocation."""
from pathlib import Path
import subprocess, tempfile
root=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as tmp:
 p=Path(tmp)
 (p/'Arduino.h').write_text('''#pragma once
#include <cstdint>
struct Print;
''')
 (p/'ESP8266WiFi.h').write_text('''#pragma once
#include <cstddef>
#include <cstdint>
struct FakeESP {uint32_t heap=22040,block=20576;
 uint32_t getFreeHeap(){return heap;}uint32_t getMaxFreeBlockSize(){return block;}};
static FakeESP ESP;
''')
 (p/'WiFiClientSecureBearSSL.h').write_text('''#pragma once
// Context size matching the reported 18,922-byte budget at rx=4096.
struct br_ssl_client_context {char bytes[3408];};
namespace BearSSL {struct WiFiClientSecure {
 static bool probeMaxFragmentLength(const char*,int,int){return false;}};}
''')
 (p/'test.cpp').write_text('''#include "NetworkGuard.h"
#include <cassert>
static uint32_t recorded=0;
void diagEvent(DiagOp,DiagStage stage,int code,uint32_t value){assert(stage==DS_HEAP&&code==0);recorded=value;}
int main(){
 assert(networkHeapReady(D_GEO_SEARCH,4096));
 ESP.heap=15016;ESP.block=14368;
 assert(!networkHeapReady(D_GEO_SEARCH,4096)&&recorded==18922);
 assert(networkPreparedHeapReady(D_GEO_SEARCH,4096));
 ESP.heap=13424;ESP.block=12952;
 assert(networkPreparedHeapReady(D_GEO_REVERSE,4096));
 ESP.heap=12778;ESP.block=8517;
 assert(networkPreparedHeapReady(D_GEO_SEARCH,4096));
 --ESP.heap;assert(!networkPreparedHeapReady(D_GEO_SEARCH,4096)&&recorded==12778);
 ESP.heap=20000;ESP.block=8516;
 assert(!networkPreparedHeapReady(D_GEO_REVERSE,4096));
 // A smaller negotiated TLS buffer still requires context and reserve.
 ESP.heap=15000;ESP.block=10000;assert(networkPreparedHeapReady(D_GEO_SEARCH,512));
 ESP.heap=5000;assert(!networkPreparedHeapReady(D_GEO_SEARCH,512));
}
''')
 subprocess.run(['g++','-std=c++11','-Wall','-Wextra','-Werror','-I'+str(p),'-I'+str(root/'src'),str(p/'test.cpp'),'-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],check=True)
print('TLS guard: reported Geo heaps admitted after stack allocation; reserve and block limits retained')
