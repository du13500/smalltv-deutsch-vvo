# SmallTV-Ultra Loader v0.1

Minimaler ESP8266-OTA-Loader für den GeekMagic SmallTV-Ultra.

Zweck:
1. Passt in den kleinen OTA-Slot der Ultra-Stock-Firmware.
2. Startet anschließend den offenen WLAN-Hotspot `SmallTV-Loader`.
3. Unter `http://192.168.4.1/update` kann die eigentliche Firmware hochgeladen werden.

Diese Datei ist nur der Zwischenschritt für die erste Installation.

Wichtig:
- Noch nicht flashen, bevor der GitHub-Actions-Build grün ist.
- Nach dem ersten Flash gibt es ohne vorherige UART-Sicherung keinen sicheren Weg zurück zur originalen Stock-Firmware.
