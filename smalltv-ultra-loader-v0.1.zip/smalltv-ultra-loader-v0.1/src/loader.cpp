#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#include <ESP8266HTTPUpdateServer.h>

static ESP8266WebServer server(80);
static ESP8266HTTPUpdateServer updater;

void setup() {
  Serial.begin(115200);
  WiFi.persistent(false);

  WiFi.mode(WIFI_AP);
  WiFi.softAP("SmallTV-Loader");

  updater.setup(&server, "/update");
  server.begin();
}

void loop() {
  server.handleClient();
  yield();
}
