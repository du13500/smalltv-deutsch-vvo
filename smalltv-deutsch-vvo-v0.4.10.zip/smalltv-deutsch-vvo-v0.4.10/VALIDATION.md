# Validierung v0.4.10

## Automatisierte Prüfungen

- Quellen, Versionsangaben, aktuelles GitHub-Badge, JavaScript-Syntax, Zeitzonen und reproduzierbarer Pixel-Font geprüft.
- C++11-Kerntests mit -Wall -Wextra -Werror: UTF-8, lateinische, griechische und kyrillische Zeichen, Wettercodes, Zeitzonen und Routen.
- Reale Radar-Vorabfunktionen: Heapprüfung, Poll-Takt, Fehlerzustände, 30-Sekunden-Ablauf, Erholung und millis-Überlauf.
- Tatsächlicher Radar-Ergänzungsscheduler mit ersetzten Netzwerkübertragungen: eine Quelle je Phase, keine Online-Abfrage beim Anwenden des Caches, Anbieterpause und Zeitabstände.
- Abfragepolitik: Retry-After als Sekunden und HTTP-Datum, gestufte Anbieterpause, über Erfolge hinweg erhaltenes Mindestintervall, Rückkehr nach zehn Minuten, HTTP 201, Trennung der Anbieter und Zeitüberlauf; synthetische DRS-Routenbeispiele.
- Produktionsallocator mit der gepinnten ArduinoJson-Bibliothek: 200 Zyklen ohne verbleibende Allocations, Heapreserve, verweigertes Wachstum, sicheres Schrumpfen und gezieltes NoMemory. Dieser Hosttest simuliert Speicherbudgets, keine echten SDK-Allokationen.
- Tatsächlicher Diagnosecode mit simuliertem ESP: Ringüberlauf, Reihenfolge, Dauer, RTC-Prüfsumme, beschädigter Marker, Erhalt der ersten 128 RTC-Bytes und Zeitüberlauf.
- PollPolicy: Start bei millis 0, Wiederholungen nach 15/30/60/120 Sekunden, normale Intervalle nach Erfolg und Zeitüberlauf.
- Tatsächliche Zeichenfunktionen mit Grafik-Recorder: selektive Updates, Zustands- und Layoutwechsel, kürzere Texte, GND/N/A/0 m und Unicode-Grenzen.
- WebKit bei neun Breiten von 320 bis 1024 Pixeln: Layout, Zeitzone laden/speichern, Kartenlängen, schnelle Picks, veraltete Antworten, asiatischer Ortsname und Speichern namenloser Positionen. Zusätzlich Speichersperre während Debounce/HTTP, Schutz vor direktem save-Aufruf, Warteschlangen für beide Karten, Freigabe nach Fehlern und Diagnoseanzeige/Downloadlink. Antworten sind kontrollierte Fixtures.

## Firmware-Build

PlatformIO 6.1.19, espressif8266 4.2.1, Arduino-ESP8266 3.1.2, ArduinoJson 7.4.3 und GFX Library for Arduino 1.6.8: vollständige Kompilierung und BIN-Erzeugung erfolgreich.

- Statisches RAM: 52.636 von 81.920 Bytes (64,3 %).
- Firmware-Flash: 693.091 von 1.044.464 Bytes (66,4 % der Buildpartition).
- Gegenüber v0.4.9: +268 Bytes statisches RAM und +2.244 Bytes Firmware-Flash.

Dies ist keine Messung des freien Laufzeit-Heaps. Der Ereignisring enthält 24 Einträge mit zusammen 480 Bytes; die übrigen Mehrkosten enthalten unter anderem Reset-Texte und neue Zustandsdaten.

Die lokale Prüfung nutzte die festgelegten offiziellen Compiler-/Frameworkpakete. Wegen eines nicht funktionierenden Paketdownloads wurde nur lokal das unbenutzte alte Uploadwerkzeug tool-esptool als optional markiert. Die bereits installierten, identischen Bibliotheksversionen wurden übernommen. Plattformdatei und Workflow im Download sind unverändert auf die reguläre Plattform ausgerichtet. Zusätzlich wurde das Begleitarchiv aus Projekt-/Frameworkquellen, Bibliotheken und tatsächlichen Buildobjekten testweise erstellt. Kein GitHub-Repository verändert; die BIN für die Installation entsteht weiterhin über den GitHub-Workflow.

## Noch offen

Kein echter SmallTV in dieser Umgebung. Radar-Aussetzer und schnelle Wetter-Ortswechsel sind damit nicht als behoben nachgewiesen. Online-Betrieb, TLS-Verhalten, Speicherentwicklung, RTC-Erhalt nach realem Reboot, echter Safari-Betrieb, Routenqualität und Tracker mit API-Schlüssel bleiben Hardwaretests.

Die Diagnose vermeidet Zugangsdaten und vollständige URLs. Der RTC-Marker zeigt lediglich den letzten protokollierten Schritt; daraus allein folgt keine Absturzursache. Routenprüfung garantiert keine korrekte Route. Wetter-Icon-Design bleibt unverändert.
