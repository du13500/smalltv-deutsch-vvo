#pragma once
#include <ESP8266WiFi.h>
#include <WiFiClientSecureBearSSL.h>
#include "RadarPolicy.h"
#include "Diagnostics.h"
static inline bool networkHeapReady(DiagOp op,uint16_t rx=4096){
 bool ok=radarTlsFits(ESP.getFreeHeap(),ESP.getMaxFreeBlockSize(),rx,sizeof(br_ssl_client_context));
 if(!ok)diagEvent(op,DS_HEAP,0,radarTlsBudget(rx,sizeof(br_ssl_client_context)).total);
 return ok;
}

// Only use a small receive buffer when the server explicitly supports MFLN.
static inline uint16_t networkTlsRx(const char* host,uint16_t& cached,DiagOp op) {
 if(cached)return cached;
 if(!networkHeapReady(op,4096))return 4096;
 cached=BearSSL::WiFiClientSecure::probeMaxFragmentLength(host,443,512)?512:4096;
 return cached;
}
