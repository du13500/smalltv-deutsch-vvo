# Themenspeicher

- Radar-Zuverlässigkeit mit v0.4.10 auf Hardware prüfen; bei Aussetzern den Diagnose-Log auswerten.
- Wetter-Ortswechsel und VVO-Erstabruf testen; Neustart-Hinweise sind noch kein Ursachenbeweis.
- Wetter-Icons in einem zukünftigen Build gestalterisch überarbeiten, zunächst Motive und Varianten gemeinsam vergleichen.
- Flug-Tracker mit gültigem aviationstack-Schlüssel vollständig prüfen.
- Erneuter Dauerbetrieb mit allen Programmen nach den Speicheränderungen; ein kurzer Rotationstest in v0.4.9 lieferte erfolgreiche Abrufe, aber keinen Langzeitnachweis.
- MIT für eigene Quellen ist festgelegt. Herkunft des konkreten GFX-Pakets und dateispezifische Framework-/SDK-Hinweise weiter prüfen.
- Nicht darstellbare Ortsnamen weiterhin über das optionale Freitextfeld lösen.
