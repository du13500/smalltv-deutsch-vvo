#include "Flight.h"
#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>
#include <WiFiClientSecureBearSSL.h>
#include <ArduinoJson.h>
#include <math.h>

static FlightSnapshot g_f = {};
static uint32_t g_lastPollMs = 0;
static uint32_t g_lastOkMs = 0;
static BearSSL::Session g_adsbSession;
static BearSSL::Session g_routeSession;
static BearSSL::Session g_adsbDbSession;
static char g_routeCallsign[12] = "";
static char g_routeOrigin[4] = "N/A";
static char g_routeDestination[4] = "N/A";

static void makeSecure(BearSSL::WiFiClientSecure& client, BearSSL::Session* session) {
  client.setInsecure();
  client.setBufferSizes(4096, 512);
  client.setSession(session);
  client.setTimeout(9000);
}

static void trimTail(char* s) {
  int n = strlen(s);
  while (n > 0 && (s[n-1] == ' ' || s[n-1] == '\t')) s[--n] = 0;
}

static float distanceKm(float lat1, float lon1, float lat2, float lon2) {
  float dLat = (lat2 - lat1) * 111.0f;
  float dLon = (lon2 - lon1) * 111.0f * cosf(lat1 * (float)PI / 180.0f);
  return sqrtf(dLat*dLat + dLon*dLon);
}

static const char* airlineFor(const char* cs) {
  if (!cs || strlen(cs) < 3) return "";
  struct M { const char* p; const char* n; };
  static const M map[] = {
    {"EWG","Eurowings"},{"DLH","Lufthansa"},{"RYR","Ryanair"},{"EJU","easyJet"},
    {"EZY","easyJet"},{"CFG","Condor"},{"WZZ","Wizz Air"},{"TVS","Smartwings"},
    {"AUA","Austrian"},{"SWR","SWISS"},{"KLM","KLM"},{"AFR","Air France"},
    {"BAW","British Airways"},{"LOT","LOT"},{"SAS","SAS"},{"THY","Turkish Airlines"},
    {"BEL","Brussels Airlines"},{"UAE","Emirates"},{"QTR","Qatar Airways"},{"EXS","Jet2"},
    {"TUI","TUI"},{"ITY","ITA Airways"},{"IBE","Iberia"},{"VLG","Vueling"}
  };
  for (const auto& m : map) if (!strncmp(cs, m.p, 3)) return m.n;
  return "";
}

static const char* typeNameFor(const char* t) {
  if (!t || !*t) return "";
  struct M { const char* c; const char* n; };
  static const M map[] = {
    {"A20N","Airbus A320neo"},{"A21N","Airbus A321neo"},{"A320","Airbus A320"},
    {"A321","Airbus A321"},{"A319","Airbus A319"},{"A318","Airbus A318"},
    {"A359","Airbus A350-900"},{"A35K","Airbus A350-1000"},{"A333","Airbus A330-300"},
    {"A332","Airbus A330-200"},{"B738","Boeing 737-800"},{"B737","Boeing 737-700"},
    {"B38M","Boeing 737 MAX 8"},{"B39M","Boeing 737 MAX 9"},{"B788","Boeing 787-8"},
    {"B789","Boeing 787-9"},{"B772","Boeing 777-200"},{"B77W","Boeing 777-300ER"},
    {"E190","Embraer E190"},{"E195","Embraer E195"},{"E290","Embraer E190-E2"},
    {"E295","Embraer E195-E2"},{"CRJ9","CRJ900"},{"BCS1","Airbus A220-100"},
    {"BCS3","Airbus A220-300"},{"AT76","ATR 72-600"},{"DH8D","Dash 8 Q400"}
  };
  for (const auto& m : map) if (!strcmp(t, m.c)) return m.n;
  return t;
}

static void routeFallback(char outOrigin[4], char outDestination[4]) {
  strlcpy(outOrigin, "N/A", 4);
  strlcpy(outDestination, "N/A", 4);
}

static bool routeComplete(const char origin[4], const char destination[4]) {
  return strlen(origin) == 3 && strlen(destination) == 3 && strcmp(origin, "N/A") && strcmp(destination, "N/A");
}

static bool lookupRouteAdsbLol(const char* callsign, float lat, float lon, char origin[4], char destination[4]) {
  BearSSL::WiFiClientSecure client;
  makeSecure(client, &g_routeSession);
  HTTPClient http;
  http.useHTTP10(true);
  http.setTimeout(9000);
  http.setReuse(false);
  if (!http.begin(client, "https://api.adsb.lol/api/0/routeset")) return false;
  http.addHeader("Content-Type", "application/json");
  http.addHeader("Accept", "application/json");
  http.setUserAgent("SmallTV-DD/0.4.1");

  JsonDocument req;
  JsonArray planes = req["planes"].to<JsonArray>();
  JsonObject p = planes.add<JsonObject>();
  p["callsign"] = callsign;
  p["lat"] = lat;
  p["lng"] = lon;
  String body;
  serializeJson(req, body);

  int code = http.POST(body);
  if (code != HTTP_CODE_OK) { http.end(); return false; }

  JsonDocument filter;
  JsonArray filterArray = filter.to<JsonArray>();
  JsonObject filterItem = filterArray.add<JsonObject>();
  filterItem["_airport_codes_iata"] = true;
  JsonDocument doc;
  DeserializationError err = deserializeJson(doc, http.getStream(), DeserializationOption::Filter(filter));
  http.end();
  if (err || !doc.is<JsonArrayConst>() || doc.as<JsonArrayConst>().size() == 0) return false;

  String route = doc[0]["_airport_codes_iata"] | "";
  route.trim();
  if (!route.length() || route == "unknown") return false;
  int firstDash = route.indexOf('-');
  int lastDash = route.lastIndexOf('-');
  if (firstDash < 0) return false;
  String a = route.substring(0, firstDash);
  String b = route.substring(lastDash + 1);
  a.trim(); b.trim();
  if (a.length() == 3) strlcpy(origin, a.c_str(), 4);
  if (b.length() == 3) strlcpy(destination, b.c_str(), 4);
  return routeComplete(origin, destination);
}

static bool lookupRouteAdsbDb(const char* callsign, char origin[4], char destination[4]) {
  BearSSL::WiFiClientSecure client;
  makeSecure(client, &g_adsbDbSession);
  HTTPClient http;
  http.useHTTP10(true);
  http.setTimeout(9000);
  http.setReuse(false);
  String url = F("https://api.adsbdb.com/v0/callsign/");
  url += callsign;
  if (!http.begin(client, url)) return false;
  http.addHeader("Accept", "application/json");
  http.setUserAgent("SmallTV-DD/0.4.1");

  int code = http.GET();
  if (code != HTTP_CODE_OK) { http.end(); return false; }

  JsonDocument filter;
  filter["response"]["flightroute"]["origin"]["iata_code"] = true;
  filter["response"]["flightroute"]["destination"]["iata_code"] = true;
  JsonDocument doc;
  DeserializationError err = deserializeJson(doc, http.getStream(), DeserializationOption::Filter(filter));
  http.end();
  if (err) return false;

  String a = doc["response"]["flightroute"]["origin"]["iata_code"] | "";
  String b = doc["response"]["flightroute"]["destination"]["iata_code"] | "";
  a.trim(); b.trim(); a.toUpperCase(); b.toUpperCase();
  if (a.length() == 3) strlcpy(origin, a.c_str(), 4);
  if (b.length() == 3) strlcpy(destination, b.c_str(), 4);
  return routeComplete(origin, destination);
}

static bool lookupRoute(const char* callsign, float lat, float lon, char origin[4], char destination[4]) {
  routeFallback(origin, destination);
  if (!callsign || strlen(callsign) < 3) return false;
  if (!strcmp(callsign, g_routeCallsign)) {
    strlcpy(origin, g_routeOrigin, 4);
    strlcpy(destination, g_routeDestination, 4);
    return routeComplete(origin, destination);
  }

  // Cache auch fehlende Treffer. Ein neues Flugzeug darf erneut beide Quellen versuchen,
  // derselbe Callsign soll aber nicht im Sekundentakt die Route-APIs belasten.
  strlcpy(g_routeCallsign, callsign, sizeof(g_routeCallsign));
  strlcpy(g_routeOrigin, "N/A", sizeof(g_routeOrigin));
  strlcpy(g_routeDestination, "N/A", sizeof(g_routeDestination));

  bool ok = lookupRouteAdsbLol(callsign, lat, lon, origin, destination);
  if (!ok) {
    routeFallback(origin, destination);
    ok = lookupRouteAdsbDb(callsign, origin, destination);
  }

  strlcpy(g_routeOrigin, origin, sizeof(g_routeOrigin));
  strlcpy(g_routeDestination, destination, sizeof(g_routeDestination));
  return ok;
}

void flightReset() {
  memset(&g_f, 0, sizeof(g_f));
  g_lastPollMs = 0;
  g_lastOkMs = 0;
  g_routeCallsign[0] = 0;
  strlcpy(g_routeOrigin, "N/A", sizeof(g_routeOrigin));
  strlcpy(g_routeDestination, "N/A", sizeof(g_routeDestination));
}

bool flightPollDue(uint16_t pollSec) {
  if (g_lastPollMs == 0) return true;
  return (uint32_t)(millis() - g_lastPollMs) >= (uint32_t)pollSec * 1000UL;
}

const FlightSnapshot& flightData() { return g_f; }
uint32_t flightLastOkMs() { return g_lastOkMs; }

bool flightFetch(float homeLat, float homeLon, uint16_t radiusKm) {
  g_lastPollMs = millis() | 1;
  if (WiFi.status() != WL_CONNECTED) { g_f.error = true; return false; }

  uint16_t radiusNm = (uint16_t)ceilf(radiusKm / 1.852f);
  if (radiusNm < 1) radiusNm = 1;
  if (radiusNm > 250) radiusNm = 250;

  FlightSnapshot next = {};
  char routeOrigin[4] = "N/A";
  char routeDestination[4] = "N/A";
  float acLat = NAN, acLon = NAN;

  {
    BearSSL::WiFiClientSecure client;
    makeSecure(client, &g_adsbSession);
    HTTPClient http;
    http.useHTTP10(true);
    http.setTimeout(9000);
    http.setReuse(false);

    String url = F("https://api.adsb.lol/v2/closest/");
    url += String(homeLat, 4); url += '/';
    url += String(homeLon, 4); url += '/';
    url += String(radiusNm);
    if (!http.begin(client, url)) { g_f.error = true; return false; }
    http.addHeader("Accept", "application/json");
    http.setUserAgent("SmallTV-DD/0.4.1");

    int code = http.GET();
    if (code != HTTP_CODE_OK) { http.end(); g_f.error = true; return false; }

    JsonDocument filter;
    JsonObject f = filter["ac"][0].to<JsonObject>();
    f["flight"] = true; f["r"] = true; f["t"] = true;
    f["lat"] = true; f["lon"] = true; f["alt_baro"] = true; f["hex"] = true;
    JsonDocument doc;
    DeserializationError err = deserializeJson(doc, http.getStream(), DeserializationOption::Filter(filter));
    http.end();
    if (err) { g_f.error = true; return false; }

    JsonArrayConst ac = doc["ac"].as<JsonArrayConst>();
    if (ac.isNull() || ac.size() == 0) {
      memset(&g_f, 0, sizeof(g_f));
      g_f.error = false;
      g_lastOkMs = millis();
      return true;
    }

    JsonObjectConst a = ac[0].as<JsonObjectConst>();
    const char* rawCall = a["flight"] | (a["hex"] | "");
    strlcpy(next.callsign, rawCall, sizeof(next.callsign));
    trimTail(next.callsign);
    strlcpy(next.registration, a["r"] | "", sizeof(next.registration));
    strlcpy(next.typeCode, a["t"] | "", sizeof(next.typeCode));
    strlcpy(next.typeName, typeNameFor(next.typeCode), sizeof(next.typeName));
    strlcpy(next.airline, airlineFor(next.callsign), sizeof(next.airline));
    next.altitudeFt = a["alt_baro"].is<int>() ? a["alt_baro"].as<int>() : 0;
    if (a["lat"].is<float>() || a["lat"].is<int>()) acLat = a["lat"].as<float>();
    if (a["lon"].is<float>() || a["lon"].is<int>()) acLon = a["lon"].as<float>();
    if (!isnan(acLat) && !isnan(acLon)) next.distanceKm = distanceKm(homeLat, homeLon, acLat, acLon);
    next.valid = true;
    next.error = false;
  }

  if (next.callsign[0] && !isnan(acLat) && !isnan(acLon)) {
    lookupRoute(next.callsign, acLat, acLon, routeOrigin, routeDestination);
  }
  strlcpy(next.origin, routeOrigin, sizeof(next.origin));
  strlcpy(next.destination, routeDestination, sizeof(next.destination));

  g_f = next;
  g_lastOkMs = millis();
  return true;
}
