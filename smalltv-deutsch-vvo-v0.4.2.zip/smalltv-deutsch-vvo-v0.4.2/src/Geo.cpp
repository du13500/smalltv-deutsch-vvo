#include "Geo.h"
#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>
#include <WiFiClientSecureBearSSL.h>
#include <ArduinoJson.h>

static BearSSL::Session g_geoSession;

static void makeSecure(BearSSL::WiFiClientSecure& client) {
  client.setInsecure();
  client.setBufferSizes(4096, 512);
  client.setSession(&g_geoSession);
  client.setTimeout(9000);
}

static String urlEncode(const String& in) {
  static const char* hex = "0123456789ABCDEF";
  String out;
  out.reserve(in.length() * 3);
  for (size_t i = 0; i < in.length(); i++) {
    uint8_t c = (uint8_t)in[i];
    if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
        (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.' || c == '~') {
      out += (char)c;
    } else if (c == ' ') {
      out += "%20";
    } else {
      out += '%'; out += hex[c >> 4]; out += hex[c & 15];
    }
  }
  return out;
}

bool geoSearchPlaces(const String& query, String& outJson) {
  if (WiFi.status() != WL_CONNECTED) return false;
  String q = query; q.trim();
  if (q.length() < 2) return false;

  BearSSL::WiFiClientSecure client;
  makeSecure(client);
  HTTPClient http;
  http.useHTTP10(true);
  http.setTimeout(9000);
  http.setReuse(false);

  String url = F("https://geocoding-api.open-meteo.com/v1/search?name=");
  url += urlEncode(q);
  url += F("&count=8&language=de&format=json");
  if (!http.begin(client, url)) return false;
  http.addHeader("Accept", "application/json");
  http.setUserAgent("SmallTV-DD/0.4.1");

  int code = http.GET();
  if (code != HTTP_CODE_OK) { http.end(); return false; }

  JsonDocument filter;
  JsonObject f = filter["results"][0].to<JsonObject>();
  f["name"] = true; f["admin1"] = true; f["country"] = true;
  f["latitude"] = true; f["longitude"] = true;
  JsonDocument doc;
  DeserializationError err = deserializeJson(doc, http.getStream(), DeserializationOption::Filter(filter));
  http.end();
  if (err) return false;

  JsonDocument out;
  out["ok"] = true;
  JsonArray places = out["places"].to<JsonArray>();
  for (JsonObjectConst r : doc["results"].as<JsonArrayConst>()) {
    const char* name = r["name"] | "";
    if (!name || !*name) continue;
    JsonObject p = places.add<JsonObject>();
    p["name"] = name;
    p["admin1"] = r["admin1"] | "";
    p["country"] = r["country"] | "";
    p["lat"] = r["latitude"].as<float>();
    p["lon"] = r["longitude"].as<float>();
    String label = name;
    String admin1 = r["admin1"] | "";
    String country = r["country"] | "";
    if (admin1.length() && admin1 != label) label += ", " + admin1;
    if (country.length()) label += ", " + country;
    p["label"] = label;
  }
  serializeJson(out, outJson);
  return true;
}
