#pragma once
#include <Arduino.h>

bool geoSearchPlaces(const String& query, String& outJson);
