# SmallTV DD v0.4 test plan

## Build gate

- GitHub Actions build must be green.
- Record static RAM, flash use and final `firmware.bin` size.
- Do not flash if the image exceeds the SmallTV 4m1m app slot.

## Existing modes

- VVO stop search and live departures.
- Open-Meteo refresh and fallback on network error.
- Nearby ADS-B refresh and `N/A` route fallback.
- NTP clock and Europe/Berlin DST handling.

## Flight tracker

- Empty flight number: `N/A` placeholders, no API request.
- Missing aviationstack key: local warning, no API request.
- Flight number is normalized to uppercase.
- Scheduled and actual departure display.
- Scheduled arrival and ETA; switch to actual arrival when available.
- Status translation for active, scheduled, landed, cancelled and diverted.
- Flight duration calculation.
- adsb.lol live altitude and ground speed update after ICAO flight number becomes known.
- aviationstack polling stops after terminal flight state.
- Saving unrelated settings must not expose the stored API key.

## Countdown slots 1–4

- Optional title hidden when empty.
- Title and counter both centered.
- Independent title and counter color per slot.
- Date-only timer changes exactly at local midnight.
- Leading zeroes remain stable, e.g. `-117` -> `-099` -> `-002` -> `000` -> `+001`.
- HMS timer: `-04:07:03` -> zero -> `+00:00:01`.
- MS timer: `-09:05` -> zero -> `+00:01`.
- Start/restart and stop work independently for all four slots.
- A running timer survives reboot because the absolute target is persisted.
- Inactive or unsynchronised timer shows dashes rather than a false value.

## Recovery

- First physical SmallTV-Ultra install remains loader first, full firmware second.
- UART remains the recovery fallback if OTA ever fails completely.
