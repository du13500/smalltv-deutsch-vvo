# SmallTV DD v0.4

Custom firmware for the GeekMagic SmallTV-Ultra (ESP8266 / ESP-12F, 240×240 ST7789).

## Display modes

- **Abfahrten**: live VVO departure monitor with realtime minutes, `JETZT` and `AUS`.
- **Wetter**: live Open-Meteo weather with current temperature, high/low, rain probability, sunrise and sunset.
- **Flugradar**: nearest aircraft via adsb.lol with callsign, airline, route, type, registration, distance and altitude.
- **Uhr**: NTP clock for Europe/Berlin.
- **Flug-Tracker**: one configured flight number. aviationstack supplies scheduled/estimated/actual times and status; adsb.lol supplements altitude and speed while airborne. Unknown values use `N/A`.
- **Countdown 1–4**: four persistent countdown slots.

## Countdown design

Each slot stores its own optional title, title color, countdown color and timer type.

Timer types are selected manually:

1. **Tage**: date-only calendar countdown. The target is a calendar day, not a hidden hour. It changes at local midnight. A countdown activated with three digits stays at least three digits (`-117`, `-099`, `-002`, `000`, `+001`).
2. **Stunden : Minuten : Sekunden**: duration timer with fixed zero-padded time fields.
3. **Minuten : Sekunden**: short duration timer.

Duration timers keep counting after zero with a plus sign until stopped. Their target epoch is persisted, so a power cycle does not reset the countdown once NTP time is available again.

The large countdown is drawn as a custom seven-segment display. Title and countdown are both horizontally centered. With an empty title, no title line is rendered and the counter gets more space.

## Flight tracker API

The flight tracker needs a personal aviationstack API key entered in the local web UI. The key is stored locally in LittleFS and is not returned by the configuration API. Status polling only runs while the flight-tracker screen is selected. Live ADS-B telemetry uses adsb.lol separately.

## Installation status

This is still a pre-flash build. Compile in GitHub Actions first and inspect RAM/flash use before installing on hardware. The SmallTV-Ultra first install uses the separate loader build.
