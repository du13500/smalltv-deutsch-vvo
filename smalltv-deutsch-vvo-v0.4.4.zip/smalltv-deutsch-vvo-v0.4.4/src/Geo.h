#pragma once
#include <Arduino.h>

bool geoSearchPlaces(const String& query, String& outJson);

bool geoReversePlace(float lat, float lon, String& outJson);
