#include "Weather.h"
#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>
#include <WiFiClientSecureBearSSL.h>
#include <ArduinoJson.h>

static WeatherSnapshot g_w = {};
static uint32_t g_lastPollMs = 0;
static uint32_t g_lastOkMs = 0;
static BearSSL::Session g_session;

static void makeSecure(BearSSL::WiFiClientSecure& client) {
  client.setInsecure();
  client.setBufferSizes(4096, 512);
  client.setSession(&g_session);
  client.setTimeout(9000);
}

static void hhmm(const char* iso, char out[6]) {
  strlcpy(out, "--:--", 6);
  if (!iso) return;
  const char* t = strchr(iso, 'T');
  if (!t || strlen(t) < 6) return;
  memcpy(out, t + 1, 5);
  out[5] = 0;
}

void weatherReset() {
  memset(&g_w, 0, sizeof(g_w));
  g_w.rainPct = -1;
  strlcpy(g_w.sunrise, "--:--", sizeof(g_w.sunrise));
  strlcpy(g_w.sunset, "--:--", sizeof(g_w.sunset));
  g_lastPollMs = 0;
  g_lastOkMs = 0;
}

bool weatherPollDue(uint16_t pollSec) {
  if (g_lastPollMs == 0) return true;
  return (uint32_t)(millis() - g_lastPollMs) >= (uint32_t)pollSec * 1000UL;
}

const WeatherSnapshot& weatherData() { return g_w; }
uint32_t weatherLastOkMs() { return g_lastOkMs; }

const char* weatherLabel(int code) {
  if (code == 0) return "KLAR";
  if (code == 1) return "HEITER";
  if (code == 2) return "WOLKIG";
  if (code == 3) return "BEWÖLKT";
  if (code == 45 || code == 48) return "NEBEL";
  if (code >= 51 && code <= 57) return "NIESEL";
  if (code >= 61 && code <= 67) return "REGEN";
  if (code >= 71 && code <= 77) return "SCHNEE";
  if (code >= 80 && code <= 82) return "SCHAUER";
  if (code >= 85 && code <= 86) return "SCHNEESCHAUER";
  if (code >= 95) return "GEWITTER";
  return "WETTER";
}

bool weatherFetch(float lat, float lon) {
  g_lastPollMs = millis() | 1;
  if (WiFi.status() != WL_CONNECTED) { g_w.error = true; return false; }

  BearSSL::WiFiClientSecure client;
  makeSecure(client);
  HTTPClient http;
  http.useHTTP10(true);
  http.setTimeout(9000);
  http.setReuse(false);

  String url = F("https://api.open-meteo.com/v1/forecast?latitude=");
  url += String(lat, 4);
  url += F("&longitude=");
  url += String(lon, 4);
  url += F("&current=temperature_2m,weather_code,is_day");
  url += F("&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,sunrise,sunset");
  url += F("&timezone=Europe%2FBerlin&forecast_days=1");

  if (!http.begin(client, url)) { g_w.error = true; return false; }
  http.addHeader("Accept", "application/json");
  http.setUserAgent("SmallTV-DD/0.4.4");

  int code = http.GET();
  if (code != HTTP_CODE_OK) { http.end(); g_w.error = true; return false; }

  JsonDocument filter;
  filter["current"]["temperature_2m"] = true;
  filter["current"]["weather_code"] = true;
  filter["current"]["is_day"] = true;
  filter["daily"]["temperature_2m_max"][0] = true;
  filter["daily"]["temperature_2m_min"][0] = true;
  filter["daily"]["precipitation_probability_max"][0] = true;
  filter["daily"]["sunrise"][0] = true;
  filter["daily"]["sunset"][0] = true;

  JsonDocument doc;
  DeserializationError err = deserializeJson(doc, http.getStream(), DeserializationOption::Filter(filter));
  http.end();
  if (err) { g_w.error = true; return false; }

  if (!doc["current"]["temperature_2m"].is<float>() && !doc["current"]["temperature_2m"].is<int>()) {
    g_w.error = true;
    return false;
  }

  WeatherSnapshot next = {};
  next.valid = true;
  next.error = false;
  next.currentC = doc["current"]["temperature_2m"].as<float>();
  next.code = doc["current"]["weather_code"] | 0;
  next.isDay = (doc["current"]["is_day"] | 1) != 0;
  next.highC = doc["daily"]["temperature_2m_max"][0] | next.currentC;
  next.lowC = doc["daily"]["temperature_2m_min"][0] | next.currentC;
  next.rainPct = doc["daily"]["precipitation_probability_max"][0] | -1;
  hhmm(doc["daily"]["sunrise"][0] | (const char*)nullptr, next.sunrise);
  hhmm(doc["daily"]["sunset"][0] | (const char*)nullptr, next.sunset);
  g_w = next;
  g_lastOkMs = millis();
  return true;
}
