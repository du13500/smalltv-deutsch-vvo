# Testplan SmallTV Deutsch/VVO v0.4.4

## v0.4.4 Schwerpunkt

1. **Wetter Karten-Picker:** Dresden suchen, Pin anschließend auf einen deutlich anderen Ort setzen. Prüfen, dass `Ausgewählter Standort` und der Würfel-Titel auf den reverse-geocodierten Namen wechseln. Zusätzlich einen Punkt auf Gebiet/Gewässer testen.
2. **Flugradar Karten-Picker:** gleiches Verhalten wie beim Wetter. Optionalen Anzeigenamen testen.
3. **Flugradar Standort-Toggle:** Checkbox aus = dauerhaft `IN DER NÄHE`; Checkbox an = Wechsel zwischen `IN DER NÄHE` und Standort/Anzeigename. Intervalle 5/10/15/30 s testen. Selector muss bei deaktivierter Checkbox ausgegraut sein.
4. **Flugradar Fehlergrace:** einzelnen fehlgeschlagenen Abruf provozieren. Anzeige darf nicht sofort auf `adsb.lol nicht erreichbar` springen. Fehleransicht erst nach mindestens zwei Fehlern und etwa 30 s ohne erfolgreichen Abruf.
5. **Wetter Einheiten:** Celsius und Fahrenheit testen. Große Temperatur sowie H/T müssen `°C` bzw. `°F` zeigen. Farblogik muss bei Umschaltung identisch bleiben.
6. **Wetter H/T:** positive, negative und zweistellige Werte prüfen. Beide Seiten müssen denselben Außenabstand haben.
7. **VVO Ausfall:** ausgefallene Fahrt muss rechts als rotes `X` an exakt der Position einer einstelligen Minutenangabe erscheinen.
8. **VVO 10 Abfahrten:** Option 10 wählen. 1-5 und 6-10 müssen im Aktualisierungsrhythmus wechseln. Seite 1 zeigt mittig `↓`, Seite 2 `↑`. Bei höchstens fünf Treffern keine zweite Seite und kein Pfeil.
9. **Uhr:** Footer-Linie und `EUROPE/BERLIN` bleiben, kleine redundante Uhrzeit rechts fehlt.
10. **Regression:** Toasts, Rotation, Countdown, Wettericons, manuelle Koordinaten und bestehende 3/4/5-Abfahrten unverändert testen.

---

# SmallTV Deutsch/VVO v0.4.3 Testplan

## Vor dem Flash

- GitHub Actions muss grün sein.
- Build-Log auf Compilerfehler/-warnungen und RAM-/Flash-Auslastung prüfen.
- Firmwaredatei muss `smalltv-dd-v0.4.3-firmware.bin` heißen.
- Update von einer laufenden v0.4/v0.4.1 direkt per `/update`, **ohne Loader**.

## Smoke-Test nach OTA

1. Gerät startet und verbindet sich mit dem bisherigen WLAN.
2. Webinterface zeigt `SmallTV Deutsch/VVO` und v0.4.3.
3. Vorhandene Konfiguration wurde übernommen.
4. Display ist korrekt ausgerichtet, Backlight und Farben funktionieren.
5. `/update` bleibt erreichbar.

## Webinterface / Feedback

- Speichern erzeugt einen grünen Toast und **kein Browser-OK-Popup**.
- Validierungsfehler erscheinen als Toast statt `alert()`.
- Countdown Start/Stop zeigt Toasts.
- Neustart zeigt eine kurze Rückmeldung und führt danach zum Reload.
- Footer zeigt `SmallTV Deutsch/VVO · entwickelt von du13500 · GitHub`.
- GitHub-Link öffnet das Repository.

## Karten-Picker Wetter

- `Dresden` suchen und Treffer auswählen.
- Koordinaten werden übernommen.
- `Auf Karte auswählen` lädt Leaflet/OpenStreetMap erst bei Bedarf.
- Marker startet an den gespeicherten/ausgewählten Koordinaten.
- Klick auf die Karte aktualisiert Breitengrad/Längengrad sofort.
- Marker lässt sich ziehen; nach Drag-End werden die Koordinaten aktualisiert.
- Manuelle Änderung der Koordinaten bleibt möglich und bewegt bei offener Karte den Marker.
- Anzeigename bleibt unabhängig vom Kartenpunkt editierbar.
- Ohne Internet darf die Karte fehlschlagen, das übrige Webinterface muss weiter funktionieren.
- Es gibt **keinen** Button `Aktuelle Position` und keine Browser-Geolocation-Abhängigkeit mehr.

## Karten-Picker Flugradar

- Ort suchen, Karte öffnen, Radar-Mittelpunkt abweichend von der Ortsmitte setzen.
- Gespeicherte Koordinaten nach Reload prüfen.
- Flugradar verwendet anschließend den gewählten exakten Mittelpunkt.
- Wetter- und Radar-Koordinaten bleiben unabhängig voneinander.

## WLAN

- Netzwerke suchen.
- Doppelte SSIDs nur einmal.
- Sortierung stärkstes Netz zuerst.
- Balken und dBm plausibel.
- Klick übernimmt SSID.

## Anzeige / Rotation

- Nur eine Checkbox: Ansicht bleibt dauerhaft.
- Mehrere Checkboxen: Wechsel nach den eingestellten Zeiten.
- Datenrefresh und Ansichtswechsel laufen unabhängig.
- Countdown-Slots laufen weiter, auch wenn sie nicht sichtbar sind.

## Uhr

- Gelbe Überschrift `UHR` ist entfernt.
- Minutenwechsel erfolgt ohne sichtbares Fullscreen-Blinken.
- Große Uhrzeit und Datum werden korrekt aktualisiert.
- Footer-Uhr bleibt synchron.

## Countdown

- Tages-Countdown mehrere Minuten beobachten: **kein sekündliches Pulsieren/Blinken**.
- Tageswert wird erst bei tatsächlicher Änderung neu gezeichnet.
- HH:MM:SS und MM:SS laufen weiterhin sekündlich.
- Vor Ziel: Minus.
- Exakt Null: feste leere Vorzeichenspalte.
- Nach Ziel: Plus.
- Stromverlust/Neustart: absolute Zielzeiten bleiben korrekt.

## Umlaute / Wetter / VVO

- `Winterbergstraße`, `Bewölkt`, `Müll`, `Übung` prüfen.
- Wetterfarben sowie Sunrise/Sunset-Symbole unverändert korrekt.
- VVO-Verkehrsmittelfilter testen.
- Lange Linienbezeichnungen wie RE50/ICE 1650 prüfen.

## Flugradar

- Routenauflösung weiterhin testen, ohne Routen zu erfinden.
- Positiver Routentreffer: beim selben Callsign keine wiederholten Route-API-Anfragen.
- `N/A > N/A`: nach 60 Sekunden genau einen erneuten Routenversuch zulassen, danach bis zum Wechsel auf einen anderen Callsign keine weiteren Route-API-Anfragen.
- Bekannte Linienflüge gegen externe Referenz gegenprüfen.
- Sonder-/Militärflug darf bei fehlender Route `N/A > N/A` zeigen.

## Flug-Tracker

- Bestehendes Verhalten regressionsprüfen.
- aviationstack bleibt optional und wird nur bei sichtbarer Tracker-Ansicht gepollt.

## Privacy-/Credit-Check

- Im Webinterface, README und LICENSE darf kein Klarname des Projektinhabers erscheinen.
- Sichtbarer Autoren-Credit ist ausschließlich `du13500`.
