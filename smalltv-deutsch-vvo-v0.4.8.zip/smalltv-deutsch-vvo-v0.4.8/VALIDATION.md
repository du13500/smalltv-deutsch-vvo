# Validierung v0.4.8

## Automatisierte Prüfungen

- Quellstruktur, Versionsangaben, JavaScript-Syntax, Zeitzonenauswahl und reproduzierbarer Pixel-Font geprüft.
- C++11-Kerntests mit -Wall -Wextra -Werror: UTF-8, Latin/Greek/Cyrillic, Wettercodes, Zeitzonen und Routen.
- Reale Radar-Vorabfunktionen: adaptive Heapprüfung, Poll-Takt, markierte Fehlerzustände, 30-Sekunden-Ablauf und millis-Überlauf.
- Gemeinsame HTTP-Abfragepolitik: Retry-After in Sekunden und als HTTP-Datum, gestufte Pause, Trennung der Anbieter und millis-Überlauf.
- Routenprüfung: alle drei gemeldeten DRS-Negativbeispiele als synthetische Positions-/Flughafenfixtures abgewiesen; passende DRS-Strecken und Datumsgrenzenfall akzeptiert. Keine historischen API-Antworten oder FR24-Daten übernommen.
- Tatsächliche Zeichenfunktionen mit Grafik-Recorder: unveränderte Wetter-, VVO-, Tracker-, Radar-, Uhr- und Countdown-Werte ohne Neuzeichnen; Minuten-/Temperatur-/Ziffernänderungen, neue Flugzeuge, geänderte Geometrie, GND/N/A/0 m und kompakte Typnamen geprüft.
- Playwright-WebKit an neun Bildschirmbreiten 320 bis 1024 Pixeln: Layout, Zeitzonen speichern, normalisierte Island-Koordinate, schnelle Karten-Picks, verspätete Ortsantwort, asiatischer Name und Speichern einer Position ohne Namen. Netzwerkantworten sind kontrollierte Fixtures.

## Firmware-Build

PlatformIO 6.1.19, espressif8266 4.2.1 und Arduino-ESP8266 3.1.2: vollständige Kompilierung und BIN-Erzeugung erfolgreich.

- Statisch belegtes RAM: 50.884 von 81.920 Bytes (62,1 %).
- Firmware-Flash: 684.779 von 1.044.464 Bytes (65,6 % der Buildpartition).
- Gegenüber v0.4.7: +2.832 Bytes statisches RAM, +11.940 Bytes Firmware-Flash.

Der RAM-Wert ist keine Messung des freien Laufzeit-Heaps. Die lokale Prüfung nutzte die identischen Compiler-/Frameworkpakete aus dem offiziellen Paketmirror; das unbenutzte alte Uploadwerkzeug tool-esptool wurde nur lokal als optional markiert. Der ausgelieferte Workflow nutzt die unveränderte Plattformkonfiguration.

## Grenzen

Keine Ausführung auf einem echten SmallTV in dieser Umgebung. Hardwaretest der Online-Abfragen, TLS-Fragmentierung, Speicherentwicklung, Routenqualität, iOS-Safari und des Flug-Trackers mit gültigem aviationstack-Schlüssel offen. Kein GitHub-Repository verändert.

Die Positionsprüfung kann unpassende Routen aussortieren; plausible Daten können trotzdem falsch sein. Globale Gewässernamen sind abhängig von der Nominatim-Abdeckung.
