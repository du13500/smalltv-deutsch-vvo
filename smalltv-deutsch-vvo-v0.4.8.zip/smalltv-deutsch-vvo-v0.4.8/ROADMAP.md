# Nächste Prüfung

- v0.4.8 am SmallTV-Ultra testen; Radar-Routenprüfung verwirft unpassende Daten, garantiert jedoch keine korrekte Route.
- HTTP-429-Erholung und langfristigen Speicherbedarf der Online-Ergänzung beobachten.
- Alle Wetterbilder bei realen Wetterlagen prüfen.
- Vollständigen Flug-Tracker mit gültigem aviationstack-Schlüssel testen.
- Belastungstest mit mehr als zwei Programmen nach dem Radarfix.
- Kein automatisches Umschreiben nicht darstellbarer Ortsnamen; optionaler Anzeigename bleibt der Ausweg.
