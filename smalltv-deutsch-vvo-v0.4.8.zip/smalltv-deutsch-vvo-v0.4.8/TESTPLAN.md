# Hardwaretest v0.4.8

1. Firmware über den GitHub-Workflow bauen und per OTA installieren. Gespeicherte v0.4.7-Einstellungen prüfen.
2. Map-Picker: Island nach horizontalem Verschieben der Weltkarte wählen. Länge muss zwischen -180 und 180 bleiben. Wetter und Radar prüfen, auch Marker ziehen.
3. Rasch mehrere Punkte wählen, darunter asiatische Orte und offene Gewässer. Nur der letzte Punkt darf seinen Namen übernehmen. Fehlende Namen dürfen Speichern nicht verhindern; Freitext testen.
4. Radar: Systemstatus mit Positions-HTTP, verbleibender Pause und Routenquelle prüfen. 429 muss eine Pause auslösen. Nach Ablauf wieder automatisch versuchen.
5. Durchgehenden Abruffehler beobachten: letzter Stand höchstens 30 Sekunden. Erfolgreiche Erholung und Flugzeugwechsel prüfen.
6. Falsche Routenbeispiele DLH1FN WRO-FRA, DLH062 FRA-FMO, SXS5NW AYT-DUS in DRS als niedrige/Bodenflugzeuge sollen abgewiesen werden. Eine abgewiesene Route wird N/A, nicht automatisch DRS.
7. Pegasus/SunExpress sowie private Flugzeuge: Online-Zusatznamen, kompakte Typnamen und Rückfall bei fehlenden Daten testen. Expliziter Bodenstatus muss GND zeigen.
8. Alle Ansichten: unveränderte Daten kein sichtbares Neuzeichnen; kürzere/geänderte Texte sauber löschen. Abfahrtsreihenfolge, JETZT/X, Wetterfehler, Temperatureinheit, Countdown-Ziffern/Nullübergang und Programmwechsel prüfen.
9. Tracker ohne Flugnummer/Schlüssel: Footer nur Uhr. Vollständige API-Nutzung weiterhin am Gerät offen.
10. Zeitzone/Nachtmodus/Unicode/Speichern als Regression prüfen, dann Dauerbetrieb mit ein oder zwei Programmen. Mehr als zwei Programme erst nach Bewertung des Radarfixes.

Automatisierte Tests ersetzen keine API- und Langzeittests auf dem ESP8266.
